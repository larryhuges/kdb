<?php
	require 'includes/bootstrap.php';
	include("includes/guest_area_head.php");
	alert_box();
?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #fff; background: #000A1E url(media/images/photo/bg.jpg) no-repeat center top; background-size: cover; z-index: 2;">
	<div id="inner-frame" class='' style="padding: 0 0; height: 27rem; margin: 8rem auto; z-index: 3; position: relative;">
		<div class='col l_col l_col_a'>
			<div>
				<p><strong style='font-size: 2rem;'>Korea's Financial Platform Leading To a Bright Future</strong></p>
				<br> 
				<h1><img src="/media/images/photo/img_main_tit1.png" alt="Global KDB"></h1> 
				<br>
				<p>In line with the government's policy to transform Korea<br> into a financial hub, the Bank has adopted the vision<br> of becoming a leading bank in Asia.</p> 
			</div>
		</div>
		 
	</div>
	
</div>

<style>
	.sIco{
		width: 100%;
		height: 28rem;
		position: absolute;
		bottom: 10rem;
		left: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		z-index: 22;
		padding: 2rem;
	}

	.sIco > div {
		width: 100%;
		max-width: 100rem;
		height: 100%;
		background-color: #fff;
		border-radius: 1rem;
		box-shadow: 0px 0px 5px 3px #0002;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.sIcoFirst{
		width: 60%;
		display: flex;
		justify-content: center;
		align-items: center;
		height: 70px;
	}

	.wrap{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin: 0 3rem;
	}

	.itemHolder{
		position: relative;
		width: 66px;
		height: 70px;
		margin: 0 auto 5px;
		overflow: hidden;
	}

	.itemHolder::before{
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		height: 70px;
		z-index: 1;
		background: url(/bg_chgl_frame.png) no-repeat center 0;
	}

	
	.wrap:hover span{
		color: #0d6efd;
		text-decoration: underline;
	}

	.afterItem, .beforeItem2{
		position: absolute;
		top: 0;
		left: 0;
		width: 66px;
		height: 70px;
		transition: all 0.25s ease-in-out;
	}

	.afterItem{
		top: 70px;
	}

	.itemHolder:hover > i div.afterItem{
		top: 0;
	}

	

	.sIcoSecond{
		width: 40%;
		height: 100%;
		border-radius: 0 1rem 1rem 0;
		background-color: #0063cc;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		padding: 3rem;
	}

	.innerBox2{
		width: 100%;
		height: auto;
		margin: .5rem 2rem;
		position: relative;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		transition: all 0.25s ease-in-out;
	}
	

	.innerBox2:hover{
		color: #fff;
	}

	.itemHolder2{
		position: relative;
		width: 55px;
		height: 55px;
	}

	.beforeItem{
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 1;
	}

	.innerBox2 span{
		width: auto;
		margin-left: 1.5rem;
		color: #fff;  
		font-size: 1.7rem;
	}


	/* .item2::after, .item2::before{
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		width: 55px;
		height: 55px;
		transition: all 0.25s ease-in-out;
	} */
		
</style>

<div class='sIco'>
	<div>
		<div class='sIcoFirst'>
			<div class="wrap">
				<div class="itemHolder">
					<i class="item">
						<div class="beforeItem2" style='background: #eff1f3 url(/media/images/photo/ico_chgl_cont_01.png) no-repeat center 0;'></div>
						<div class="afterItem" style='background: #0063cc url(/media/images/photo/ico_chgl_cont_01_on.png) no-repeat center 0;'></div>
					</i>
				</div>
				<span>View Accounts</span>   
			</div>
			<div class="wrap">
				<div class="itemHolder">
					<i class="item">
						<div class="beforeItem2" style='background: #eff1f3 url(/media/images/photo/ico_chgl_cont_02.png) no-repeat center 0;'></div>
						<div class="afterItem" style='background: #0063cc url(/media/images/photo/ico_chgl_cont_02_on.png) no-repeat center 0;'></div>
					</i>
				</div>
				<span> Transfer</span>  
			</div>
			<div class="wrap">
				<div class="itemHolder">
					<i class="item">
						<div class="beforeItem2" style='background: #eff1f3 url(/media/images/photo/ico_chgl_cont_05.png) no-repeat center 0;'></div>
						<div class="afterItem" style='background: #0063cc url(/media/images/photo/ico_chgl_cont_05_on.png) no-repeat center 0;'></div>
					</i>
				</div>
				<span> Quick Inquiry</span>    
			</div>
			<div class="wrap">
				<div class="itemHolder">
					<i class="item">
						<div class="beforeItem2" style='background: #eff1f3 url(/media/images/photo/ico_chgl_cont_02.png) no-repeat center 0;'></div>
						<div class="afterItem" style='background: #0063cc url(/media/images/photo/ico_chgl_cont_02_on.png) no-repeat center 0;'></div>
					</i>
				</div>
				<span>Exchange</span> 
			</div>
		</div>
		<div class='sIcoSecond'>
			<div class="innerBox2">
				<div class="itemHolder2">
					<div class="beforeItem" style='background: url(/media/images/photo/ico_chgl_com_01.png) no-repeat center center;'></div>
					<i class="item2"></i>
				</div>
				<span>Trust & Pension</span>
			</div>
			<div class="innerBox2" style='border-top: 1px solid gray; border-bottom: 1px solid gray; padding: .5rem 0;'>
				<div class="itemHolder2">
					<div class="beforeItem" style='background: url(/media/images/photo/ico_chgl_com_02.png) no-repeat center center;'></div>
					<i class="item2"></i>
				</div>
				<span>Customer Banking</span>
			</div>
			<div class="innerBox2">
				<div class="itemHolder2">
					<div class="beforeItem" style='background: url(/media/images/photo/ico_chgl_com_04.png) no-repeat center center;'></div>
					<i class="item2"></i>
				</div>
				<span>Consulting</span>
			</div>
		</div>
	</div>
</div> 


<div id="frame" style="padding: 3rem 0; background: #fff;">	
	<div>

	</div>
	<div id="inner-frame" align="center" style='margin-top:10rem'>
		
	</div>
</div>


<div id="frame" style="background-color: #fff; padding: 10px; color: #333; font-size: 1.4rem; background: #000A1E url(media/images/backgrounds/hcbg.jpg) no-repeat center top; background-size: cover;">
	<div id="inner-frame" style="max-width: 1200px;">
		<div class='col two_col col_assist' style="">
			<div class='page_title' style="margin:0;  width: 100%; color:#002C5C;">
				Explore KDB<br>
				Start banking better with us.
			</div>
			<p style="line-height: 1.5; margin: .675rem 0; text-align: justify;">
				

				We believe in the possibilities of better. And we’re excited to start this journey with you. Take the first step toward a better banking experience—find your fit here.

			</p>
		</div> 
		
	</div>	
</div>

<style>
	.cus{
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		text-align: left;
		 color: #666;
	}
</style>
<div id="frame" style="padding: 3rem 0; border-top: 1px solid #dedede; background: #f5f7fb;">	
	
	<div id="inner-frame" align="center">

		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus' style='padding-left: 8.5rem;
    background: url(media/images/photo/ico_cscont.png) no-repeat 0 0;'>

				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>KDB Customer Center</span>
				
				<p style='font-size: 1.4rem; color: #666;'>Monday ~ Friday 09:00 ~ 18:00 (Korea time) </p>

			</div>
		</div>
		
		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus'>

				<p style='font-size: 1.4rem; color: #666;'>Domestic </p>
				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>1588-1500, 1668-1500</span>
				

			</div>
		</div>

		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus'>


				<p style='font-size: 1.4rem; color: #666;'>Overseas </p>
				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>+82-1588-1500, +82-1668-1500</span>

			</div>
		</div>

		
	</div>
</div>
<?php include("includes/guest_area_foot.php");?>