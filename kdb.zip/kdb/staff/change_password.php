<?php
require_once("../includes/bootstrap.php");	
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
		<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-lock'></i> Admin Change Password
				<br><hr>
			</div>
			<div id="popdown">
				<div id='close_pop' style='color:#333;' onclick="close_popup()"><i class='fa fa-close'></i></div>
				<div id='message'></div>
			</div>
	<?php
		$errcode=array();
		$old_password=$new_password=$r_new_password="";
		$old_password_errmessage=$new_password_errmessage=$r_new_password_errmessage="";
		
		if(isset($_POST['update'])){
			if(!empty($_POST['old_password']) && isset($_POST['old_password'])){
				$old_password=clean_strings($_POST['old_password']);
				if(!preg_match("/^[a-zA-Z0-9]*$/",$old_password)){
					$old_password_errmessage="Only Numbers and Alphabets are allowed";
					$errcode[]=1;
				}
				$hashed_password=sha1($old_password);
				mysqli_query($con,"select id from wlis_admin_table_768 where username='{$_SESSION['wlis_admin_username']}' and password='$hashed_password'");
				if(mysqli_affected_rows($con)<1){
					$old_password_errmessage="Incorrect Old Password";
					$errcode[]=8;
				}
				
			}else{
				$old_password_errmessage="Old Password field cannot be empty";
				$errcode[]=2;
			}
			
			if(!empty($_POST['new_password']) && isset($_POST['new_password'])){
				$new_password=clean_strings($_POST['new_password']);
				if(!preg_match("/^[a-zA-Z0-9]*$/",$new_password)){
					$new_password_errmessage="Only Numbers and Alphabets are allowed";
					$errcode[]=3;
				}
				
			}else{
				$new_password_errmessage="New Password field cannot be empty";
				$errcode[]=4;
			}
			
			if(!empty($_POST['r_new_password']) && isset($_POST['r_new_password'])){
				$r_new_password=clean_strings($_POST['r_new_password']);
				if(!preg_match("/^[a-zA-Z0-9]*$/",$r_new_password)){
					$r_new_password_errmessage="Only Numbers and Alphabets are allowed";
					$errcode[]=5;
				}
				
			}else{
				$r_new_password_errmessage="Retype Password field cannot be empty";
				$errcode[]=6;
			}
			
			if($new_password!=$r_new_password){
				$r_new_password_errmessage="Password Mismatch";
				$errcode[]=7;
			}else{
				$new_hashed_password=sha1($new_password);
			}
			
			if(!empty($errcode)){
				$msgbox="You have ". count($errcode) ." errors";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{
				mysqli_query($con, "update wlis_admin_table_768 set password='$new_hashed_password' where username='{$_SESSION['wlis_admin_username']}'");
				if(mysqli_affected_rows($con)==1){
					$msgbox="Password Changed Successfully";
					unset($_SESSION['wlis_admin_id']);
					unset($_SESSION['wlis_admin_username']);
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("../admin_gain_321_access");
				}
			}
		}
	?>
		
			<div id='log_form'> 
			
			<form id='form1' name='form1' onsubmit="return myFunction('Change Password?')" method='post' action='change_password' enctype='multipart/form-data'>
				&nbsp;<input class='text' type='password' required title='Old Password' name='old_password' placeholder='Enter Old Password'/><span style='color:red; font-style:italic;'><?php echo $old_password_errmessage;?></span>
				&nbsp;<input class='text' type='password' required title='New Password' name='new_password' placeholder='Enter New Password'/><span style='color:red; font-style:italic;'><?php echo $new_password_errmessage;?></span>
				&nbsp;<input class='text' type='password' required title='Re-type New Password' name='r_new_password' placeholder='Re-type New Password'/><span style='color:red; font-style:italic;'><?php echo $r_new_password_errmessage;?></span><br><br>
				<button class='btn upd' type='submit' name='update'>Change Password</button><br /><br />
			</form>
				
		</div>
		</div>
<?php 
include("includes/admin_foot.php");
?>