<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
//alert_box();
?>
<?php
	$doc_name="";
	$path1="";
	$path2="";
	$frontp="";
	$backp="";
	$date_uploaded=date("d M Y H:i:s");
	
	$errmessage=array();
	
	if(isset($_POST['upload'])){
		
		if(!empty($_POST['doc_name']) && isset($_POST['doc_name'])){
			$doc_name=clean_strings($_POST['doc_name']);
		}else{
			$errmessage['doc_name']="Enter Document Name";
		}
		
		if(!empty($_FILES['frontp']['name']) && isset($_FILES['frontp']['name'])){
			$frontp=clean_strings($_FILES['frontp']['name']);
			$filename1=basename($frontp);
			$path1=strtolower(str_replace(" ","_","../images/documents/front_".$filename1));
			$tmp_name1=$_FILES['frontp']['tmp_name'];
			$type1=$_FILES['frontp']['type'];
			$size1=$_FILES['frontp']['size'];
			
			if($type1=='image/jpeg' || $type1=='image/jpg' || $type1=='image/png'){
				echo null;
			}else{
				$errmessage['photo1_type']="Only image Files (Jpeg, Jpg, Png) are allowed<br>";
			}
			
			if($size1>5000000){
				$errmessage['photo1_size']="image Size Should be less than 5MB<br>";
			}
		}else{
			$errmessage['frontp']="Select Front Image";
		}
		
		
		 if(!empty($_FILES['backp']['name']) && isset($_FILES['backp']['name'])){
			$backp=clean_strings($_FILES['backp']['name']);
			$filename2=basename($backp);
			$path2=strtolower(str_replace(" ","_","../images/documents/back_".$filename2));
			$tmp_name2=$_FILES['backp']['tmp_name'];
			$type2=$_FILES['backp']['type'];
			$size2=$_FILES['backp']['size'];
			
			if($type2=='image/jpeg' || $type2=='image/jpg' || $type2=='image/png'){
				echo null;
			}else{
				$errmessage['photo2_type']="Only image Files (Jpeg, Jpg, Png) are allowed<br>";
			}
			
			if($size2>5000000){
				$errmessage['photo2_size']="image Size Should be less than 2MB<br>";
			}
		}else{
			$errmessage['backp']="Select Back Image";
		} 
		
		if(!empty($errmessage)){
			$response='Error Occured';
			echo "<script>alert('Error, You will be notified via email.')</script>";
		}else{
			$sql="update users_info  set doc_name='$doc_name', frontp='$path1', backp='$path2', date_uploaded='$date_uploaded' where username='{$_SESSION['wlis_member_username']}'";
			//$pst_id=mysqli_insert_id($con);
			mysqli_query($con, $sql);
			if(mysqli_affected_rows($con)==1){
				if(!empty($path1)){
					move_uploaded_file($tmp_name1,$path1);
				}
				
				if(!empty($path2)){
					move_uploaded_file($tmp_name2,$path2);
				} 
				$admin_msg="{$_SESSION['wlis_member_username']} has apply for account verification on Fxmoore-Options";
				send_admin_mail('Verify Account',$admin_msg);
				echo "<script>alert('Uploaded Successfully, your account will be verified within 24hrs.')</script>";
			}else{
				echo "<script>alert('Error uploading document.')</script>";
			}
		}
	}
?>
		<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
			<div class='bread_c'>
				<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Account Verified</span>
			</div>
		</div>

		<div class='g_col' style="width:98%; padding:20px 0;  background-color: transparent; border:0; box-shadow: none;">
				<div id="packages">
					<div id='packages_inn'>
						<i class='fa fa-money' id='faicon'></i>
						<div id='d_amt'>
							<h1 class="h_value">
								$ <?php echo btc_bal();?>
							</h1>
							<p class='reduce'> Wallet </p><br><br>
						</div>
						<div id='p_below'>
							Online wallet balance
						</div>
					</div>
				</div>

				<div id="packages">
					<div id='packages_inn' style="background-color: #f39c12 !important;">
						<i class='fa fa-user' style='position:absolute; top:7px; right:10px; font-size:80px; color:rgba(0,0,0,0.15);'></i>
						<div id='d_amt'>
							<h1 style="font-size: 38px; font-weight: bold; margin: 0 0 10px 0; white-space: nowrap; padding: 0;">
								 <i class='fa fa-user'></i> 4837
							</h1>
							<br>
							<p class='reduce'> Registered User </p><br><br>
						</div>
						<div id='p_below'>
							We provide service you can trust
						</div>
					</div>
					
				</div>
				
				<div id="packages">
					<div id='packages_inn' style="background-color:  #39cccc !important;">
						<i class='fa fa-check' style='position:absolute; top:7px; right:10px; font-size:80px; color:rgba(0,0,0,0.15);'></i>
						<div id='d_amt'>
							<h1 style="font-size: 38px; font-weight: bold; margin: 0 0 10px 0; white-space: nowrap; padding: 0;">
								 100%
							</h1>
							<br>
							<p class='reduce'> Client Trust </p><br><br>
						</div>
						<div id='p_below'>
							Our Services Speaks for us.
						</div>
					</div>
				</div>
			
				<div id="packages">
					<div id='packages_inn' style="background-color:#00a65a !important; ">
						<i class='fa fa-lock' style='position:absolute; top:7px; right:10px; font-size:80px; color:rgba(0,0,0,0.15);'></i>
						<div id='d_amt'>
							<h1 style="font-size: 25px; font-weight: bold; margin: 0 0 10px 0; white-space: nowrap; padding: 0;">
								 <?php echo $_SERVER['REMOTE_ADDR'];?>
							</h1>
							<br>
							<p class='reduce'> Your IP Address </p><br><br>
						</div>
						<div id='p_below'>
							Your access IP right now
						</div>
					</div>
				</div>			
			</div> 
    
		<div class='g_col' style="border-top: 3px solid #dd4b39; padding:0; margin-bottom: 20px; background: #fff; box-shadow: 0 1px 1px rgba(0,0,0,0.1); border-radius: 3px; ">
			<div style=''>
				<div style='display: inline-block; font-size: 16px; margin: 0; line-height: 1; padding: 10px; font-weight: normal; font-family: page_section_font; border-bottom: 1px solid rgba(0,0,0,0.05); width: 100%'>
					<i class="fa fa-user"></i> Verify Account
				</div>
				<div style="position: relative; margin: auto; width: 100%; max-width: 700px; text-align: justify; font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; font-weight: 600; padding: 20px;">
					<?php
						if($_SESSION['wlis_member_verified']=='Yes'){
					?>
							<div align='center' style='padding: 5% 5% 5% 5%; border-radius: 0;'>
					
								<div id='display_icon' style="margin-bottom: 30px;">
									<img src="images/success2.gif" width='100'>
								</div>
								<h1 id='message_title' style='width: 100%; padding-bottom: 3%; font-family: page_font_rob; font-size: 20px;'>
									YOUR ACCOUNT HAS BEEN VERIFIED
								</h1>
							</div>
					<?php
						}else{
					?>
							Verify Your account by providing us with a vaild document (ID card). Drivers Licence, Valid Work ID Card, Passport, etc are accepted. Please do not try to upload a fake document as our support teams reviews every document uploaded. Detected fake documents will lead to immediate suspension of account! Once Uploaded, Our support team reviews your document and gets back to you within 3 working days. The uploaded documents are for verification purposes only and are deleted once confirmed. You will be notified via email once your document has been verified. <br>
							Choose your document and click on the verify button.<br><br>
							<form method="POST" style="font-weight: 100;" action="/user/verify.php" enctype="multipart/form-data">
								<p id="field_title">Username</p>
								<input type='text' value="<?php //echo $username;?>" name='username' required class='text' placeholder='Username'>

								<p id="field_title">Document Name</p>
								<input type='text' value="" name='doc_name' required class='text' placeholder='Enter the document name (E.g: Driver's License)' style="background-color: transparent;">

								<p id="field_title">Front Page</p>
								<input type='file' accept="image/*" value="" name='frontp' required class='text' style="background-color: transparent; border: none;">

								<p id="field_title">Back Page</p>
								<input type='file' accept="image/*" value="" name='backp' required class='text'style="background-color: transparent; border: none;">

								<button type='submit' name='upload' style="background-color: #00c0ef; border-color: #00acd6;    border-radius: 3px;margin: 1%; width: 98%; padding: 10px 16px; font-size: 18px; line-height: 1.3333333;" class='btn2 upd'>
									<i class="fa fa-check"></i> Verify Account
								</button>
							</form>
					<?php
						}
					?>
				</div>
			</div>
		</div>
<script type="text/javascript">
	function close_alert(){
		 var y=document.getElementById('alert_box');
	    y.style.animation='d_out .5s ease';
    	setTimeout(function (){document.getElementById('alert_box_holder').style.display='none';},500);
	}
</script>

</div>
<?php 
include("includes/member_foot.php");
?>