<?php
	ob_start();
	require_once("sessions.php");	
	require_once("connection.php");
	require_once("functions.php");
?>