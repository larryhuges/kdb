<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
$username = $_SESSION['customer_username'];
$t_query=mysqli_query($con, "select * from `users_info` where username='$username' limit 1");
$t_out=mysqli_fetch_assoc($t_query);
$t_current_balance=$t_out['current_balance'];
/* $t_fullname=$t_out['firstname']." ".$t_out['lastname'];
$t_username=$t_out['username'];
$t_verified=$t_out['verified'];
$t_referral=$t_out['referral'];
$t_email=$t_out['email'];
$t_mobile=$t_out['mobile'];
$t_photo=$t_out['photo'];
$t_account_name=$t_out['account_name'];
$t_checking_account=$t_out['checking_account'];
$t_saving_account=$t_out['savings_account'];
$t_credit_card=$t_out['credit_card'];
$t_bank_name=$t_out['bank_name'];
$t_available_balance=$t_out['available_balance'];
$t_s_current_balance=$t_out['s_current_balance'];
$t_s_available_balance=$t_out['s_available_balance'];
$t_cc_current_balance=$t_out['cc_current_balance'];
$t_cc_available_balance=$t_out['cc_available_balance']; */

	if(isset($_POST['t_from'])){
		$t_from = clean_strings($_POST['t_from']);
		$t_pin = clean_strings($_POST['t_pin']);
		$t_to = clean_strings($_POST['t_to']);
		$t_accNum = clean_strings($_POST['t_accNum']);
		$t_amount = clean_strings($_POST['t_amount']);
		$t_date = clean_strings($_POST['t_date']);
		$t_memo = clean_strings($_POST['t_memo']);
		$email = $_SESSION['customer_email'];

		$sql = "select id from users_info where pin='$t_pin' and username = '$username'";
		mysqli_query($con, $sql);
		if(mysqli_affected_rows($con) >= 1){
			if($t_amount <= 100000){
				if($t_amount <= $t_current_balance){
					$sql = "update users_info set current_balance = current_balance - $t_amount, available_balance = available_balance - $t_amount where username = '$username'";
					//echo $sql;
					mysqli_query($con, $sql);
					//echo mysqli_error($con);
					if(mysqli_affected_rows($con)==1){
						$date_of_event=date("Y-m-d H:i:s");
						mysqli_query($con, "insert into transactions (username, amount, transfer_from, transfer_to, description, h_address, date_of_event, status) values ('$username', $t_amount, '$t_from', '$t_accNum', '$t_to', '$t_memo', '$t_date', 'processing')");
						if(mysqli_affected_rows($con)==1){
							echo '200';
						}else{
							echo '202';
						}
					}else{
						echo "500";
					}
				}else{
					echo "400";
				}
			}else{
				echo "401";
			}
		}else{
			echo "404";
		}
		
	}
?>