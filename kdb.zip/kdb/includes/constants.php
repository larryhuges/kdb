<?php
	define("DB_SERVER","localhost");
	define("DB_USERNAME","root");
	define("DB_PASSWORD","");
	define("DB_NAME","loan");
?>

<?php
/* 	define("DB_SERVER","localhost");
	define("DB_USERNAME","intloelk_keyvest");
	define("DB_PASSWORD","kIukT9f3G=5R");
	define("DB_NAME","intloelk_keyvest"); */
?>