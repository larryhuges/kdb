<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
//alert_box();
?>
<div id='modalimg' style='overflow:scroll;' align='center'>
	<div id='close_pop' style='color:#f00; z-index:10000000;' onclick="document.getElementById('modalimg').style.display='none';"><i class='fa fa-close'></i></div>
	<img class='image_resize' id='imgmod' style='margin:auto;'>
</div>
<?php
	$doc_name="";
	$path1="";
	$path2="";
	$frontp="";
	$backp="";
	$date_uploaded=date("d M Y H:i:s");
	
	$errmessage=array();
	
	if(isset($_POST['activate'])){
		
		if(!empty($_POST['username']) && isset($_POST['username'])){
			$username=clean_strings($_POST['username']);
		}else{
			$errmessage['username']="Enter Document Name";
		}
		
		if(!empty($_POST['email']) && isset($_POST['email'])){
			$email=clean_strings($_POST['email']);
		}else{
			$errmessage['email']="Enter Email";
		}

		if(!empty($errmessage)){
			$response='Error Occured';
			echo "<script>alert('Error, You will be notified via email.')</script>";
		}else{
			$sql="update users_info set verified='Yes' where username='$username'";
			//$pst_id=mysqli_insert_id($con);
			mysqli_query($con, $sql);
			if(mysqli_affected_rows($con)==1){
				$subject='Account Verified Successfully';

				$message="Dear ".$username.",<br><br>Your 360FOREX account has been verified successfully <br> Please fund your online wallet and start trading";
				
				$email_from = "admin@360forex.net";

                $message = "<img src='https://www.360forex.net/images/logo-dark.jpg'><br><br>".$message."<br><br>Best Regards,<br><br>
<img src='https://www.360forex.net/images/signature.png' height='35'><br>
<b>360FOREX</b>";
               // $from = $from_mail;
            
                $headers = "";
                $headers .= "From: 360FOREX <admin@360forex.net> \r\n";
                $headers .= "Reply-To:" . $email_from . "\r\n" ."X-Mailer: PHP/" . phpversion();
                $headers .= 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";    
                mail($email,$subject,$message,$headers);
				echo "<script>alert('Verified Successfully.')</script>";
			}else{
				echo "<script>alert('Error verifying account.')</script>";
			}
		}
	}
?>
		<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
			<div class='bread_c'>
				<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Verify</span>
			</div>
		</div>

		<div class='g_col' style="box-shadow:none; border-top: 3px solid #dd4b39; padding:0; margin-bottom: 20px; background: #fff; box-shadow: 0 1px 1px rgba(0,0,0,0.1); border-radius: 3px; overflow-x:scroll;">
			<div style=''>
				<div style='display: inline-block; font-size: 16px; margin: 0; line-height: 1; padding: 10px; font-weight: normal; font-family: page_section_font; border-bottom: 1px solid rgba(0,0,0,0.05); width: 100%;'>
					<i class="fa fa-user"></i> Verify Account
				</div>
				<div style="position: relative; margin: 1%; width: 98%; text-align: justify; font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; font-weight: 600; padding: 20px;">
					<table class='pay'>
				<tr class='pay'>
					<th class='pay' style="color:#fff; background-color: #2196F3;">SN</th>
					<th class='pay' style="color:#fff; background-color: #2196F3;">USERNAME</th>
					<th class='pay' style="color:#fff; background-color: #2196F3;">DOCUMENT NAME</th>
					<th class='pay' style="color:#fff; background-color: #2196F3;">FRONT PHOTO</th>
					<th class='pay' style="color:#fff; background-color: #2196F3;">BACK PHOTO</th>
					<th class='pay' style="color:#fff; background-color: #2196F3;">DATE</th>
					<th class='pay' style="color:#fff; background-color: #2196F3;">ACTION</th>
				</tr>

				<?php 
					$sql="select * from users_info where verified='No' and frontp <> '' and backp <> ''";
					$query=mysqli_query($con,$sql);
					$i=1;
					while($out=mysqli_fetch_assoc($query)){
						
				?>
				<tr class='pay'>
					<td class='pay'>&nbsp;<?php echo $i;?>&nbsp;</td>
					<td class='pay'>&nbsp;<?php echo $out['username']?>&nbsp;</td>
					<td class='pay'>&nbsp;<?php echo $out['doc_name']?>&nbsp;</td>
					
					<td class='pay'>&nbsp;<img style="cursor: pointer;" src='../user/<?php echo $out['frontp'];?>' onclick="showImage('../user/<?php echo $out['frontp']?>')" width='60'>&nbsp;
					<td class='pay'>&nbsp;<img style="cursor: pointer;" src='../user/<?php echo $out['backp'];?>' onclick="showImage('../user/<?php echo $out['backp']?>')" width='60'>&nbsp;
					<td class='pay'>
						&nbsp; 
						<?php echo formatted_date($out['date_uploaded'])?>
						&nbsp;
					</td>
					<td class='pay'>&nbsp
						<form action="" method="post" >
							
							<input type="hidden" name="username" value="<?php echo $out['username']?>">
							<input type="hidden" name="email" value="<?php echo $out['email']?>">
							<button type='submit' name='activate' class='btn upd'><i class='fa fa-info'></i>
								Activate
							</button>
						</form>
						&nbsp;
					</td>
				</tr>
				<?php 
					$i++;
				}
				?>
			</table>
				</div>
			</div>
		</div>
<script type="text/javascript">
	function close_alert(){
		 var y=document.getElementById('alert_box');
	    y.style.animation='d_out .5s ease';
    	setTimeout(function (){document.getElementById('alert_box_holder').style.display='none';},500);
	}

	function showImage(imgsrc){
		document.getElementById('modalimg').style.display='block';
		document.getElementById('imgmod').src=imgsrc;
	}
</script>

</div>
<?php 
include("includes/admin_foot.php");
?>