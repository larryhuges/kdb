<?php
require_once("../includes/bootstrap.php");	
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-group'></i> Update User Info
				<br><hr>
			</div>
			<div id="popdown">
				<div id='close_pop' style='color:#333;' onclick="close_popup()"><i class='fa fa-close'></i></div>
				<div id='message'></div>
			</div>
<?php
	$errcode=array();
	$firstname=$lastname=$country_code=$mobile=$mobile_number=$email=$dob=$country=$state=$account_name=$account_number=$bank_name=$account_type=$currency=$business_type=$referral=$username=$pin=$ewallet=$house_address="";
	$firstname_errmessage=$lastname_errmessage=$country_code_errmessage=$mobile_errmessage=$email_errmessage=$dob_errmessage=$country_errmessage=$state_errmessage=$account_name_errmessage=$account_number_errmessage=$bank_name_errmessage=$account_type_errmessage=$currency_errmessage=$business_type_errmessage=$referral_errmessage=$username_errmessage=$password_errmessage=$r_password_errmessage=$pin_errmessage=$gender_errmessage=$house_address_errmessage=$ewallet_errmessage="";
	
	if(isset($_GET['user']) && !empty($_GET['user'])){
		$user=trim(clean_strings($_GET['user']));
	}else{
		$user=null;
	}
	
	$sql="select * from users_info where username='$user' limit 1";
	$query=mysqli_query($con, $sql);
	$out=mysqli_fetch_assoc($query);
	$firstname=$out['firstname'];
	$lastname=$out['lastname'];
	$mobile=$out['mobile'];
	$email=$out['email'];
	$gender=$out['gender'];
	$country=$out['country'];
	$dob=$out['dob'];
	$pin=$out['pin'];
	$ewallet=$out['current_balance'];
	$house_address=$out['house_address']; 
	$account_number=$out['checking_account'];

/* 	
	$account_name=$out['account_name'];
	$bank_name=$out['bank_name'];
	$account_type=$out['account_type'];
	*/
	
	if(isset($_POST['update'])){
		
		if(!empty($_POST['firstname']) && isset($_POST['firstname'])){
			$firstname=trim(clean_strings($_POST['firstname']));
		}else{
			$firstname_errmessage="First Name cannot be empty";
			$errcode[]=2;
		}
		
		if(!empty($_POST['lastname']) && isset($_POST['lastname'])){
			$lastname=trim(clean_strings($_POST['lastname']));
		}else{
			$lastname_errmessage="Last Name cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['mobile']) && isset($_POST['mobile'])){
			$mobile=trim(clean_strings($_POST['mobile']));
		}else{
			$mobile_errmessage="Mobile cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['email']) && isset($_POST['email'])){
			$email=trim(clean_strings($_POST['email']));
			if(filter_var($email,FILTER_VALIDATE_EMAIL)){
				echo null;
			}else{
				$email_errmessage="Invalid Email Format";
				$errcode[]=1;
			}
		}else{
			$email_errmessage="Email field cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['dob']) && isset($_POST['dob'])){
			$dob=trim(clean_strings($_POST['dob']));
		}else{
			$dob_errmessage="Date of Birth cannot be empty";
			$errcode[]=4;
		}
		
	if(!empty($_POST['country']) && isset($_POST['country'])){
			$country=trim(clean_strings($_POST['country']));
		}else{
			$country_errmessage="Country cannot be empty";
			$errcode[]=4;
		}
		
	/* 		if(!empty($_POST['state']) && isset($_POST['state'])){
			$state=trim(clean_strings($_POST['state']));
			if(!preg_match("/^[a-zA-Z]*$/",$state)){
				$state_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$state_errmessage="State cannot be empty";
			$errcode[]=4;
		} */
		
		if(!empty($_POST['account_name']) && isset($_POST['account_name'])){
			$account_name=trim(clean_strings($_POST['account_name']));
			if(!preg_match("/^[a-zA-Z ]*$/",$account_name)){
				$account_name_errmessage="Only alphabets are allowed";
				$errcode[]=1;
			}
		}else{
			$account_name_errmessage="Account Name cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['account_number']) && isset($_POST['account_number'])){
			$account_number=trim(clean_strings($_POST['account_number']));
		}else{
			$account_number_errmessage="Account No Field cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['bank_name']) && isset($_POST['bank_name'])){
			$bank_name=trim(clean_strings($_POST['bank_name']));
		}else{
			$bank_name_errmessage="Bank Name cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['account_type']) && isset($_POST['account_type'])){
			$account_type=trim(clean_strings($_POST['account_type']));
			if(!preg_match("/^[a-zA-Z ]*$/",$account_type)){
				$account_type_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$account_type_errmessage="Field cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['pin']) && isset($_POST['pin'])){
			$pin=trim(clean_strings($_POST['pin']));
		}else{
			$pin_errmessage="Pin cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['house_address']) && isset($_POST['house_address'])){
			$house_address=trim(clean_strings($_POST['house_address']));
		}else{
			$house_address_errmessage="House Address cannot be empty";
			$errcode[]=1;
		}
		
		if(isset($_POST['ewallet'])){
			$ewallet=trim(clean_strings($_POST['ewallet']));
		}else{
			$ewallet_errmessage="Account Number cannot be empty";
			$errcode[]=1;
		}
	
			if(!empty($errcode)){
				$msgbox="You have ". count($errcode) ." error"; if(count($errcode) >1){ $msgbox.="s";}
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{// state='$state',
				$sql="update users_info set firstname='$firstname', lastname='$lastname', mobile='$mobile', email='$email', account_name='$account_name', gender='$gender', country='$country', account_number='$account_number', bank_name='$bank_name', account_type='$account_type', pin=$pin, dob='$dob', current_available='$ewallet', house_address='$house_address' where username='$user' limit 1";

				mysqli_query($con,$sql);
				//echo mysqli_error($con);
				if(mysqli_affected_rows($con) == 1){
					$msgbox="Updated Successfully";
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("edit_member.php?user=$user");
				}
			}
		
	}
	
	
?>
		
			<div id='log_form'>			
				
				<form action='edit_member.php?user=<?php echo $user;?>' onsubmit='return myFunction("Update USer Profile?")'  method='post' enctype='multipart/form-data'>

					
					<span id='field_title'>First Name</span><br>
					<input type='text' name='firstname' class='text' required value='<?php echo $firstname;?>' placeholder='First Name'>
					<?php echo errmessage_design($firstname_errmessage)?><br>
					
					<span id='field_title'>Last Name</span><br>
					<input type='text' name='lastname' class='text' required value='<?php echo $lastname;?>' placeholder='Last Name'>
					<?php echo errmessage_design($lastname_errmessage)?><br>
					
					<span id='field_title'>Mobile</span><br>
					<input type='text' style='width:100%;' name='mobile' class='text' required value='<?php echo $mobile;?>' placeholder='Mobile'>
					<?php echo errmessage_design($country_code_errmessage)?><?php echo errmessage_design($mobile_errmessage)?>
					
					<span id='field_title'>Email</span><br>
					<input type='email' name='email' class='text' required value='<?php echo $email;?>' placeholder='Email Address'>
					<?php echo errmessage_design($email_errmessage)?><br>
					
					<span id='field_title'>Gender</span><br>          
					<select name='gender' class='text'>";
						<option>Male</option>
						<option>Female</option>
					</select>
					<?php echo errmessage_design($gender_errmessage)?><br>
					
					<span id='field_title'>Country</span><br>          
					<select name='country' class='text'>";
					
					<?php
						echo "<option>$country</option>";
						$countries=array('Nigeria');
						sort($countries);
						for($i=0;$i<count($countries);$i++){
							echo "<option>{$countries[$i]}</option>";
						}
					?>
					
					</select>
					<?php echo errmessage_design($country_errmessage)?><br>
					
			<!-- 		<span id='field_title'>State</span><br>          
					<select name='state' class='text'>";
					
					<?php
						echo "<option>$state</option>";
						$states=array('Lagos', 'Imo');
						sort($states);
						for($i=0;$i<count($states);$i++){
							echo "<option>{$states[$i]}</option>";
						}
					?>
					
					</select>
					<?php echo errmessage_design($state_errmessage)?><br>
					 -->
					<span id='field_title'>Account Number</span><br>
					<input type='text' name='account_number' onblur='check_existence(2)' class='text' value='<?php echo $account_number;?>' placeholder='Account Number'>  
					<?php echo errmessage_design($account_number_errmessage)?><br>
				
					<span class='field_title'>Account Type</span><br> 
					<select name='account_type' class='text'>
						<option><?php echo $account_type;?></option>
						<option>Savings</option>
						<option>Current</option>
					</select>
					<?php echo errmessage_design($account_type_errmessage)?><br>
					 
					 <span id='field_title'>PIN</span><br>
					<input type='number' minlength='4' maxlength='4' name='pin' class='text' required value='<?php echo $pin;?>' placeholder='PIN'>
					<?php echo errmessage_design($pin_errmessage)?><br>
					
					<span id='field_title'>DOB</span><br>
					<input type='text' name='dob' class='text' required value='<?php echo $dob;?>' placeholder='DOB'>
					<?php echo errmessage_design($dob_errmessage)?><br>
					
					<span id='field_title'>House Address</span><br>
					<textarea name='house_address' class='text' required placeholder='House Address'><?php echo $house_address;?></textarea>
					<?php echo errmessage_design($house_address_errmessage)?><br>
					
					<span id='field_title'> Account Balance </span><br>
					<input type='number' name='ewallet' class='text' required value='<?php echo $ewallet;?>' placeholder='Account Balance'>
					<?php echo errmessage_design($ewallet_errmessage)?><br>
					
					<button type='submit' name='update' class='btn upd' style='float:none; width:auto;'>Update Account</button><br>
				</form>
		</div>
 </div>

<script type='text/javascript'>
	function show_menu(){
		var mobile_menu=document.getElementById('mobile_menu').style.display;
		if(mobile_menu!='inline-block'){
			document.getElementById('mobile_menu').style.display='inline-block';
			document.getElementById('menu_bar_holder').style.backgroundColor='1034A6';
			
		}else{
			document.getElementById('mobile_menu').style.display='none';
			document.getElementById('menu_bar_holder').style.backgroundColor='1034A6';
		}
	}	

	/*  */
	  
</script>
<?php 
include("includes/admin_foot.php");
?>