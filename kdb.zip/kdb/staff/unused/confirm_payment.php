<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<div id="inner-frame">
			<div id='log_form'> 
			<div class='page_title' style='margin:0;'>
				Confirm Deposit 	
			</div>
			<?php
				if(isset($_POST['verify'])){
					$referral=trim(clean_strings($_POST['referral']));
					$username=trim(clean_strings($_POST['username']));
					$fullname=trim(clean_strings($_POST['fullname']));
					 
					mysqli_query($con, "update users_info set verified='Yes' where username='$username'");
					if(mysqli_affected_rows($con)==1){
						mysqli_query($con, "insert into transactions (fullname, username, amount, description, status) values ('$fullname', '$username', 5000, 'Registration Fee', 'verified')");
						if($referral=='afriposter'){
							echo null;
						}else{
							mysqli_query($con, "update users_info set ewallet=ewallet + 2400, num_downline=num_downline + 1 where username='$referral'");
						}
						setcookie("success","Confirmed Successfully",time() + (3600*5),"/");
						redirect_to("verify_payment");
					}
				}
			?>
			<table class='pay'>
				<tr class='pay'>
					<th class='pay'>S/N</th>
					<th class='pay'>Username</th>
					<th class='pay'>fullname</th>
					<th class='pay'>Date</th>
					<th class='pay'>POP</th>
					<th class='pay'>Action</th>
				</tr>
				
			<?php 
				$i=1;
				$sql="select username, firstname, lastname, date_joined, pop, referral from users_info where verified='No' and pop<>'' order by date_joined desc";
				$query=mysqli_query($con, $sql);
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
					<tr class='pay'>	
						<td class='pay'><?php echo $i?></td>
						<td class='pay'><?php echo $out['username']?></td>
						<td class='pay'><?php echo $out['firstname']." ".$out['lastname']?></td>
						<td class='pay'><?php echo $out['date_joined']?></td>
						<td class='pay'><img src='<?php echo $out['pop']?>' width='70' style='cursor:pointer;' onclick="showImage('<?php echo $out['pop']?>')"></td>
						<td class='pay'>
							<form action='' method='post' onsubmit='return myFunction("Verify?")' enctype='multipart/form-data'>
								<input type='hidden' value='<?php echo $out['firstname']." ".$out['lastname']?>' name='fullname'>
								<input type='hidden' value='<?php echo $out['username']?>' name='username'>
								<input type='hidden' value='<?php echo $out['referral']?>' name='referral'>
								<?php
									if($out['referral']=='afriposter'){
								?>
										<a href="place_users"><span title="User has no referral. Place user under a referral before activating user's account" class='btn del'>Place User</span></a>
								<?php
									}else{
								?>
										<button class='btn upd' name='verify'>Verify</button>
								<?php
									}
								?>
								
							</form>
						</td>
					</tr>	
			<?php
						$i++;
					}
				}else{
			?>
					<tr class='pay'>	
						<td class='pay' colspan='6'>Empty</td>
					</tr>
			<?php
				}
			?>
			</table>
				
		</div>
		</div>
<?php 
include("includes/admin_foot.php");
?>