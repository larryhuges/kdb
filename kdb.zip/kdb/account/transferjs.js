const pages = document.querySelectorAll('.tfPage')

document.addEventListener('DOMContentLoaded', () => {
  pages[0].style.display = 'block'
  pages[0].style.animation = 'showPage 1s ease'
  setTimeout(function () {
    pages[0].style.animation = 'unset'
  }, 1000)
})

function openPopUP(id) {
  const box = document.querySelector(id)
  box.style.display = 'flex'
  box.style.animation = 'showPage 1s ease'
  setTimeout(function () {
    box.style.animation = 'unset'
  }, 1000)
}

function closePopUP(id) {
  document.querySelector(id).style.display = 'none'
}

function loadPage(id) {
  const pages = document.querySelectorAll('.tfPage')
  pages.forEach((page) => {
    page.style.display = 'none'
  })
  pages[id].style.display = 'block'
  pages[id].style.animation = 'showPage 1s ease'
  setTimeout(function () {
    pages[id].style.animation = 'unset'
  }, 1000)
}

function selectRD(id) {
  const bank = document.querySelectorAll('[rdBank]')[id].innerHTML
  const acc = document.querySelectorAll('[rdAccountNumber]')[id].innerHTML
  document.querySelector('#t_accNum').value = acc
  document.querySelector('[selectBN]').innerHTML = bank
  document.querySelector('#t_to').value = bank
}

document.querySelectorAll('.sbBank').forEach((bank) => {
  bank.addEventListener('click', () => {
    document.querySelector('[selectBN]').innerHTML =
      bank.getAttribute('bankName')
    document.querySelector('#t_to').value = bank.getAttribute('bankName')
    closePopUP('#bankList')
  })
})

document.querySelectorAll('.preAmount p').forEach((x) => {
  x.addEventListener('click', () => {
    document.querySelector('#t_amount').value = x.getAttribute('data-v')
  })
})

function popWire() {
  document.querySelector('#wire_holder').style.display = 'block'
}

function closeWire() {
  document.querySelector('#wire_holder').style.display = 'none'
}

function pop_send_money() {
  document.querySelectorAll('.pages').forEach((p) => {
    p.style.display = 'none'
  })
  document.querySelector('#page2').style.display = 'block'
}

const wirePages = document.querySelectorAll('.pages')
document.addEventListener('DOMContentLoaded', () => {
  // wirePages[0].style.display = 'block'
  console.log('n')
})

function cancel_funding() {
  document.querySelectorAll('.pages').forEach((p) => {
    p.style.display = 'none'
  })
  document.querySelector('#page1').style.display = 'block'
}

let form_ = document.querySelector('#form_')
form_.addEventListener('submit', async (e) => {
  e.preventDefault()
  console.log(document.querySelector('#t_to').value)
  document.querySelector('#selectedAccount').innerHTML =
    document.querySelector('#t_from').value
  document.querySelector('#selectedAccount2').innerHTML =
    document.querySelector('#t_from').value
  document.querySelector('#toPaybank').innerHTML =
    document.querySelector('#t_to').value
  document.querySelector('#toPaybank2').innerHTML =
    document.querySelector('#t_to').value
  document.querySelector('#toPayAccount').innerHTML =
    document.querySelector('#t_accNum').value
  document.querySelector('#toPayAccount2').innerHTML =
    document.querySelector('#t_accNum').value
  loadPage(1)
})

async function sendCode() {
  let loader = document.querySelector('#jexjs-indicator-wrap')
  loader.style.display = 'block'

  const response = await fetch('sendCode.php')
  let result = await response.text()
  console.log(response, result)

  if (response.ok && result.trim() == 'OK') {
    openPopUP('#OTPBox')
  } else {
    alert('Error Sending Code')
  }
  loader.style.display = 'none'
}

async function confirmCode() {
  let confirmCode = ''

  document.querySelectorAll('.confirmCodeText').forEach((t) => {
    confirmCode = confirmCode + '' + t.value
  })

  let loader = document.querySelector('#jexjs-indicator-wrap')

  let fd = new FormData()
  fd.append('confirmCode', confirmCode)

  const options = {
    method: 'POST',
    body: fd,
  }

  loader.style.display = 'block'

  const response = await fetch('confirmCode.php', options)
  let result = await response.text()
  console.log(response, result)

  if (response.ok && result.trim() == 'OK') {
    closePopUP('#OTPBox')
    transfer_fund()
  } else {
    alert('Invalid Code')
    loader.style.display = 'none'
  }
}

async function transfer_fund() {
  let t_from = document.querySelector('#t_from')
  let t_pin = document.querySelector('#t_pin')
  let t_to = document.querySelector('#t_to')
  let t_accNum = document.querySelector('#t_accNum')
  let t_amount = document.querySelector('#t_amount')
  let t_date = document.querySelector('#t_date')
  let t_memo = document.querySelector('#t_memo')
  let loader = document.querySelector('#jexjs-indicator-wrap')

  let fd = new FormData()
  fd.append('t_from', t_from.value)
  fd.append('t_pin', t_pin.value)
  fd.append('t_to', t_to.value)
  fd.append('t_accNum', t_accNum.value)
  fd.append('t_amount', t_amount.value)
  fd.append('t_date', t_date.value)
  fd.append('t_memo', t_memo.value)

  const options = {
    method: 'POST',
    body: fd,
  }

  loader.style.display = 'block'

  const response = await fetch('processForm.php', options)
  let result = await response.text()

  console.log(response, result)

  if (response.ok) {
    if (result.trim() == '200') {
      loadPage(2)
    } else if (result.trim() == '500') {
      alert('Error Transferring Funds. Please contact customer care!!!')
    } else if (result.trim() == '400') {
      alert('Insufficiate Funds!!!')
    } else if (result.trim() == '401') {
      alert('Maximum limti of 100,000 exceeded!!!')
    } else if (result.trim() == '404') {
      loadPage(1)
      alert('Incorrect Withdrawal Pin Entered!!!')
    } else {
      alert('Error Transferring Funds. Please contact customer care!!!')
    }
  } else {
    alert('Error Transferring Funds. Please contact customer care!!!')
  }
  loader.style.display = 'none'
}
