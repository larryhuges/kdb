 <div id='frame' style="background-color:#4b4e68; margin-top: 0px;">
		<div id='inner-frame' style='margin-bottom: 0; padding:0px;'>
		
			<div class='col four_col'>
				<div id='foot_menu'>
					
					<a href='contact' class='first'><p class='foot_menu_i' style="color: #dedede; font-size: 14px;"> CONTACT US</p></a>
					
				</div>
			</div>
	
			<div style="float: left; width: 100%; line-height: 1.5; font-size: 14px; color: #dedede; padding: 20px;">
      <p class="contact"> 14 Eunhaeng-ro, Yeongdeungpo-gu, Seoul 07242, Korea  | ☎ Domestic 1588-1500, 1668-1500, Overseas +82-1588-1500, +82-1668-1500</p> 
      <p class="copyright">Copyright ©2023 Korea Development Bank, All rights reserved.</p>
			</div>
		</div>
    </div>

<script type="text/javascript">
	function toggle_menu_id2(id){
		var x=document.getElementById(id);
		if(x.style.display=='block'){
			x.style.animation='hide_menu_scroll_left .5s ease';
			setTimeout(function (){x.style.display='none'},500);
		}else{
			x.style.animation='show_menu_scroll_left .5s ease';
			x.style.display='block';
		}
	}

</script>

</body>
<?php
if(isset($_COOKIE['error']) && !empty($_COOKIE['error'])){
?>
		<script>
			popup("<?php echo $_COOKIE['error'];?>","error");
		</script>
<?php
	setcookie("error","",time() - (3600*50),"/");
}
?>

<?php
if(isset($_COOKIE['success']) && !empty($_COOKIE['success'])){
?>
		<script>
			popup("<?php echo $_COOKIE['success'];?>","added");
		</script>
<?php
	setcookie("success","",time() - (3600*50),"/");
}
?>
</html>
<?php 
//	mysqli_close($con);
	ob_end_flush();
?>