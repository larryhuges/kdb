<?php

	require_once("connection.php");

	function redirect_to($location){
		header("Location: ".$location); 
		exit();
	}

	function base_url(){
		return "http://kdb.com/";
		//return "https://www.uskeyvest.com/";
	}

	function page_header($title, $img){
		$output="";
		$output="<div id='frame' style='background:#f8f9fb url(\"$img\") center; background-size: cover; z-index: 2; box-shadow: 0px 3px 1px #000;'>
			<div id='inner-frame' style='max-width: 950px;'>
				<p class='page_title' style='color:#fff; padding: 20px;'>
					$title
				</p>
			</div>
		</div>";
		return $output;
	}


	function clean_strings($strings){
		global $con;
		$active=get_magic_quotes_gpc();
		$new=function_exists("mysqli_real_escape_string");
		
		if($new){
			if($active){
				$strings=stripslashes($strings);
			}
			$strings=htmlspecialchars(mysqli_real_escape_string($con,$strings));
		}else{
			if(!$active){
				$strings=htmlspecialchars(addslashes($strings));
			}
		}
		return trim($strings);
	}

	function replaced_string($id,$str){
		$string_rep=$id."/".strtolower(str_replace(array("?","/"," ","\\","."),array("-","-","-","-",""),$str));
		return $string_rep;
	}

	function per_page(){
		return 5;
	}

	function admin_pagination($table,$linked_to){
		
		global $con;
			
		$per_page=per_page();
		
		$output="";
		$q=mysqli_query($con,"select id from $table");
		$rows=mysqli_affected_rows($con);
		
		if($rows>$per_page){
			$pages=ceil($rows/$per_page);
			
				for($j=1;$j<=$pages;$j++){
					$output.="<a href='$linked_to$j'><span class='pagination_number'>$j</span></a>";
				}
		}
		return $output;
	}

	function member_pagination($table,$linked_to,$user){
		
		global $con;
		
		$per_page=per_page();
		//$filter=filter_published();
		$output="";
		$q=mysqli_query($con,"select id from $table where $user='{$_SESSION['member_username']}'");
		$rows=mysqli_affected_rows($con);
		
		if($rows>$per_page){
			$pages=ceil($rows/$per_page);
			
				for($j=1;$j<=$pages;$j++){
					$output.="<a href='$linked_to$j'><span class='pagination_number'>$j</span></a>";
				}
		}
		return $output;
	}

	function pagination($table,$linked_to){
		
		global $con;
		
		$filter=filter_published();
		
		$per_page=per_page();
		
		$output="";
		$q=mysqli_query($con,"select id from $table where 1=1$filter");
		$rows=mysqli_affected_rows($con);
		
		if($rows>$per_page){
			$pages=ceil($rows/$per_page);
			
				for($j=1;$j<=$pages;$j++){
					$output.="<a href='$linked_to$j'><span class='pagination_number'>$j</span></a>";
				}
		}
		return $output;
	}


	function remove_unwanted_tags($strs){
		$tags="<h1><h2><h3><h4><h5><h6><i><b><strong><br><br/><cite><li><ul><ol><sub><sup>";
		$s=strip_tags($strs,$tags);
		return str_replace("\r\n","<br>",$s);
	}


	function filter_published(){
	
		global $con;

		$act=mysqli_query($con,"select publish from rbps_actions");
		$q_act=mysqli_fetch_assoc($act);
		if($q_act['publish']=='FILTER'){
			$filter=" and published='Yes'";
		}else{
			$filter="";
		}
		return $filter;
	}

	function gen_latest_post_list($order, $cat, $limit){
		
		global $con;
		
		if(empty($cat)){
			$category="";
		}else{
			$category=" and post_category='$cat'";
		}

		$filter=filter_published();
		
		$sql="select * from rbps_posts where 1=1$filter$category order by $order limit $limit";
		$query=mysqli_query($con,$sql);
		$output="";
		while($out=mysqli_fetch_assoc($query)){
			if(!empty($out['photo1'])){
				$url=strtolower($out['photo1']);
			}else{
				$url="images/d2.jpg";
			}
			$vid=$out['video'];
			$link=replaced_string($out['id'],$out['post_title']);
			$output.="
				<div class='news_holder'>
				<div class='news_img' style=\"background:transparent url('$url') 
	no-repeat center; background-size:cover;\">";
				
				$output.=" </div><div class='news_content'>
							<p class='news_header'>";
								$output.= $out['post_title'];
								if(!empty($vid)){
									$output.= " <span style='color:red; font-weight:bold;'>[Vid]</span> ";
								}
							$output.="</p>
							<p class='news_body'>".substr($out['post_content'],0,30)."...<br>
								<a href='view_news/$link' class='first' style='font-size:12px;'>Read More</a>
							";
							$output.=formatted_date($out['date_posted']);
							
						$output.="</p></div>
					</div>
				
			";
		}
		$output.="<a href='reports'><button class='btn add'>More News</button></a>";
		
		return $output;
	}

	function gen_latest_events_list($limit){
	
		global $con;

		$filter=filter_published();
		//
		$sql="select * from rbps_posts where 1=1$filter and post_category='events' order by date_posted asc limit $limit";
		$query=mysqli_query($con,$sql);
		$output="";
		while($out=mysqli_fetch_assoc($query)){
			if(!empty($out['photo1'])){
				$url=strtolower($out['photo1']);
			}else{
				$url="images/d2.jpg";
			}
			$vid=$out['video'];
			$link=replaced_string($out['id'],$out['post_title']);
			$output.="
				<div class='news_holder' style='margin:0;'>
				<div class='news_img' style=\"background:transparent url('$url') 
	no-repeat center; background-size:cover;\">";
				
				$output.=" </div><div class='news_content'>
							<p class='news_header'>";
								$output.= $out['post_title'];
								if(!empty($vid)){
									$output.= " <span style='color:red; font-weight:bold;'>[Vid]</span> ";
								}
							$output.="</p>
							<p class='news_body'>".substr($out['post_content'],0,35)."...<br>
								<a href='view_news/$link' style='font-size:12px;' class='first'>Read More</a>
							";
							$output.=formatted_date($out['date_posted']);
							
						$output.="</p></div>
					</div>
				
			";
		}
		$output.="<a href='reports'><button class='btn add'>More News</button></a>";
		
		return $output;
	}

	function gen_latest_post_list_2($limit){
	
		global $con;

		$filter=filter_published();
		
		$sql="select * from rbps_posts where 1=1$filter order by date_posted asc limit $limit";
		$query=mysqli_query($con,$sql);
		$output="";

		while($out=mysqli_fetch_assoc($query)){
			//$url=strtolower($out['photo1']);
			$url="images/d2.jpg";
			$vid=$out['video'];
			$link=replaced_string($out['id'],$out['post_title']);
			$output.="<a href='view_news/$link'>
				<div class='col three_col show_first_frame_col_1' style=\"padding:30px;\">
					<img src='$url' class='slide_image_resize'>
					<div>
						<br>
						<h4 class='col_title'>";
						$output.=substr($out['post_title'],0,30);
						$output.="</h4>
						<br>
						<p class='col_desc'>
							".substr($out['post_content'],0,65)."...<br>
						</p>";
						$output.=formatted_date($out['date_posted']);
					$output.="</div>
				</div>
				";
			
		}
		return $output;
	}

	function gen_latest_tutorial_videos($cat, $limit){
	
		global $con;

		$filter=filter_published();

		if($cat!='all'){
			$where_clause=" where category2='$cat'";
		}else{
			$where_clause="";
		}
		
		$sql="select * from rbps_videos$where_clause order by date_posted asc limit $limit";
		$query=mysqli_query($con,$sql);
		$output="";

		while($out=mysqli_fetch_assoc($query)){
			$img=strtolower($out['photo1']);
			$vid=$out['video'];

			if(empty($img)){
				$url="<iframe style='width:100%; height: 150px;' src='$vid' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
					";
			}else{
				$url="<img src='../$img' class='slide_image_resize'>";
			}
			
			$link=replaced_string($out['id'],$out['title']);
			$output.="
				<div class='col three_col show_first_frame_col_1' style=\"padding:30px;\">
					<div>$url</div>
					<div>
						<br>
						<h4 class='col_title'>";
						$output.=substr($out['title'],0,30);
						$output.="</h4>
						<br>
						<p class='col_desc'>
							".substr($out['description'],0,65)."...<br>
						</p>";
						$output.=formatted_date($out['date_posted']);
					$output.="</div>
				</div>
				";
			
		}
		return $output;
	}

	function gen_latest_books($cat, $limit){
	
		global $con;
		if(isset($limit) && !empty($limit)){
			$limt_va=" limit $limit";
		}else{
			$limit_va="";
		}
		//$filter=filter_published();

		if($cat!='all'){
			$where_clause=" where category2='$cat'";
		}else{
			$where_clause="";
		}
		
		$sql="select * from rbps_books$where_clause order by date_posted asc$limit_va";
		$query=mysqli_query($con,$sql);
		$output="";

		while($out=mysqli_fetch_assoc($query)){
			$img=strtolower($out['book_cover']);
			$book=$out['book_path'];
			$url="<img src='../$img' style='max-height:100%;' alt='$img'>";
			
			$output.="
			<a href='$book'>
				<div class='col four_col show_first_frame_col_1' style=\"padding:30px;\">
					<div style='overflow:hidden; height:100px; text-align:center;'>
						$url
					</div>
					<div style='overflow:hidden; height:100px; text-align:center;'>
						<br>
						<h4 class='col_title'>";
						$output.=substr($out['title'],0,30);
						$output.="</h4>
						<br>
						<p class='col_desc'>
							".substr($out['description'],0,50)."...<br>
						</p>";
						$output.="<p class='col_desc'>
							".formatted_date($out['date_posted'])."<br>
						</p>";
					$output.="</div>
				</div>
			</a>
				";
			
		}
		return $output;
	}

	function latest_info_marquee($page){
		$output="
			<div class='frame'>
				<div class='bread_c'>
					<div style='float:left; width:auto; padding:5px 10px; background:#f00; color:#fff; font-weight:bolder;'>
						<i class='fa fa-home'></i> Portal <span style='color: #fff; font-weight:normal;'>/ $page</span>
					</div>
					<div style='width:calc(100% - 250px); float:right;'>
						<marquee style='width:100%;'> <i class='fa fa-info'></i> Latest Info</span></marquee>
					</div>
				</div>
			</div>
		";
		return $output;
	}

	function latest_staff_info_marquee($page){
		$output="
			<div class='frame'>
				<div class='bread_c'>
					<div style='float:left; width:auto; padding:5px 10px; background:#f00; color:#fff; font-weight:bolder;'>
						<i class='fa fa-home'></i> Staff Portal <span style='color: #fff; font-weight:normal;'>/ $page</span>
					</div>
					<div style='width:calc(100% - 250px); float:right;'>
						<marquee style='width:100%;'> <i class='fa fa-info'></i> Latest Info</span></marquee>
					</div>
				</div>
			</div>
		";
		return $output;
	}

	/*function validate_userInput_strings($name,$str){
		$output=array();
		if(!empty($str) && isset($str)){
			$output[$name]=trim(clean_strings($str));
			if(!preg_match("/^[a-zA-Z]*$/",$output[$name])){
				$output[$name.'_errmessage']="Only alphabets are allowed";
				$output[$name.'_errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output[$name.'_errmessage']="";
				$output[$name.'_errorfound']="";
				$output['error']=0;
			}
		}else{
			$output[$name]="";
			$output[$name.'_errmessage']="$name is required";
			$output[$name.'_errorfound']="errorfound";
			$output['error']=1;
		}
		return $output;
	}*/

	

	function student_list($sql_in, $school){
		$school_management_system=getschoolinfo();
		if($school=='junior secondary' || $school=='senior secondary'){
			if($school_management_system['college_management_system']=='combine'){
				$sql="$sql_in where class='jss' or class='sss'";
			}else{
				if($school=='junior secondary'){
					$sql="$sql_in where class='jss'";
				}else{
					$sql="$sql_in where class='sss'";
				}
			}
		}elseif($school=='primary'){
			if($school_management_system['basic_management_system']=='combine'){
				$sql="$sql_in where class='kg' or class='nur' or class='pry'";
			}
		}else{
			echo null;
		}
		return $sql;
	}

	function generate_admission_no(){
		global $con;
		$i = 1;
		$admission_no="2018075".mt_rand(000,999);
		while($i = 0){
			$admission_no="2018075".mt_rand(000,999);
			$query=mysqli_query($con, "select admission_no from personal_information where admission_no='$admission_no' limit 1");
			if(mysqli_affected_rows($con)>=1){
				continue;
			}else{
				break;
			}
		}
		return $admission_no;
	}

	

	function staff_list($sql_in, $school){
		$school_management_system=getschoolinfo();
		if($school=='junior secondary' || $school=='senior secondary'){
			if($school_management_system['college_management_system']=='combine'){
				$sql="$sql_in where school='junior secondary' or school='senior secondary'";
			}else{
				if($school=='junior secondary'){
					$sql="$sql_in where school='junior secondary'";
				}elseif($school=='senior secondary'){
					$sql="$sql_in where school='senior secondary'";
				}
			}
		}elseif($school=='primary' || $school=='nursery' || $school=='kingdergarten' || $school=='creche'){
			if($school_management_system['basic_management_system']=='combine'){
				$sql="$sql_in where school='primary' or school='nursery' or school='kingdergarten' or school='creche'";
			}else{
				if($school=='primary'){
					$sql="$sql_in where school='primary'";
				}elseif($school=='nursery' || $school=='kingdergarten' || $school=='creche'){
					$sql="$sql_in where school='nursery' or school='kingdergarten' or school='creche'";
				}
			}
		}
		return $sql;
	}

	

	function top_level_management_staff(){
		$output=array('proprietor', 'proprietress', 'director', 'deputy director', 'senior principal', 'junior principal', 'head teacher');
		return $output;
	}
	
	function higher_management_staff(){
		$output=array('proprietor', 'proprietress', 'director', 'deputy director', 'senior principal', 'senior vp admin', 'senior vp academic', 'junior principal', 'junior vp admin', 'junior vp academic', 'head teacher');
		return $output;
	}

	function management_staff(){
		$output=array('proprietor', 'proprietress', 'director', 'deputy director', 'senior principal', 'senior vp admin', 'senior vp academic', 'senior hod science', 'senior hod commercial', 'senior hod art', 'senior hod sports', 'junior principal', 'junior vp admin', 'junior vp academic', 'junior hod science', 'junior hod commercial', 'junior hod art', 'junior hod sports', 'head teacher');
		return $output;
	}

	function academic_staffs(){
		$output=array('proprietor', 'proprietress', 'director', 'deputy director', 'senior principal', 'senior vp admin', 'senior vp academic', 'senior hod science', 'senior hod commercial', 'senior hod art', 'senior hod sports' , 'junior principal', 'junior vp admin', 'junior vp academic', 'junior hod science', 'junior hod commercial', 'junior hod art', 'junior hod sports', 'head teacher', 'class teacher', 'subject teacher', 'contract teacher');
		return $output;
	}


	function zeroforempty($input){
		if(empty($input)){
			return "0";
		}else{
			return $input;
		}
	}

	function validate_userInput_empty($name,$str,$required){
		$output=array();
		if(!empty($str) && isset($str)){
			$output['value']=clean_strings($str);
			$output['errmessage']="";
			$output['errorfound']="";
			$output['error']=0;
		}else{
			if($required==true){
				$output['value']="";
				$output['errmessage']="$name is required";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['value']="";
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}
		return $output;
	}

	function validate_userInput_photo($name,$str,$required,$dir){
		$output=array();
		if(!empty($str['name']) && isset($str['name'])){
			$output['value']=clean_strings($str['name']);
			$filename=basename($output['value']);
			$path=strtolower(str_replace(" ","_","../$dir/rbps_image_".$filename));
			$db_path=strtolower(str_replace(" ","_","$dir/rbps_image_".$filename));
			$output['tmp_name']=$str['tmp_name'];
			$output['path']=$path;
			$output['db_path']=$db_path;
			$type=$str['type'];
			$size=$str['size'];
			
			if($type=='image/jpeg' || $type=='image/jpg' || $type=='image/png'){
				echo null;
			}else{
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="Only image Files (Jpeg, Jpg, Png) are allowed";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}
			
			if($size>2000000){
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="image Size Should be less than 2MB";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}
		}else{
			if($required==true){
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="$name is required";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}
		return $output;
	}

	function validate_userInput_pdf($name,$str,$required,$dir){
		$output=array();
		if(!empty($str['name']) && isset($str['name'])){
			$output['value']=clean_strings($str['name']);
			$filename=basename($output['value']);
			$path=strtolower(str_replace(" ","_","../$dir/rbps_books_".$filename));
			$db_path=strtolower(str_replace(" ","_","$dir/rbps_books_".$filename));
			$output['tmp_name']=$str['tmp_name'];
			$output['path']=$path;
			$output['db_path']=$db_path;
			$type=$str['type'];
			$size=$str['size'];
			
			if($type=='application/pdf'){
				echo null;
			}else{
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="Only PDF Files are allowed";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}
		}else{
			if($required==true){
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="$name is required";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['value']="";
				$output['path']="";
				$output['db_path']="";
				$output['tmp_name']="";
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}
		return $output;
	}

	function validate_userInput_email($str,$required){
		$output=array();
		if(!empty($str) && isset($str)){
			$output['value']=clean_strings($str);
			if(filter_var($output['value'],FILTER_VALIDATE_EMAIL)){
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}else{
				$output['errmessage']="Invalid Email Format";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}
		}else{
			if($required==true){
				$output['value']="";
				$output['errmessage']="Email is required";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['value']="";
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}
		return $output;
	}

	function validate_userInput_number($name,$str,$required){
		$output=array();
		if((!empty($str) || $str!=0) && isset($str)){
			$output['value']=clean_strings($str);
			$preg_match="/^[0-9]*$/";
			$responds="Only numbers are allowed";

			if(!preg_match($preg_match,$output['value'])){
				$output['errmessage']=$responds;
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}else{
			if($required==true){
				$output['value']="";
				$output['errmessage']="$name is required";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['value']="";
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}
		return $output;
	}

	function validate_userInput($name,$str,$input,$required){
		$output=array();
		if((!empty($str) || $str==0) && isset($str)){
			$output['value']=clean_strings($str);
			if($input=='text'){
				$preg_match="/^[a-zA-Z]*$/";
				$responds="Only alphabets are allowed";
			}elseif($input=='text_space'){
				$preg_match="/^[a-zA-Z ]*$/";
				$responds="Only alphabets are allowed";
			}elseif($input=='text_space_dot'){
				$preg_match="/^[\.a-zA-Z ]*$/";
				$responds="Only alphabets are allowed";
			}elseif($input=='alphanumeric_space'){
				$preg_match="/^[a-zA-Z0-9 ]*$/";
				$responds="Only alphabets are allowed";
			}elseif($input=='number'){
				$preg_match="/^[0-9]*$/";
				$responds="Only numbers are allowed";
			}elseif($input=='tel'){
				$preg_match="/^[0-9+]*$/";
				$responds="Only numbers are allowed";
			}elseif($input=='alphanumeric'){
				$preg_match="/^[a-zA-Z0-9]*$/";
				$responds="Only alphabets and/or numbers are allowed";
			}
			if(!preg_match($preg_match,$output['value'])){
				$output['errmessage']=$responds;
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}else{
			if($required==true){
				$output['value']="";
				$output['errmessage']="$name is required";
				$output['errorfound']="errorfound";
				$output['error']=1;
			}else{
				$output['value']="";
				$output['errmessage']="";
				$output['errorfound']="";
				$output['error']=0;
			}
		}
		return $output;
	}

	function fetch_array_data($str){
		$output=array();
		if(isset($str) && !empty($str)){
			$output['value']=$str;
			$output['errmessage']="";
			$output['errorfound']="";
			$output['error']=0;
		}else{
			$output['value']="";
			$output['errmessage']="";
			$output['errorfound']="";
			$output['error']=0;
		}
		return $output;
	}

	function session_value($str){
		if(isset($_SESSION['inputs'][$str]) && !empty($_SESSION['inputs'][$str])){
			return $_SESSION['inputs'][$str]['value'];
		}else{
			return "";
		}
	}

	function session_errmessage($str){
		if(isset($_SESSION['inputs'][$str]) && !empty($_SESSION['inputs'][$str])){
			return $_SESSION['inputs'][$str]['errmessage'];
		}else{
			return "";
		}
	}

	function session_errorfound($str){
		if(isset($_SESSION['inputs'][$str]) && !empty($_SESSION['inputs'][$str])){
			return $_SESSION['inputs'][$str]['errorfound'];
		}else{
			return "";
		}
	}

	function input_value($str){
		global $inputs;
		if(isset($inputs[$str]) && !empty($inputs[$str])){
			return $inputs[$str]['value'];
		}else{
			return "";
		}
	}

	function input_errmessage($str){
		global $inputs;
		if(isset($inputs[$str]) && !empty($inputs[$str])){
			return $inputs[$str]['errmessage'];
		}else{
			return "";
		}
	}

	function input_errorfound($str){
		global $inputs;
		if(isset($inputs[$str]['errorfound']) && !empty($inputs[$str]['errorfound'])){
			return $inputs[$str]['errorfound'];
		}else{
			return "";
		}
	}

	function subject_input_errorfound($admission_no,$subject){
		global $inputs;
		if(isset($inputs[$admission_no][$subject]['errorfound']) && !empty($inputs[$admission_no][$subject]['errorfound'])){
			return $inputs[$admission_no][$subject]['errorfound'];
		}else{
			return "";
		}
	}

	function popup_error_message($message){
		$output="";
		$output="<script>new_reg_popup(\"$message\",'error');</script>";
    	return $output;
	}

	function alert($message){
		$output="";
		$output="<script>alert(\"$message\");</script>";
    	return $output;
	}

	function view_array($message){
		$output="";
		$output="<pre>".print_r($message)."</pre>";
    	return $output;
	}

	function alert_box(){
		echo "
			<div id='popdown' style='z-index: 9999999999999999;'>
				<div id='alert_box_center' style='margin-top: 5%; margin-bottom: 0;'>
					<div id='pop_alert_box' align='center' style='padding: 5% 5% 5% 5%; border-radius: 0;'>
						<img id='message_icon' src='' height='100' /><br>
						<h1 id='message_title' style='width: 100%; padding-bottom: 3%; font-family: page_font_mont; font-size: 20px;'>
						</h1>
						<p id='message' style='color:#555; width: 100%; padding-bottom: 5%; font-family: sans-serif; font-size: 16px; line-height: 1.7;'>
						</p>
						<div align='center'>
							<button type='button' onclick='close_popup()' style='margin:0; padding:10px 20px; font-size: 16px;' class='btn upd'>
								OK
							</button>
						</div>	
					</div>
				</div>
			</div>
		";
	}


	function errmessage_design($message){
		$output="";
		if(!empty($message)){
			$output="
				<span style='color:#f00; font-size:1.2rem; font-style:italic;'>$message</span>
			";
		}
		return $output;
	}


	function formatted_date($raw_date){
		$mar_date=strtotime($raw_date);
		$secs=ceil((time()-$mar_date));
		$mins=ceil((time()-$mar_date)/60);
		$hours=ceil((time()-$mar_date)/60/60);
		$days=ceil((time()-$mar_date)/60/60/24);
		
		$duration="";
		$value="";

			if($secs<=30){
				$value='Now';
				$duration='';
			}elseif($secs>30 && $secs<59){
				$value=' secs ago';
				$duration=$secs;
			}elseif($mins<=1){
				$value=' min ago';
				$duration=$mins;
			}elseif($mins>1 && $mins<59){
				$value=' mins ago';
				$duration=$mins;
			}elseif($hours<=1){
				$value=' hour ago';
				$duration=$hours;
			}elseif($hours>1 && $hours<24){
				$value=' hours ago';
				$duration=$hours;
			}elseif($days>1 && $days<3){
				$value='Yesterday';
				$duration='';
			}elseif($days>2 && $days<7){
				$value=' days ago';
				$duration=$days;
			}elseif($days>=7 && $days<=30){
				
				$weeks=floor($days / 7);
				if($weeks<=1){
					$value='A week ago';
					$duration='';
				}elseif($weeks>1){
					$value=' weeks ago';
					$duration=$weeks;
				}
				
			}elseif($days>30 && $days<365){
				$value='';
				$duration=date("F, Y",strtotime($raw_date));
			}elseif($days>=365){
				$value='';
				$duration=date("F, Y",strtotime($raw_date));
			}
		$formatted_date="<span style='color:#3b3; font-size:12px;'><i class='fa fa-clock-o'></i></span> ".$duration.$value;
		return $formatted_date;
	} 

	/*function promote_student_pry_junior_sec($class_name, $annex){
		$output = array();
		if($class_name == 'creche'){
			$class_n = $class_name;
		}else{
			$class_n = substr($class_name, 0, (strlen($class_name) - 1));
		}
		$all_classes = getallclasses();
		$i = 0;
		foreach ($all_classes as $p_class => $cname) {
			if($class_n == $cname){
				$j = $i + 1;
				$n_class = $all_classes[$j];
				$max_no_spc = getmaxnumofstudentsperclass($n_class);
				
				$avail_classes = getlikeclasses($n_class, $annex);
			
				foreach ($avail_classes as $class_ => $value) {
					if($value == "Error"){
						$output['status'] = false;
						break;
					}elseif($value == "Empty"){
						$class_section = substr($class_name, (strlen($class_name) - 1));
						$output['new_class'] = strtolower($n_class);
						$output['new_class_section'] = strtoupper($class_section);
						$output['new_class_code'] = strtolower($n_class.$class_section);
						$output['status'] = true;
						break;
					}else{
						$t_no_std = getnoofstudentsperclass($value, $annex);
						if($t_no_std < $max_no_spc){
							$class_section = substr($value, (strlen($value) - 1));
							$output['new_class'] = strtolower($n_class);
							$output['new_class_section'] = strtoupper($class_section);
							$output['new_class_code'] = strtolower($value);
							$output['t_no_std'] = $t_no_std;
							$output['status'] = true;
							break;
						}else{
							$output['status'] = false;
						}
					}
				}
				break;
			}
			$i++;
		}	
		
		return $output;
		/*foreach ($all_classes as $p_class => $cname) {
			if($class_name == $cname){
				$j = $i + 1;
				$n_class = substr($all_classes[$j], 0);
				$avail_classes = getlikeclasses($n_class, $annex);
				foreach ($avail_classes as $class_ => $value) {
					$gnospc = getnoofstudentsperclass($value, $annex);
					if($gnospc < $t_no_std){
						$new_class = $value;
						break;
					}
				}
			}
			$i++;
		}	*/
	//}*/

	function promote_student($class_name){
		$output = array();
		if(substr($class_name, 0, (strlen($class_name) - 1)) == 'jss 3'){
			$output['new_class'] = "sss 1";
			$output['new_class_section'] = "A";
			$output['new_class_code'] = "sss 1a";
			$output['status'] = true;
		}else{
			if($class_name == 'creche'){
				$class_n = $class_name;
			}else{
				$class_n = substr($class_name, 0, (strlen($class_name) - 1));
			}
			$all_classes = getallclasses();
			$i = 0;
			foreach ($all_classes as $p_class => $cname) {
				if($class_n == $cname){
					$j = $i + 1;
					$n_class = $all_classes[$j];
					
					$class_section = substr($class_name, (strlen($class_name) - 1));
					$output['new_class'] = strtolower($n_class);
					$output['new_class_section'] = strtoupper($class_section);
					$output['new_class_code'] = strtolower($n_class.$class_section);
					$output['status'] = true;
					break;
				}
				$i++;
			}	
		}
		
		return $output;
	}

	/*function promote_student_senior_sec($class_name, $admission_no, $annex){
		$class_n = substr($class_name, 0, (strlen($class_name) - 1));
		$class_section = substr($class_name, (strlen($class_name) - 1));
		$all_classes = array("sss 1", "sss 2", "sss 3");
		$i = 0;
		foreach ($all_classes as $p_class => $cname) {
			if($class_n == $cname){
				$j = $i + 1;
				$n_class = $all_classes[$j];

				$class_section = substr($class_name, (strlen($class_name) - 1));
				$output['new_class'] = strtolower($n_class);
				$output['new_class_section'] = strtoupper($class_section);
				$output['new_class_code'] = strtolower($n_class.$class_section);
				$output['status'] = true;
				break;
			}
			$i++;
		}	
		
		return $new_class;
	}*/
	
	function countries_code(){
		$countries = [];
		$countries[] = array("code" => "AF", "name" => "Afghanistan", "d_code" => "+93");
		$countries[] = array("code" => "AL", "name" => "Albania", "d_code" => "+355");
		$countries[] = array("code" => "DZ", "name" => "Algeria", "d_code" => "+213");
		$countries[] = array("code" => "AS", "name" => "American Samoa", "d_code" => "+1");
		$countries[] = array("code" => "AD", "name" => "Andorra", "d_code" => "+376");
		$countries[] = array("code" => "AO", "name" => "Angola", "d_code" => "+244");
		$countries[] = array("code" => "AI", "name" => "Anguilla", "d_code" => "+1");
		$countries[] = array("code" => "AG", "name" => "Antigua", "d_code" => "+1");
		$countries[] = array("code" => "AR", "name" => "Argentina", "d_code" => "+54");
		$countries[] = array("code" => "AM", "name" => "Armenia", "d_code" => "+374");
		$countries[] = array("code" => "AW", "name" => "Aruba", "d_code" => "+297");
		$countries[] = array("code" => "AU", "name" => "Australia", "d_code" => "+61");
		$countries[] = array("code" => "AT", "name" => "Austria", "d_code" => "+43");
		$countries[] = array("code" => "AZ", "name" => "Azerbaijan", "d_code" => "+994");
		$countries[] = array("code" => "BH", "name" => "Bahrain", "d_code" => "+973");
		$countries[] = array("code" => "BD", "name" => "Bangladesh", "d_code" => "+880");
		$countries[] = array("code" => "BB", "name" => "Barbados", "d_code" => "+1");
		$countries[] = array("code" => "BY", "name" => "Belarus", "d_code" => "+375");
		$countries[] = array("code" => "BE", "name" => "Belgium", "d_code" => "+32");
		$countries[] = array("code" => "BZ", "name" => "Belize", "d_code" => "+501");
		$countries[] = array("code" => "BJ", "name" => "Benin", "d_code" => "+229");
		$countries[] = array("code" => "BM", "name" => "Bermuda", "d_code" => "+1");
		$countries[] = array("code" => "BT", "name" => "Bhutan", "d_code" => "+975");
		$countries[] = array("code" => "BO", "name" => "Bolivia", "d_code" => "+591");
		$countries[] = array("code" => "BA", "name" => "Bosnia and Herzegovina", "d_code" => "+387");
		$countries[] = array("code" => "BW", "name" => "Botswana", "d_code" => "+267");
		$countries[] = array("code" => "BR", "name" => "Brazil", "d_code" => "+55");
		$countries[] = array("code" => "IO", "name" => "British Indian Ocean Territory", "d_code" => "+246");
		$countries[] = array("code" => "VG", "name" => "British Virgin Islands", "d_code" => "+1");
		$countries[] = array("code" => "BN", "name" => "Brunei", "d_code" => "+673");
		$countries[] = array("code" => "BG", "name" => "Bulgaria", "d_code" => "+359");
		$countries[] = array("code" => "BF", "name" => "Burkina Faso", "d_code" => "+226");
		$countries[] = array("code" => "MM", "name" => "Burma Myanmar", "d_code" => "+95");
		$countries[] = array("code" => "BI", "name" => "Burundi", "d_code" => "+257");
		$countries[] = array("code" => "KH", "name" => "Cambodia", "d_code" => "+855");
		$countries[] = array("code" => "CM", "name" => "Cameroon", "d_code" => "+237");
		$countries[] = array("code" => "CA", "name" => "Canada", "d_code" => "+1");
		$countries[] = array("code" => "CV", "name" => "Cape Verde", "d_code" => "+238");
		$countries[] = array("code" => "KY", "name" => "Cayman Islands", "d_code" => "+1");
		$countries[] = array("code" => "CF", "name" => "Central African Republic", "d_code" => "+236");
		$countries[] = array("code" => "TD", "name" => "Chad", "d_code" => "+235");
		$countries[] = array("code" => "CL", "name" => "Chile", "d_code" => "+56");
		$countries[] = array("code" => "CN", "name" => "China", "d_code" => "+86");
		$countries[] = array("code" => "CO", "name" => "Colombia", "d_code" => "+57");
		$countries[] = array("code" => "KM", "name" => "Comoros", "d_code" => "+269");
		$countries[] = array("code" => "CK", "name" => "Cook Islands", "d_code" => "+682");
		$countries[] = array("code" => "CR", "name" => "Costa Rica", "d_code" => "+506");
		$countries[] = array("code" => "CI", "name" => "Côte d'Ivoire", "d_code" => "+225");
		$countries[] = array("code" => "HR", "name" => "Croatia", "d_code" => "+385");
		$countries[] = array("code" => "CU", "name" => "Cuba", "d_code" => "+53");
		$countries[] = array("code" => "CY", "name" => "Cyprus", "d_code" => "+357");
		$countries[] = array("code" => "CZ", "name" => "Czech Republic", "d_code" => "+420");
		$countries[] = array("code" => "CD", "name" => "Democratic Republic of Congo", "d_code" => "+243");
		$countries[] = array("code" => "DK", "name" => "Denmark", "d_code" => "+45");
		$countries[] = array("code" => "DJ", "name" => "Djibouti", "d_code" => "+253");
		$countries[] = array("code" => "DM", "name" => "Dominica", "d_code" => "+1");
		$countries[] = array("code" => "DO", "name" => "Dominican Republic", "d_code" => "+1");
		$countries[] = array("code" => "EC", "name" => "Ecuador", "d_code" => "+593");
		$countries[] = array("code" => "EG", "name" => "Egypt", "d_code" => "+20");
		$countries[] = array("code" => "SV", "name" => "El Salvador", "d_code" => "+503");
		$countries[] = array("code" => "GQ", "name" => "Equatorial Guinea", "d_code" => "+240");
		$countries[] = array("code" => "ER", "name" => "Eritrea", "d_code" => "+291");
		$countries[] = array("code" => "EE", "name" => "Estonia", "d_code" => "+372");
		$countries[] = array("code" => "ET", "name" => "Ethiopia", "d_code" => "+251");
		$countries[] = array("code" => "FK", "name" => "Falkland Islands", "d_code" => "+500");
		$countries[] = array("code" => "FO", "name" => "Faroe Islands", "d_code" => "+298");
		$countries[] = array("code" => "FM", "name" => "Federated States of Micronesia", "d_code" => "+691");
		$countries[] = array("code" => "FJ", "name" => "Fiji", "d_code" => "+679");
		$countries[] = array("code" => "FI", "name" => "Finland", "d_code" => "+358");
		$countries[] = array("code" => "FR", "name" => "France", "d_code" => "+33");
		$countries[] = array("code" => "GF", "name" => "French Guiana", "d_code" => "+594");
		$countries[] = array("code" => "PF", "name" => "French Polynesia", "d_code" => "+689");
		$countries[] = array("code" => "GA", "name" => "Gabon", "d_code" => "+241");
		$countries[] = array("code" => "GE", "name" => "Georgia", "d_code" => "+995");
		$countries[] = array("code" => "DE", "name" => "Germany", "d_code" => "+49");
		$countries[] = array("code" => "GH", "name" => "Ghana", "d_code" => "+233");
		$countries[] = array("code" => "GI", "name" => "Gibraltar", "d_code" => "+350");
		$countries[] = array("code" => "GR", "name" => "Greece", "d_code" => "+30");
		$countries[] = array("code" => "GL", "name" => "Greenland", "d_code" => "+299");
		$countries[] = array("code" => "GD", "name" => "Grenada", "d_code" => "+1");
		$countries[] = array("code" => "GP", "name" => "Guadeloupe", "d_code" => "+590");
		$countries[] = array("code" => "GU", "name" => "Guam", "d_code" => "+1");
		$countries[] = array("code" => "GT", "name" => "Guatemala", "d_code" => "+502");
		$countries[] = array("code" => "GN", "name" => "Guinea", "d_code" => "+224");
		$countries[] = array("code" => "GW", "name" => "Guinea-Bissau", "d_code" => "+245");
		$countries[] = array("code" => "GY", "name" => "Guyana", "d_code" => "+592");
		$countries[] = array("code" => "HT", "name" => "Haiti", "d_code" => "+509");
		$countries[] = array("code" => "HN", "name" => "Honduras", "d_code" => "+504");
		$countries[] = array("code" => "HK", "name" => "Hong Kong", "d_code" => "+852");
		$countries[] = array("code" => "HU", "name" => "Hungary", "d_code" => "+36");
		$countries[] = array("code" => "IS", "name" => "Iceland", "d_code" => "+354");
		$countries[] = array("code" => "IN", "name" => "India", "d_code" => "+91");
		$countries[] = array("code" => "ID", "name" => "Indonesia", "d_code" => "+62");
		$countries[] = array("code" => "IR", "name" => "Iran", "d_code" => "+98");
		$countries[] = array("code" => "IQ", "name" => "Iraq", "d_code" => "+964");
		$countries[] = array("code" => "IE", "name" => "Ireland", "d_code" => "+353");
		$countries[] = array("code" => "IL", "name" => "Israel", "d_code" => "+972");
		$countries[] = array("code" => "IT", "name" => "Italy", "d_code" => "+39");
		$countries[] = array("code" => "JM", "name" => "Jamaica", "d_code" => "+1");
		$countries[] = array("code" => "JP", "name" => "Japan", "d_code" => "+81");
		$countries[] = array("code" => "JO", "name" => "Jordan", "d_code" => "+962");
		$countries[] = array("code" => "KZ", "name" => "Kazakhstan", "d_code" => "+7");
		$countries[] = array("code" => "KE", "name" => "Kenya", "d_code" => "+254");
		$countries[] = array("code" => "KI", "name" => "Kiribati", "d_code" => "+686");
		$countries[] = array("code" => "XK", "name" => "Kosovo", "d_code" => "+381");
		$countries[] = array("code" => "KW", "name" => "Kuwait", "d_code" => "+965");
		$countries[] = array("code" => "KG", "name" => "Kyrgyzstan", "d_code" => "+996");
		$countries[] = array("code" => "LA", "name" => "Laos", "d_code" => "+856");
		$countries[] = array("code" => "LV", "name" => "Latvia", "d_code" => "+371");
		$countries[] = array("code" => "LB", "name" => "Lebanon", "d_code" => "+961");
		$countries[] = array("code" => "LS", "name" => "Lesotho", "d_code" => "+266");
		$countries[] = array("code" => "LR", "name" => "Liberia", "d_code" => "+231");
		$countries[] = array("code" => "LY", "name" => "Libya", "d_code" => "+218");
		$countries[] = array("code" => "LI", "name" => "Liechtenstein", "d_code" => "+423");
		$countries[] = array("code" => "LT", "name" => "Lithuania", "d_code" => "+370");
		$countries[] = array("code" => "LU", "name" => "Luxembourg", "d_code" => "+352");
		$countries[] = array("code" => "MO", "name" => "Macau", "d_code" => "+853");
		$countries[] = array("code" => "MK", "name" => "Macedonia", "d_code" => "+389");
		$countries[] = array("code" => "MG", "name" => "Madagascar", "d_code" => "+261");
		$countries[] = array("code" => "MW", "name" => "Malawi", "d_code" => "+265");
		$countries[] = array("code" => "MY", "name" => "Malaysia", "d_code" => "+60");
		$countries[] = array("code" => "MV", "name" => "Maldives", "d_code" => "+960");
		$countries[] = array("code" => "ML", "name" => "Mali", "d_code" => "+223");
		$countries[] = array("code" => "MT", "name" => "Malta", "d_code" => "+356");
		$countries[] = array("code" => "MH", "name" => "Marshall Islands", "d_code" => "+692");
		$countries[] = array("code" => "MQ", "name" => "Martinique", "d_code" => "+596");
		$countries[] = array("code" => "MR", "name" => "Mauritania", "d_code" => "+222");
		$countries[] = array("code" => "MU", "name" => "Mauritius", "d_code" => "+230");
		$countries[] = array("code" => "YT", "name" => "Mayotte", "d_code" => "+262");
		$countries[] = array("code" => "MX", "name" => "Mexico", "d_code" => "+52");
		$countries[] = array("code" => "MD", "name" => "Moldova", "d_code" => "+373");
		$countries[] = array("code" => "MC", "name" => "Monaco", "d_code" => "+377");
		$countries[] = array("code" => "MN", "name" => "Mongolia", "d_code" => "+976");
		$countries[] = array("code" => "ME", "name" => "Montenegro", "d_code" => "+382");
		$countries[] = array("code" => "MS", "name" => "Montserrat", "d_code" => "+1");
		$countries[] = array("code" => "MA", "name" => "Morocco", "d_code" => "+212");
		$countries[] = array("code" => "MZ", "name" => "Mozambique", "d_code" => "+258");
		$countries[] = array("code" => "NA", "name" => "Namibia", "d_code" => "+264");
		$countries[] = array("code" => "NR", "name" => "Nauru", "d_code" => "+674");
		$countries[] = array("code" => "NP", "name" => "Nepal", "d_code" => "+977");
		$countries[] = array("code" => "NL", "name" => "Netherlands", "d_code" => "+31");
		$countries[] = array("code" => "AN", "name" => "Netherlands Antilles", "d_code" => "+599");
		$countries[] = array("code" => "NC", "name" => "New Caledonia", "d_code" => "+687");
		$countries[] = array("code" => "NZ", "name" => "New Zealand", "d_code" => "+64");
		$countries[] = array("code" => "NI", "name" => "Nicaragua", "d_code" => "+505");
		$countries[] = array("code" => "NE", "name" => "Niger", "d_code" => "+227");
		$countries[] = array("code" => "NG", "name" => "Nigeria", "d_code" => "+234");
		$countries[] = array("code" => "NU", "name" => "Niue", "d_code" => "+683");
		$countries[] = array("code" => "NF", "name" => "Norfolk Island", "d_code" => "+672");
		$countries[] = array("code" => "KP", "name" => "North Korea", "d_code" => "+850");
		$countries[] = array("code" => "MP", "name" => "Northern Mariana Islands", "d_code" => "+1");
		$countries[] = array("code" => "NO", "name" => "Norway", "d_code" => "+47");
		$countries[] = array("code" => "OM", "name" => "Oman", "d_code" => "+968");
		$countries[] = array("code" => "PK", "name" => "Pakistan", "d_code" => "+92");
		$countries[] = array("code" => "PW", "name" => "Palau", "d_code" => "+680");
		$countries[] = array("code" => "PS", "name" => "Palestine", "d_code" => "+970");
		$countries[] = array("code" => "PA", "name" => "Panama", "d_code" => "+507");
		$countries[] = array("code" => "PG", "name" => "Papua New Guinea", "d_code" => "+675");
		$countries[] = array("code" => "PY", "name" => "Paraguay", "d_code" => "+595");
		$countries[] = array("code" => "PE", "name" => "Peru", "d_code" => "+51");
		$countries[] = array("code" => "PH", "name" => "Philippines", "d_code" => "+63");
		$countries[] = array("code" => "PL", "name" => "Poland", "d_code" => "+48");
		$countries[] = array("code" => "PT", "name" => "Portugal", "d_code" => "+351");
		$countries[] = array("code" => "PR", "name" => "Puerto Rico", "d_code" => "+1");
		$countries[] = array("code" => "QA", "name" => "Qatar", "d_code" => "+974");
		$countries[] = array("code" => "CG", "name" => "Republic of the Congo", "d_code" => "+242");
		$countries[] = array("code" => "RE", "name" => "Réunion", "d_code" => "+262");
		$countries[] = array("code" => "RO", "name" => "Romania", "d_code" => "+40");
		$countries[] = array("code" => "RU", "name" => "Russia", "d_code" => "+7");
		$countries[] = array("code" => "RW", "name" => "Rwanda", "d_code" => "+250");
		$countries[] = array("code" => "BL", "name" => "Saint Barthélemy", "d_code" => "+590");
		$countries[] = array("code" => "SH", "name" => "Saint Helena", "d_code" => "+290");
		$countries[] = array("code" => "KN", "name" => "Saint Kitts and Nevis", "d_code" => "+1");
		$countries[] = array("code" => "MF", "name" => "Saint Martin", "d_code" => "+590");
		$countries[] = array("code" => "PM", "name" => "Saint Pierre and Miquelon", "d_code" => "+508");
		$countries[] = array("code" => "VC", "name" => "Saint Vincent and the Grenadines", "d_code" => "+1");
		$countries[] = array("code" => "WS", "name" => "Samoa", "d_code" => "+685");
		$countries[] = array("code" => "SM", "name" => "San Marino", "d_code" => "+378");
		$countries[] = array("code" => "ST", "name" => "São Tomé and Príncipe", "d_code" => "+239");
		$countries[] = array("code" => "SA", "name" => "Saudi Arabia", "d_code" => "+966");
		$countries[] = array("code" => "SN", "name" => "Senegal", "d_code" => "+221");
		$countries[] = array("code" => "RS", "name" => "Serbia", "d_code" => "+381");
		$countries[] = array("code" => "SC", "name" => "Seychelles", "d_code" => "+248");
		$countries[] = array("code" => "SL", "name" => "Sierra Leone", "d_code" => "+232");
		$countries[] = array("code" => "SG", "name" => "Singapore", "d_code" => "+65");
		$countries[] = array("code" => "SK", "name" => "Slovakia", "d_code" => "+421");
		$countries[] = array("code" => "SI", "name" => "Slovenia", "d_code" => "+386");
		$countries[] = array("code" => "SB", "name" => "Solomon Islands", "d_code" => "+677");
		$countries[] = array("code" => "SO", "name" => "Somalia", "d_code" => "+252");
		$countries[] = array("code" => "ZA", "name" => "South Africa", "d_code" => "+27");
		$countries[] = array("code" => "KR", "name" => "South Korea", "d_code" => "+82");
		$countries[] = array("code" => "ES", "name" => "Spain", "d_code" => "+34");
		$countries[] = array("code" => "LK", "name" => "Sri Lanka", "d_code" => "+94");
		$countries[] = array("code" => "LC", "name" => "St. Lucia", "d_code" => "+1");
		$countries[] = array("code" => "SD", "name" => "Sudan", "d_code" => "+249");
		$countries[] = array("code" => "SR", "name" => "Suriname", "d_code" => "+597");
		$countries[] = array("code" => "SZ", "name" => "Swaziland", "d_code" => "+268");
		$countries[] = array("code" => "SE", "name" => "Sweden", "d_code" => "+46");
		$countries[] = array("code" => "CH", "name" => "Switzerland", "d_code" => "+41");
		$countries[] = array("code" => "SY", "name" => "Syria", "d_code" => "+963");
		$countries[] = array("code" => "TW", "name" => "Taiwan", "d_code" => "+886");
		$countries[] = array("code" => "TJ", "name" => "Tajikistan", "d_code" => "+992");
		$countries[] = array("code" => "TZ", "name" => "Tanzania", "d_code" => "+255");
		$countries[] = array("code" => "TH", "name" => "Thailand", "d_code" => "+66");
		$countries[] = array("code" => "BS", "name" => "The Bahamas", "d_code" => "+1");
		$countries[] = array("code" => "GM", "name" => "The Gambia", "d_code" => "+220");
		$countries[] = array("code" => "TL", "name" => "Timor-Leste", "d_code" => "+670");
		$countries[] = array("code" => "TG", "name" => "Togo", "d_code" => "+228");
		$countries[] = array("code" => "TK", "name" => "Tokelau", "d_code" => "+690");
		$countries[] = array("code" => "TO", "name" => "Tonga", "d_code" => "+676");
		$countries[] = array("code" => "TT", "name" => "Trinidad and Tobago", "d_code" => "+1");
		$countries[] = array("code" => "TN", "name" => "Tunisia", "d_code" => "+216");
		$countries[] = array("code" => "TR", "name" => "Turkey", "d_code" => "+90");
		$countries[] = array("code" => "TM", "name" => "Turkmenistan", "d_code" => "+993");
		$countries[] = array("code" => "TC", "name" => "Turks and Caicos Islands", "d_code" => "+1");
		$countries[] = array("code" => "TV", "name" => "Tuvalu", "d_code" => "+688");
		$countries[] = array("code" => "UG", "name" => "Uganda", "d_code" => "+256");
		$countries[] = array("code" => "UA", "name" => "Ukraine", "d_code" => "+380");
		$countries[] = array("code" => "AE", "name" => "United Arab Emirates", "d_code" => "+971");
		$countries[] = array("code" => "GB", "name" => "United Kingdom", "d_code" => "+44");
		$countries[] = array("code" => "US", "name" => "United States", "d_code" => "+1");
		$countries[] = array("code" => "UY", "name" => "Uruguay", "d_code" => "+598");
		$countries[] = array("code" => "VI", "name" => "US Virgin Islands", "d_code" => "+1");
		$countries[] = array("code" => "UZ", "name" => "Uzbekistan", "d_code" => "+998");
		$countries[] = array("code" => "VU", "name" => "Vanuatu", "d_code" => "+678");
		$countries[] = array("code" => "VA", "name" => "Vatican City", "d_code" => "+39");
		$countries[] = array("code" => "VE", "name" => "Venezuela", "d_code" => "+58");
		$countries[] = array("code" => "VN", "name" => "Vietnam", "d_code" => "+84");
		$countries[] = array("code" => "WF", "name" => "Wallis and Futuna", "d_code" => "+681");
		$countries[] = array("code" => "YE", "name" => "Yemen", "d_code" => "+967");
		$countries[] = array("code" => "ZM", "name" => "Zambia", "d_code" => "+260");
		$countries[] = array("code" => "ZW", "name" => "Zimbabwe", "d_code" => "+263");
		
		return $countries;
	}
?>