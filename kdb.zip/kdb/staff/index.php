<?php
ob_start();
require_once("../includes/bootstrap.php");	
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
		
		<div>
				<div id='packages'>
					<i class='fa fa-group' style='position:absolute; bottom:7px; right:10px; font-size:60px; color:rgba(255,255,255,0.2);'></i>
					<div id='d_amt'>
						<?php 
							echo mysqli_num_rows(mysqli_query($con, "select id from users_info"));
						?><br>
						<span class='reduce'>Total Registered Members</span>
					</div>
				</div>
			
				<div id='packages' style='background-color:#bb0;'>
					<i class='fa fa-bank' style='position:absolute; bottom:7px; right:10px; font-size:60px; color:rgba(255,255,255,0.2);'></i>
					<div id='d_amt'>
						<?php 
							$q=mysqli_query($con, "select sum(amount) as deposit from transactions where description='Deposit'");
							$o=mysqli_fetch_assoc($q);
							echo number_format($o['deposit']);
						?><br>
						<span class='reduce'>Deposits</span>
					</div>
				</div>
				
				<div id='packages' style='background-color:#bb0;'>
					<i class='fa fa-bank' style='position:absolute; bottom:7px; right:10px; font-size:60px; color:rgba(255,255,255,0.2);'></i>
					<div id='d_amt'>
						<?php 
							$q=mysqli_query($con, "select sum(amount) as deposit from transactions where description='Cash Withdrawal'");
							$o=mysqli_fetch_assoc($q);
							echo number_format($o['deposit']);
						?><br>
						<span class='reduce'>Withdrawals</span>
					</div>
				</div>
		</div>

		
<?php 
include("includes/admin_foot.php");
?>