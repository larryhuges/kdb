<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
?>

<?php date_default_timezone_set("Africa/Lagos"); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<![if !IE]>
<link rel="icon" href="images/DG.png" type="image/x-icon">
<![endif]>
<link rel="shortcut icon" href="images/DG.png" type="image/ico">
<link rel="stylesheet" href="css/index.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Dynamic Gain</title>
<script type="text/javascript" src="js/index.js"></script>
</head>

<body style="margin:0px;">
	<div id='home' style=''>
			<a href='index.php'>
				<div id='logo'>
					<img src='images/DG.png' id='imgg' class='image_resize'>
				</div>
			</a>
			
			<nav id='lap_menu'>
				<ul class='lap_one'>				
					<?php
						if(isset($_SESSION['c_id'])){
							echo "<a class='first' href='logout.php?key=11'><li class='lap_one'>Logout</li></a>
								<a class='first' href='index.php#How-It-Works'><li class='lap_one'>How It Works</li></a>
								<a class='first' href='index.php#About'><li class='lap_one'>About</li></a>
								<a class='first' href='dashboard.php'><li class='lap_one'>Dashboard</li></a>
								<a class='first' href='index.php'><li class='lap_one'>Home</li></a>";
						}else{
							echo "
								<a class='first' href='signup.php'><li class='lap_one'>SignUp</li></a>
								<a class='first' href='login.php'><li class='lap_one'>Login</li></a>
								<a class='first' href='index.php#How-It-Works'><li class='lap_one'>How It Works</li></a>
								<a class='first' href='index.php#About'><li class='lap_one'>About</li></a>
								<a class='first' href='index.php'><li class='lap_one'>Home</li></a>
							";
						}
					
					?>
				</ul>
			</nav>
			
			<div id='menu_bar_holder' onclick='show_menu()'>
				<div id='menu_bars'></div>
				<div id='menu_bars'></div>
				<div id='menu_bars'></div>
			</div>
			
			<nav id='mobile_menu'>
				<ul class='one'>
					<?php
						if(isset($_SESSION['c_id'])){
							echo "
								<a class='first' href='index.php'><li class='one'>Home</li></a>
								<a class='first' href='dashboard.php'><li class='one'>Dashboard</li></a>
								<a class='first' href='index.php#About'><li class='one'>About</li></a>
								<a class='first' href='index.php#How-It-Works'><li class='one'>How It Works</li></a>
								<a class='first' href='logout.php?key=11'><li class='one'>Logout</li></a>
								";
						}else{
							echo "
								<a class='first' href='index.php'><li class='one'>Home</li></a>
								<a class='first' href='index.php#About'><li class='one'>About</li></a>
								<a class='first' href='index.php#How-It-Works'><li class='one'>How It Works</li></a>
								<a class='first' href='login.php'><li class='one'>Login</li></a>
								<a class='first' href='signup.php'><li class='one'>SignUp</li></a>
								
							";
						}
					?>
					
					
				</ul>
			</nav>
			
	</div>

	<section id="wrapper">
		<div id="slider_holder">
			<img src='images/imagefill.jpg' class='image_resize'>
			<div id='slide' class='myslide'>
				<div id='text_holder'>
					<div id='title' align='center'>DYNAMIC GAIN</div>
				</div>
			</div>
			<!--<a href='signup.php'><p class='join_btn'>Learn More</p></a>-->
		</div>
	</section>
	
	<section id="wrapper" class="grad" style="height:auto; color:blue;" align="center">
		<div id="center_container">
			<!--<div align='center' style='margin-top:0px;'>
				<h1 style="text-align: center; margin-top:30px; color:#38454f; font-size:35px; font-family: Tahoma, Geneva, sans-serif;">About DYNAMIC GAIN</h1>
			</div>-->
		
			<div id='sub-section' style='float:left;'>
				<img src='images/about.jpg' class="image_resize"><br>
			</div>
			<div id='sub-section' style='float:right; color:#00416A;'>

			<p id="About"><br>
			Dynamic Gain provides a platform that facilitates peer to peer donations between members. D.G is designed 
			to help people grow financially, create, preserve, and transfer wealth across generations worldwide. <br><br><br><br>
			<strong>Who We Are?</strong>
			<br>Dynamic Gain aimed to establish a community of honest members helping each other to create a strong and reliable financial system for each other.
				Thoughtful research began on how to make Dynamic Gain solve the restrictions and challenges of all other 
				social financial donation systems nationwide, we are pleased to inform you that the system was developed, 
				verified and tested several times before it gained authorization for hosting.</p>
</p>
			</div>
		</div>
	</section>
	
	<section id="wrapper" style="height:auto; background:#eee;" align="center">
		<div id="center_container">
		<div align='center' style='margin-top:30px;'>
		<h1 id="How-It-Works" style="text-align: center; color:#2196F3; font-size:35px; font-family: Tahoma, Geneva, sans-serif;">How It Works</h1>
		</div>
		<div id='sub-section' style='float:right; text-align:center;' align='center'>
			<img src='images/how_it_works.jpg' class="image_resize"><br>
		</div>
		<div id='sub-section' style='float:left; color:#333; text-shadow:none;'>
			
			&nbsp;<strong>How to get started:</strong><br><br>
			<ol>
				<li>Simply register on https://www.dynamicgain.com</li>
				<li>Register with your valid email and  phone number</li>
                                <li>An activation Email will be sent to your registered Email Address</li>
				<li>Activate your Email address</li>
                                <li>Login and select your preferred package</li>
                                <li>The system merges you automatically to pay your first 20% of your total donation.</li>
				<li>After 3 days the system merges you to pay the remaining 80% of your total donation</li>
				<li>Once your POP is confirmed, wait to be matched on the 5th day of your PH</li>
                                <li>On the 5th day, before you can withdraw your money, the system will automatically ask you to recommit 20% for another package.</li>
				<li>Recycle to make more gain and keep the system growing</li>
                                <li>For re-commitment, you get N1000 Bonus.</li>
			</ol>
		</div>
		</div>
				
	</section>
	<?php 
		$query=mysqli_query($con,"select * from testimonies where good='Yes' order by date_sent asc limit 5");
		if(mysqli_affected_rows($con)<=0){
			echo null;
		}else{
			echo "
			<section id='wrapper' style='height:auto; color:blue;' align='center'>
				<div id='center_container'>
				
					<div id='sub-section' style='float:left;'>
						<img src='images/testimonials.png' class='image_resize'><br>
					</div>
					<div id='sub-section' style='float:right; color:#00416A;'>
		
					<p style='padding:2%, 10%;'><br>
					
						";
						while($out=mysqli_fetch_assoc($query)){
						
							echo "<div class='testy'>
								{$out['username']}<br><br>
								<i>{$out['message']}</i>
							</div>";
						}
						echo "
					
					</p>
					</div>
				</div>
			</section>";
		}
	?>
	<!--
	<section id="wrapper" style="height:auto; background:#fff; color:blue;" align="center">
		<div id="center_container">
			<div id='sub-section' align='center' style='float:right;'>			
				<img src='images/recent.jpg' class="image_resize">
			</div>
			<div id='sub-section' style='float:left; background-color:#fff; text-shadow:none;'>
			<div align='center' style='margin-top:30px;'>
				<h1 style="text-align: center; margin-top:30px; color:#2196F3; font-size:25px; font-family: Tahoma, Geneva, sans-serif;">Recent Activities</h1>
			</div>
			<div style='text-shadow:none; letter-spacing:0; color:#000;'>
				
				<?php
					$sql="select * from news_feed order by date_check desc limit 10";
					$query=mysqli_query($con,$sql);
					while($out=mysqli_fetch_assoc($query)){
						echo "<div class='two'>".$out['message']." ".$out['date_check']."</div>";
					}
				?>
				
			</div>
		
		</div>
			
		</div>	
	</section>
	
	<section id="wrapper" style="background:#eff; padding-bottom:2%;" align="center">
		<div id='center_container'>
			<div align='center' style='margin-top:30px;'>
				<h1 style="text-align: center; margin-top:30px; color:#38454f; font-size:35px; font-family: Tahoma, Geneva, sans-serif;">Performance</h1>
			</div>
			<div id='products' align='center' style='margin-bottom:0px; background-color:#eff; border:none; color:#2196F3; margin-top:20px;'>
				<i class="fa fa-sellsy" style="font-size:80px;"></i><br>
				<h3 style='color:#38454f; letter-spacing:2px; font-family:sans-serif;' align='center'>Fast & Simple</h3>
			</div>
			<div id='products' align='center' style='margin-bottom:0px; background-color:#eff; border:none; color:#2196F3; margin-top:20px;'>
				<i class="fa fa-server" style="font-size:80px;"></i><br>
				<h3 style='color:#38454f; letter-spacing:2px; font-family:sans-serif;' align='center'>Easy Dashboard</h3>
			</div>
			<div id='products' align='center' style='margin-bottom:0px; background-color:#eff; border:none; color:#2196F3; margin-top:20px;'>
				<i class="fa fa-hdd-o" style="font-size:80px;"></i><br>
				<h3 style='color:#38454f; letter-spacing:2px; font-family:sans-serif;' align='center'>Security</h3>
			</div>
			<div id='products' align='center' style='margin-bottom:0px; background-color:#eff; border:none; color:#2196F3; margin-top:20px;'>
				<i class="fa fa-life-ring" style="font-size:80px;"></i><br>
				<h3 style='color:#38454f; letter-spacing:2px; font-family:sans-serif;' align='center'>24/7 support</h3>
			</div>
		</div>
	</section>	-->
	<script>
	var i;
	
		for(i=0;i<4;i++){
			countdown(i);
		}
		  function countdown(index){
			var ttt=document.getElementById('to'+index).innerHTML;//alert(ttt);
			var y=0;
			var x=setInterval(function (){
				
				ttt=ttt-1;y=y+1;
				document.getElementById('to'+index).innerHTML=y;
				if(ttt<=0){
					clearInterval(x);
					//alert(index + "done")
				}
			},1);
		  }
	</script>
	
	<script>
		var ind=1;
				calltesty(ind);
				
				function calltesty(ind){
					starttesty(ind)
					var timer=setInterval("starttesty(ind)",5000);
				}
				

				function starttesty(n){
					
					var testy= document.getElementsByClassName('testy')
					//var botton = document.getElementsByClassName('botton');
					var i;
					
					if(n > testy.length){
						ind=1;
					}
					
					for(i=0;i<testy.length; i++){
						testy.item(i).style.display='none';
						testy.item(ind - 1).style.opacity=0;
						//botton.item(i).style.backgroundColor='#999'
					}
					
					testy.item(ind - 1).style.display='block';
					testy.item(ind - 1).style.opacity=1;
					//botton.item(index - 1).style.backgroundColor='black'
					ind=ind + 1;
					
				} 
	</script>
	
<script type="text/javascript">
				var index=1;
				callSlide(index);
				
				function callSlide(index){
					startSlide(index)
					var timer=setInterval("startSlide(index)",5000);
				}
				

				function startSlide(n){
					
					var slide = document.getElementsByClassName('myslide')
					//var botton = document.getElementsByClassName('botton');
					var i;
					
					if(n > slide.length){
						index=1;
					}
					
					for(i=0;i<slide.length; i++){
						slide.item(i).style.display='none';
						slide.item(index - 1).style.opacity=0;
						//botton.item(i).style.backgroundColor='#999'
					}
					
					slide.item(index - 1).style.display='block';
					slide.item(index - 1).style.opacity=1;
					//botton.item(index - 1).style.backgroundColor='black'
					index=index + 1;
					
				} 
				
				/* function countdown(id,num){
					// var ct_down=document.getElementsByClassName('ct_down').innerHTML;
					var ct_show_globe=document.getElementsById('globe').innerHTML;
					var ct_show_nig=document.getElementsById('nig').innerHTML;
					var ct_show_online=document.getElementsById('online').innerHTML;
					var ct_show_ref=document.getElementsById('ref').innerHTML;
					
					var ct_show_globe=document.getElementsById('globe').innerHTML;
					var ct_show_nig=document.getElementsById('nig').innerHTML;
					var ct_show_online=document.getElementsById('online').innerHTML;
					var ct_show_ref=document.getElementsById('ref').innerHTML;
					
					var x=setInterval(function(){
						var ct_show_globe=ct_show_globe + 1;
						var ct_show_nig=ct_show_nig + 1;
						var ct_show_online=ct_show_online + 1;
						var ct_show_ref=ct_show_ref + 1;
						
						
					},100);
				} */
			</script> 
<?php 
	include("includes/foot.php");
	ob_end_flush();
?>