<?php
	session_start();
	
	function logged_in(){
		return isset($_SESSION['customer_id']);
	}
	
	function confirm_logged_in(){
		if(!logged_in()){
			header("Location: ../");
			exit;
		}
	}
	
	function admin_logged_in(){
		return isset($_SESSION['wlis_admin_id']);
	}
	
	function confirm_admin_logged_in(){
		if(!admin_logged_in()){
			header("Location: ../admin_gain_321_access");
			exit;
		}
	}
	
	
?>