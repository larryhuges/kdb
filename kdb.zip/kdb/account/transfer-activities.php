<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
?>

<style type="text/css">

	.text{
		border: .1rem solid #333;
	}
	
	.bankInput{
		display: block;
		max-width: 30rem; 
		cursor: pointer;
		position: relative;
	}

	.bankInput > div{
		position: absolute;
		top: 0;
		right: 0;
		width: 2rem; 
		height: 2rem;
		z-index: 10;
		margin: 1rem
	}

	table.kdbTable, tr.kdbTable{
		width:100%;
		//min-width:60rem;
		height:auto;
		margin:auto;
		margin-bottom:1%;
		border-collapse:collapse;
		font-family:sans-serif;
		border:.1rem solid #ecf0f5;
	}

.bcenter{
	text-align: center;
}

td.kdbTable, th.kdbTable{
	height:auto;
	vertical-align: center;
	margin:auto;
	border-collapse:collapse;
	border:.1rem solid #bcbcbc;
	font-size:1.2rem;
	padding: 1rem;
}
</style>


<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #666; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col_bg' style="float: left; width: 100%; padding: 2.0rem; margin: 00; background-color: #fff;">

			<div class="pTitle">
				Transfer Activities
			</div>
			<table class="p2p">
				<tr class="p2p" style="border-bottom: .1rem solid #aaa;">
					<th class="p2p">Date <i class="fa fa-caret-down"></i></th>
					<th class="p2p" style="">Type <i class="fa fa-caret-down"></i></th>
					<th class="p2p">Transfer from <i class="fa fa-caret-down"></i></th>
					<th class="p2p">Transfer to <i class="fa fa-caret-down"></i></th>
					<th class="p2p" style="">Description <i class="fa fa-caret-down"></i></th>
					<th class="p2p">Amount <i class="fa fa-caret-down"></i></th>
					<th class="p2p">Status <i class="fa fa-caret-down"></i></th>
				</tr>
					<?php
						$s = "select * from transactions where username = '$t_username' order by date_of_event desc";
						$q = mysqli_query($con, $s);
						if(mysqli_affected_rows($con) >= 1){
							while ($o = mysqli_fetch_assoc($q)) {
					?>
								<tr class="p2p" style="border-bottom: .1rem solid #aaa;">
									<td class="p2p"><?php echo formatted_date($o['date_of_event'])?></td>
									<td class="p2p"><?php echo ucwords($o['description'])?></td>
									<td class="p2p"><?php echo ucwords($o['transfer_from'])?></td>
									<td class="p2p"><?php echo ucwords($o['transfer_to'])?></td>
						
									<td class="p2p"><?php echo ucwords($o['h_address'])?></td>
									<td class="p2p"><?php echo number_format($o['amount'], 2)?></td>
									<td class="p2p"><?php echo ucwords($o['status'])?></td>
									
								</tr>
					<?php
							}
						}else{
					?>
							<tr class="p2p" style="border-bottom: .1rem solid #aaa;">
								<td class="p2p">No Transfer Activity</td>
							</tr>
					<?php
						}
					?>
			</table>
		</div>
	</div>
</div>
<?php 
include("includes/member_foot.php");
?>
