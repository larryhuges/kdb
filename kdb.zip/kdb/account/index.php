<?php
	require '../includes/bootstrap.php';
	confirm_logged_in();
	include("includes/member_head.php");
?>
<?php alert_box();?>

<style type="text/css">
	#inner-frame{
		max-width:110.0rem;
		width:100%;
		height:auto;
		margin:0 auto;
		padding:1.0rem;
		position:relative;
		overflow-x:hidden;
	}

	.tabs_{
		float: left;
		position: relative;
		padding: 2.0rem 2.0rem;
		font-size: 1.4rem;
		//background-color: red;
		text-align: center;

	}

	.arrow-up {
		position: absolute;
		bottom: 0;
		left: 50%;
		width: 0; 
		height: 0; 
		border-left: 1.5rem solid transparent;
		border-right: 1.5rem solid transparent;
		border-bottom: 2.0rem solid #f0f2f5;
		display: none;
	}
</style>



<style type="text/css">
	#w_amt{
		font-size: 3.0rem;
		line-height: 1.5;
		padding: 1.0rem;
	}

	.reduce{
		font-size: 1.4rem;
	}
</style>
<!--
<div id='popdown' style="display: none;">
	<div id='alert_box_center' style='margin-top: 5%; margin-bottom: 0;'>
		<div id='pop_alert_box' align='center' style='padding: 5% 5% 5% 5%; border-radius: 0;'>

			<i class="fa fa-warning" style="font-size: 8.0rem; color: red;"></i><br><br>
			
			<h1 id='message_title' style='width: 100%; padding-bottom: 3%; font-family: page_font_rob; font-size: 2.0rem;'>
				Account Locked!!!
			</h1>
			<p id='message' style='color:#555; width: 100%; padding-bottom: 5%; font-family: sans-serif; font-size: 1.4rem;'>
				Your account has been temporarily locked bacause we detected unverified access to your account. Please visit any KEYVEST bank branch to unlock your account. 
			</p>
			<div align='center'>
				<form action="logout?5" method="get">
					<button type='submit'  style='margin:0;' class='btn upd'>
						OK
					</button>
				</form>
			</div>	
		</div>
	</div>
</div>
-->

<style>
	.acctype{
		display: flex;
		align-items:center;
		justify-content: flex-start;
		width: 100%;
		height: auto;
		border-bottom: .1rem solid #e6e6e6;
		box-sizing: border-box;
		margin: 2rem 0;
	}

	.acctype div {
		padding: 1.5rem 2rem;
		border: .1rem solid #e6e6e6;
		cursor:pointer
	}

	.acctype div:hover {
		background-color: #0063cc;
		color: #fff;
	}

	.nacc{
		display: flex;
		align-items:center;
		justify-content: space-between;
		width: 100%;
		height: auto;
		border: .1rem solid #e6e6e6;
		box-sizing: border-box;
		background: #fff;
		padding: 1.5rem 2rem;
		margin: 2rem 0;
		border-radius: 1rem;
	}

	

	.nacc1{
		display: flex;
		align-items:center;
		justify-content: flex-start;
	}

	.nacc1 img{
		margin-right: 2rem;
	}

	.nacc1 h2{
		margin-right: 3rem;
	}

	.accSum{
		display: flex;
		align-items:center;
		justify-content: space-between;
		width: 100%;
		height: auto;
		box-sizing: border-box;
		padding: 1.5rem 2rem;
		margin: 2rem 0 4rem;
		line-height: 2.8rem;
	}

	.nacclabel{
		display: flex;
		align-items:center;
		justify-content: space-between;
		width: 100%;
		height: auto;
		border: .1rem solid #0063cc;
		box-sizing: border-box;
		padding: 1.5rem 2rem;
		margin: 0;
		color: #fff; 
		background-color: #0063cc;
	}
</style>

<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #333; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col one_col' style="padding: 0;">
			<h1 style='color: #001f5b;'>
				Account Summary
			</h1>

			<div class='acctype'>
				<div>Deposit</div>
				<div>Trust</div>
				<div>Industrial Finance Bond</div>
				<div>Loan</div>
				<div>All</div>
			</div>

			<div class='col one_col'>
				<span style="font-size: 1.4rem; font-weight: normal; color: #333;">Last login 
					<?php
						echo str_replace('-', '/', $_SESSION['customer_last_login']);
					?>
				</span>
			</div>

			<?php
				if($t_verified == 'No'){
			?>
				<div class='col one_col nacc' style='background-color: red;'>
					<div class='nacc1'>
						<img src='../media/images/photo/ico_chgl_cont_02.png'/>
						<div>
							<h2 style='color: #fff;'>PENDING ACTIVATION!</h2>
							<p  style='color: #ededed;'>Your account has not been activated. Please Contcat Customer care if the activation process is not completed with 24 hours</p>
						</div>
					</div>
				</div>
			<?php } ?>
			<div class='col one_col nacc'>
				<div class='nacc1'>
					<img src='../media/images/photo/ico_chgl_cont_02.png'/>
					<h2>Deposit</h2>
					<p>Total <span>1</span> Account(s)</p>
				</div>
				<div>
					<b><?php echo number_format($t_available_balance, 2);?></b> KRW
				</div>
			</div>

			<div class='col one_col nacclabel' style=''>
				<div class='nacc1'>
					<p><b>Withdrawal Deposit Account(1)</b></p>
				</div>
				<div>
					<b><?php echo number_format($t_available_balance, 2);?></b> KRW
				</div>
			</div>

			<div class='col one_col accSum'>
				<div class=''>
					<p><b>KDB Hi, <?php echo $t_fullname;?></b></p>
					<p><u><?php echo $t_checking_account ?></u></p>
				</div>
				<div style='text-align: center; line-height: 2rem;'>
					<p>Opened Date</p>
					<p>2023 02 27</p>
				</div>
				<div style='text-align: right'>
					<p>
						<b><?php echo number_format($t_available_balance, 2);?></b>	KRW<br>
						<a href='transfer'><button class='btn upd'>Transfer</button></a>
					</p>
				</div>
			</div>

			<div class='col one_col nacclabel' style=''>
				<div class='nacc1'>
					<p><b>Lump Sum/Installment Deposit Account(0)</b></p>
				</div>
				<div>
					<b>0</b> KRW
				</div>
			</div>
		</div>
	</div>	
</div>

<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #333; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col one_col col_bg' style="padding: .0rem 2.0rem;">
			<div style="float: left; width: 100%; padding: 1.0rem; margin: .0rem 0; background-color: #fff;">

				<div style="float: left; width: 100%; padding: 1.0rem; padding-bottom: 2.0rem; font-size: 1.5rem; border-bottom: .2rem solid #333;">
					Recent Transfer Activity
				</div>
				<table class="p2p">
					<tr class="p2p" style="border-bottom: .1rem solid #aaa;">
						<th class="p2p">Date <i class="fa fa-caret-down"></i></th>
						<th class="p2p" style="">Type <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Transfer from <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Transfer to <i class="fa fa-caret-down"></i></th>
						<th class="p2p" style="">Description <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Amount <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Status <i class="fa fa-caret-down"></i></th>
					</tr>
						<?php
							$s = "select * from transactions where username = '$t_username' order by date_of_event desc limit 6";
							$q = mysqli_query($con, $s);
							if(mysqli_affected_rows($con) >= 1){
								while ($o = mysqli_fetch_assoc($q)) {
						?>
									<tr class="p2p" style="border-bottom: .1rem solid #aaa;">
										<td class="p2p"><?php echo formatted_date($o['date_of_event'])?></td>
										<td class="p2p"><?php echo ucwords($o['description'])?></td>
										<td class="p2p"><?php echo ucwords($o['transfer_from'])?></td>
										<td class="p2p"><?php echo ucwords($o['transfer_to'])?></td>
							
										<td class="p2p"><?php echo ucwords($o['h_address'])?></td>
										<td class="p2p"><?php echo number_format($o['amount'], 2)?></td>
										<td class="p2p"><?php echo ucwords($o['status'])?></td>
										
									</tr>
						<?php
								}
							}else{
						?>
								<tr class="p2p" style="border-bottom: .1rem solid #aaa;">
									<td class="p2p">No Transfer Activity</td>
								</tr>
						<?php
							}
						?>
				</table>
			</div>
		</div>
	</div>	
</div>
<?php 
include("includes/member_foot.php");
?>