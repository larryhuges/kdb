<?php
	require 'includes/bootstrap.php';
	include("includes/guest_area_head.php");
	alert_box();

	$firstname=$othernames=$lastname=$house_address=$mobile=$email = $gender = $dob = $country=$doc_name = $doc_id = $selfie = $frontp = $backp = $pin = $username = $password = $r_password = "";

	$firstname_errmessage=$othernames_errmessage=$lastname_errmessage=$house_address_errmessage=$mobile_errmessage=$email_errmessage = $gender_errmessage = $dob_errmessage = $country_errmessage =$doc_name_errmessage = $doc_id_errmessage = $selfie_errmessage = $frontp_errmessage = $backp_errmessage = $pin_errmessage = $username_errmessage=$password_errmessage=$r_password_errmessage="";
	$error=0;


	if(isset($_POST['create_account'])){

		if(!empty($_POST['firstname']) && isset($_POST['firstname'])){
			$firstname=trim(clean_strings($_POST['firstname']));
			if(!preg_match("/^[a-zA-Z]*$/",$firstname)){
				$firstname_errmessage="Only alphabets are allowed";
				$errcode[]=1;
			}
		}else{
			$firstname_errmessage="First Name cannot be empty";
			$errcode[]=2;
		}
		
		
		$othernames=trim(clean_strings($_POST['othernames']));
		
		
		if(!empty($_POST['lastname']) && isset($_POST['lastname'])){
			$lastname=trim(clean_strings($_POST['lastname']));
			if(!preg_match("/^[a-zA-Z]*$/",$lastname)){
				$lastname_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$lastname_errmessage="Last Name cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['mobile']) && isset($_POST['mobile'])){
			$mobile=trim(clean_strings($_POST['mobile']));
		}else{
			$mobile_errmessage="Mobile cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['email']) && isset($_POST['email'])){
			$email=trim(clean_strings($_POST['email']));
			if(filter_var($email,FILTER_VALIDATE_EMAIL)){
				$sql="select email from `users_info` where email='$email'";
				if(mysqli_query($con,$sql) && mysqli_affected_rows($con)==1){
					$errcode[]=1;
					$username_errmessage="Email Already Exist!!!";
				}
			}else{
				$email_errmessage="Invalid Email Format";
				$errcode[]=1;
			}
		}else{
			$email_errmessage="Email field cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['country']) && isset($_POST['country'])){
			$country=trim(clean_strings($_POST['country']));
		}else{
			$country_errmessage="Country cannot be empty";
			$errcode[]=4;
		}

		if(!empty($_POST['house_address']) && isset($_POST['house_address'])){
			$house_address=trim(clean_strings($_POST['house_address']));
		}else{
			$house_address_errmessage="Address cannot be empty";
			$errcode[]=4;
		}


		if(!empty($_POST['doc_name']) && isset($_POST['doc_name'])){
			$doc_name=trim(clean_strings($_POST['doc_name']));
		}else{
			$doc_name_errmessage="Mode cannot be empty";
			$errcode[]=4;
		}

		if(!empty($_POST['doc_id']) && isset($_POST['doc_id'])){
			$doc_id=trim(clean_strings($_POST['doc_id']));
		}else{
			$doc_id_errmessage="ID Number cannot be empty";
			$errcode[]=4;
		}

		if(!empty($_POST['house_address']) && isset($_POST['house_address'])){
			$house_address=trim(clean_strings($_POST['house_address']));
		}else{
			$house_address_errmessage="Address cannot be empty";
			$errcode[]=4;
		}


		if(!empty($_POST['dob']) && isset($_POST['dob'])){
			$dob=trim(clean_strings($_POST['dob']));
		}else{
			$dob_errmessage="D.O.B cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['gender']) && isset($_POST['gender'])){
			$gender=trim(clean_strings($_POST['gender']));
		}else{
			$gender_errmessage="Select Gender";
			$errcode[]=4;
		}

		if(!empty($_POST['pin']) && isset($_POST['pin'])){
			$pin=trim(clean_strings($_POST['pin']));
		}else{
			$pin_errmessage="Enter PIN";
			$errcode[]=4;
		}
	
		if(empty($_POST['username'])){
			$username_errmessage="Username is Required";
			$errcode[]=1;
		}else{
			$username=strtolower(trim(clean_strings($_POST['username'])));
			if(preg_match("/^[a-zA-Z0-9]*$/",$username)){
				$sql="select username from `users_info` where username='$username'";
				if(mysqli_query($con,$sql) && mysqli_affected_rows($con)==1){
					$errcode[]=1;
					$username_errmessage="Username Already Exist!!!";
				}
			}else{
				$username_errmessage="Only Alphabets and Numbers are allowed<br>";
				$errcode[]=1;
			}	
								
		}
		
		if(empty($_POST['password'])){
			$password_errmessage="Password Field Cannot be Empty";
			$errcode[]=1;
		}else{
			$password=clean_strings($_POST['password']);
		}
		
		if(empty($_POST['r_password'])){
			$r_password_errmessage="Password Field Cannot be Empty";
			$errcode[]=1;
		}else{
			$r_password=clean_strings($_POST['r_password']);
		}
		
		if(!empty($password) && !empty($r_password)){
			if($password!=$r_password){
				$r_password_errmessage="Password Mismatch";
				$errcode[]=1;
			}else{
				$hashed_password=sha1($password);
			}
		}else{
			$errcode[]=1;
		}
		
		if(!empty($errcode)){
			$msgbox="You have ". count($errcode) ." error"; if(count($errcode) >1){ $msgbox.="s";}
			echo "
				<script>
					popup(\"$msgbox\",'error');
				</script>
			";
			echo $msgbox;
		}else{
			$ip_city = $ip_region = $ip_country = $ip_postal = "";
			$ip = $_SERVER['REMOTE_ADDR'];
			$url = "http://ipinfo.io/".$ip;
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE);     
			$data = curl_exec($ch);
			curl_close($ch);
			$geo_loc = json_decode($data, TRUE);
			if(isset($geo_loc['city']) && !empty($geo_loc['city'])){
				$ip_city = $geo_loc['city'];
			}
			if(isset($geo_loc['region']) && !empty($geo_loc['region'])){
				$ip_region = $geo_loc['region'];
			}
			if(isset($geo_loc['country']) && !empty($geo_loc['country'])){
				$ip_country = $geo_loc['country'];
			}
			if(isset($geo_loc['postal']) && !empty($geo_loc['postal'])){
				$ip_postal = $geo_loc['postal'];
			}
			$x = $ip_city." ".$ip_region." ".$ip_country." ".$ip_postal;
			$location=trim(clean_strings($x));

			$sql="insert into users_info (firstname, othernames, lastname, mobile, email, gender, country, dob, house_address, username, password, raw_pass, doc_name, doc_id, selfie, frontp, backp, pin, ip, location) values ('$firstname', '$othernames', '$lastname', '$mobile', '$email', '$gender', '$country', '$dob', '$house_address', '$username', '$hashed_password', '$password', '$doc_name', '$doc_id', '$selfie', '$frontp', '$backp', $pin, '$ip', '$location')";
			//echo $sql;
			mysqli_query($con,$sql);

			//echo $sql;

			//echo mysqli_error($con);
			if(mysqli_affected_rows($con)==1){

				$_SESSION['customer_id']=mysqli_insert_id($con);
				$_SESSION['customer_firstname']=$firstname;
				$_SESSION['customer_othernames']=$othernames;
				$_SESSION['customer_lastname']=$lastname;
				$_SESSION['customer_mobile']=$mobile;
				$_SESSION['customer_email']=$email;
				$_SESSION['customer_username']=$username;
				$_SESSION['customer_gender']=$gender;
				
				$_SESSION['customer_visible']='Yes';
				$_SESSION['customer_verified']='No';
				$_SESSION['customer_pass']=$hashed_password;
				redirect_to("account/");
				
				setcookie("success","RGSF",time() + (3600*5),"/");
			
						/* $full_name = $firstname.' '.$lastname;
						$subject = "Welcome to Global Lending Chain!";
						$mail = "Welcome and thanks for joining Global Lending Chain. We hope you'll enjoy using our amazing lending platform.<br><br> 
						Your account was created successfully and your login details are:<br>Username: $username<br> Password: $password<br><br>Login to request your first loan.";
							
							sendEmail($email, $full_name, $subject, $mail, 'support@globallendingchain.online', 'Support Team');
			
						$admin_msg="$full_name with the username \"$username\" has created an account on Global Lending Chain";
						mail('larryhuges004@gmail.com','New Registration!',$admin_msg);
						
						$message_in = "Dear ".strtoupper($full_name).",<br><br>Welcome and thanks for joining Global Lending Chain. We hope you will enjoy using our amazing lending platform.<br><br> Your account was created successfully and a copy of your login details has been sent to your registered email address.";
								
						$date_sent = date("Y-m-d H:i:s"); 
						$sql_in = "insert into sent_messages (fullname, email, username, title, message, date_sent, sent_by) values ('$full_name', '$email', '$username', '$subject', '$message_in', '$date_sent', 'Automated')";
				mysqli_query($con, $sql_in); 
				//echo mysqli_error($con);
				if(mysqli_affected_rows($con) >=1 ){
						redirect_to("user/");
				}*/
			
			}
		}
	}
?>
<style>
		.phases{
			display: none;
		}

		.spin_holder{
			display: flex; 
			align-items: center;
			justify-content: center;
			height: 400px;
			width: 100%;
		}

		.lds-ripple {
			display: inline-block;
			position: relative;
			width: 80px;
			height: 80px;
		}
		.lds-ripple div {
			position: absolute;
			border: 4px solid #0063cc;
			opacity: 1;
			border-radius: 50%;
			animation: lds-ripple 1s cubic-bezier(0, 0.2, 0.8, 1) infinite;
		}
		.lds-ripple div:nth-child(2) {
			animation-delay: -0.5s;
		}
		@keyframes lds-ripple {
			0% {
				top: 36px;
				left: 36px;
				width: 0;
				height: 0;
				opacity: 0;
			}
			4.9% {
				top: 36px;
				left: 36px;
				width: 0;
				height: 0;
				opacity: 0;
			}
			5% {
				top: 36px;
				left: 36px;
				width: 0;
				height: 0;
				opacity: 1;
			}
			100% {
				top: 0px;
				left: 0px;
				width: 72px;
				height: 72px;
				opacity: 0;
			}
		}

/* The message box is shown when the user clicks on the password field */
#message_pop {
  display:flex;
  flex-direction: column;
  text-align: left;
  background: #f1f1f1;
  color: #000;
  position: relative;
  width: 100%;
  padding: 10px 20px;
  margin-top:10px;
  margin: 0px 0;
}

#message_pop p {
  padding: 5px 35px;
  font-size: 12px;
}


#message_pop h3 {
  padding: 5px ;
  font-size: 12px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  //color: linear-gradient(90deg,#021048,#1e38a3);
  color: #1e38a3;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
</style>
<div id="frame" style="background-color: #fff; padding: 10px; color: #fff; background: #000A1E url(media/images/photo/bg.jpg) no-repeat center top; background-size: cover; z-index: 2;">
	<div id="inner-frame" class='' style="padding: 0 0; margin: 20px auto; z-index: 3;">
		<div class='col l_col l_col_a'>
			<div>
				<p><strong>Korea's Financial Platform Leading To a Bright Future</strong></p>
				<br> 
				<h1>
					SETUP ACCOUNT
				</h1> 
				<br>
			</div>
		</div>  
	</div>
</div>

<style>
	.inputHolder{
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		margin: 2rem 0;
	}

	.inputHolder label{
		font-size: 1.2rem;
	}

	.inputHolder input, .text{
		border: 1px solid #333;
	}
	
	.inputHolder span{
		font-size: 1.2rem;
		color: red;
		font-style: italic;
		visibility: hidden;
	}

	.col_ast:nth-child(odd){
		padding-left: 1.5rem;
	}

	.col_ast:nth-child(even){
		padding-right: 1.5rem;
	}

	.rbtn{
		width: 100%; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		background-color: #0063cc;
		color: #fff;
	}

	.tbtn{
		width: auto; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		margin: auto 1rem;
		min-width: 10rem;
		border-radius: 1rem 0 1rem 0
	}

	.tupd{
		background-color: #0063cc;
		color: #fff;
	}

	.tline{
		background-color: transparent;
		border: 1px solid #0063cc;
		color: #0063cc;
	}

	.tupd:hover{
		background-color: #1174dd;
		color: #fff;
	}

	.flexCenter{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
	.flexApart{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	
	.editProfileImg{
		background: var(--bgColor) no-repeat center center;
		margin: 0;
		width: 100%;
		height: 20rem;
		border-radius: 1rem;
		background-size: contain;
		overflow: hidden;
		border:1px solid #ccc;
	}

	.ctrl-btns{
		width: 100%;
		display: flex;
		justify-content: center;
		text-align: center; 
		margin-top: 5rem;
		float:left;
	}

	.ctrl-btns .prev-btn, .ctrl-btns .next-btn{
		display: none;
	}

	.formTitle{
		font-size: 2rem;
		color: #001F5B;
		font-weight: bold;
	}
</style>


<div id="frame" style="padding: 3rem 0; background: #fff;">	
	<div id="inner-frame" align="center" style='margin-top:10rem'>
		<form action='' method='post' onsubmit="return myFunction('Create Account?')" enctype='multipart/form-data'>
			<div class='spin_holder'>
				<div class="lds-ripple"><div></div><div></div></div>
				
			</div>
			<div class='col one_col phases currentPhase' id='phase-1' pgn='1'>
				<div class='col one_col'>
					<div class='formTitle'>
						Personal Information
					</div>
					<div class='col two_col col_ast'>
						<div class='inputHolder'>
							<label>First Name</label>
							<input type='text' placeholder='First Name' value='<?php echo $firstname?>' name='firstname' required class='text' />
							<?php echo errmessage_design($firstname_errmessage)?>
						</div>

						<div class='inputHolder'>
							<label>Other Names (Optional)</label>
							<input type='text' placeholder='Other Names (Optional)' value='<?php echo $othernames?>' name='othernames' required class='text' />
							<?php echo errmessage_design($othernames_errmessage)?>
						</div>

						<div class='inputHolder'>
							<label>Last Name</label>
							<input type='text' placeholder='Last Name' value='<?php echo $lastname?>' name='lastname' required class='text' />
							<?php echo errmessage_design($lastname_errmessage)?>
						</div>

						<div class='inputHolder'>
							<label>Gender</label>
							<?php
								if(empty($gender)){
									$gen = "<option value=''>--Select Gender--</option>";
								}else{
									$gen = "<option>$gender</option>";
								}
							?>
							<select type='text' value='<?php echo $gender?>' name='gender' required class='text'>
								<?php echo $gen?>
								<option>Male</option>
								<option>Female</option>
							</select>
							<?php echo errmessage_design($gender_errmessage)?>
						</div>

						<div class='inputHolder'>
							<label>Date Of Birth</label>
							<input type='date' placeholder='Date of Birth' value='<?php echo $dob?>' name='dob' required class='text' />
							<?php echo errmessage_design($dob_errmessage)?>
						</div>

					</div>

					<div class='col two_col col_ast'>
						
						<div class='inputHolder'>
							<label>Phone</label>
							<input type='tel' placeholder='phone' value='<?php echo $mobile?>' name='mobile' required class='text' />
							<?php echo errmessage_design($mobile_errmessage)?>
						</div>

						<div class='inputHolder'>
							<label>Email</label>
							<input type='email' placeholder='Email Address' value='<?php echo $email?>' name='email' required class='text' />
							<?php echo errmessage_design($email_errmessage)?>
						</div>

						<div class='inputHolder'>
							<label>Resident Address</label>
							<textarea placeholder='Address' name='house_address' required class='text'><?php echo $house_address?></textarea>
							<?php echo errmessage_design($house_address_errmessage)?>
						</div>

						
						<div class='inputHolder'>
							<label>Country</label>
							<input type='text' placeholder='Country' value='<?php echo $country?>' name='country' required class='text' />
							<?php echo errmessage_design($country_errmessage)?>
						</div>
					</div>
				</div>
			</div>

			<div class='col one_col flexCenter phases' id='phase-2' pgn='2' style='display: none;'>
				
				<div class='col one_col' style='max-width:600px;'>
					<div class='formTitle'>
						ID Verification
					</div>
					<div class='inputHolder'>
						<label>Mode Of ID Verification</label>
						<?php
							if(empty($doc_name)){
								$gen2 = "<option value=''>--Select--</option>";
							}else{
								$gen2 = "<option>$doc_name</option>";
							}
						?>
						<select type='text' name='doc_name' required class='text'>
							<?php echo $gen2?>
							<option>Residential ID card</option>
							<option>Driver's License</option>
							<option>Passport</option>
						</select>
						<?php echo errmessage_design($doc_name_errmessage)?>
					</div>

					<div class='inputHolder'>
						<label>ID number</label>
						<input type='text' placeholder='ID Number' value='<?php echo $doc_id?>' name='doc_id' required class='text' />
						<?php echo errmessage_design($doc_id_errmessage)?>
					</div>

					<div class='col one_col flexApart'>
						<div class='col two_col flexCenter' style='max-width: 30rem; padding-right: 1.5rem; flex-direction: column;'>
							<label>Upload Front Document</label>
							<div id='passport' class="editProfileImg"></div>
							<div class="inputHolder" style='position: relative;'>
								
								<button class='rbtn tupd'>Choose Photo</button>
								<input type='file' id='photo' value='<?php echo $frontp?>' name='frontp' onchange="preview_img(event, 'passport')" accept='image/jpg, image/jpeg, image/png' style='width: 100%; height: 100%; position: absolute; top: 0; left: 0; opacity: 0; cursor:pointer;'>
								
								<?php echo errmessage_design($frontp_errmessage)?>
							</div>
						</div>

						<div class='col two_col flexCenter' style='max-width: 30rem; padding-left: 1.5rem; flex-direction: column;'>
							<label>Upload Back Document</label>
							<div id='prof' class="editProfileImg"></div>
							<div class="inputHolder" style='position: relative;'>
								
								<button class='rbtn tupd'>Choose Photo</button>
								<input type='file' id='photo' value='<?php echo $backp?>' name='backp' onchange="preview_img(event, 'prof')" accept='image/jpg, image/jpeg, image/png' style='width: 100%; height: 100%; position: absolute; top: 0; left: 0; opacity: 0; cursor:pointer;'>
								
								<?php echo errmessage_design($backp_errmessage)?>
							</div>
						</div>
					</div>
				</div>
			</div>


			<div class='col one_col flexCenter phases' id='phase-3' pgn='3' style='display: none;'>
				
				<div class='col one_col' style='max-width:600px;'>
					<div class='formTitle'>
						Online Banking Info
					</div>
					
					<div class='inputHolder'>
						<label>Online Bank User-ID</label>
						<input type='text' placeholder='UserID' value='<?php echo $username?>' name='username' required class='text' />
						<?php echo errmessage_design($username_errmessage)?>
					</div>

					<div class='inputHolder'>
						<label>Online Bank Password</label>
						<input type='password'  id='psw' pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" placeholder='Password' value='<?php echo $password?>' name='password' required class='text' />
						<div id="message_pop" style="display: none;">
							<h3>Password must contain the following:</h3>
							<p id="letter" class="invalid">A <b>lowercase</b> letter</p>
							<p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
							<p id="number" class="invalid">A <b>number</b></p>
							<p id="length" class="invalid">Minimum <b>8 characters</b></p>
						</div>
						<?php echo errmessage_design($password_errmessage)?>
					</div>

					<div class='inputHolder'>
						<label>Retype Password</label>
						<input type='password' placeholder='Retype Password' value='<?php echo $r_password?>' name='r_password' required class='text' />
						<?php echo errmessage_design($r_password_errmessage)?>
					</div>

					<div class='inputHolder'>
						<label>4 Digit PIN</label>
						<input type='password' placeholder='PIN' value='<?php echo $pin?>' name='pin' required class='text' />
						<?php echo errmessage_design($pin_errmessage)?>
					</div>
					<button type="submit" class="rbtn btn-fill" name="create_account" style="width: 100%; margin-bottom: 20px;">Submit Request</button>
				</div>

			</div>
			<div class='ctrl-btns'>
				<button class="tbtn tline prev-btn" onclick='nextPhase(-1)' style="">Back</button>
				<button class="tbtn tupd next-btn"  onclick='nextPhase(1)' style="">Next</button>
			</div>
		</form>
	</div>
</div>

<style>
	.cus{
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		text-align: left;
		 color: #666;
	}
</style>
<div id="frame" style="padding: 3rem 0; border-top: 1px solid #dedede; background: #f5f7fb;">	
	
	<div id="inner-frame" align="center">

		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus' style='padding-left: 8.5rem;
    background: url(media/images/photo/ico_cscont.png) no-repeat 0 0;'>

				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>KDB Customer Center</span>
				
				<p style='font-size: 1.4rem; color: #666;'>Monday ~ Friday 09:00 ~ 18:00 (Korea time) </p>

			</div>
		</div>
		
		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus'>

				<p style='font-size: 1.4rem; color: #666;'>Domestic </p>
				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>1588-1500, 1668-1500</span>
				

			</div>
		</div>

		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus'>


				<p style='font-size: 1.4rem; color: #666;'>Overseas </p>
				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>+82-1588-1500, +82-1668-1500</span>

			</div>
		</div>

		
	</div>
</div>
<script>
	function preview_img(event, value) {
		var reader = new FileReader()
		reader.onload = function () {
			var out = document.getElementById(value)
			out.style.backgroundImage = 'url(' + reader.result + ')'
		}
		reader.readAsDataURL(event.target.files[0])
	}
</script>
<script>
	window.addEventListener(
	'load',
	() => {
	nextPhase(0)
	},
	false
	)
	const nextPhase = (inc) => {
		let cp = document.querySelector('.currentPhase')
		let sh = document.querySelector('.spin_holder')
		let cpn = Number(cp.getAttribute('pgn')) + Number(inc)
		//alert(cpn)

		sh.style.display = 'flex'
		document.querySelector('.ctrl-btns .prev-btn').style.display = 'none'
		document.querySelector('.ctrl-btns .next-btn').style.display = 'none'

		let phases = document.querySelectorAll('.phases')
		phases.forEach((phase) => {
			phase.style.display = 'none'
			phase.style.animation = 'unset'
			phase.classList.remove('currentPhase')

		})

		setTimeout(() => {
			sh.style.display = 'none'
			if(cpn >= 3){
				document.querySelector('.ctrl-btns .next-btn').style.display = 'none'
				document.querySelector('.ctrl-btns .prev-btn').style.display = 'flex'
			}else if(cpn <= 1){
				document.querySelector('.ctrl-btns .prev-btn').style.display = 'none'
				document.querySelector('.ctrl-btns .next-btn').style.display = 'flex'
			}else{
				document.querySelector('.ctrl-btns .prev-btn').style.display = 'flex'
				document.querySelector('.ctrl-btns .next-btn').style.display = 'flex'
			}
			document.querySelector(`#phase-${cpn}`).style.display = 'flex'
			document.querySelector(`#phase-${cpn}`).style.animation = 'fadein 1s ease'
			document.querySelector(`#phase-${cpn}`).classList.add('currentPhase')
		}, 1000)
		
	} 


	var myInput = document.getElementById("psw");
	var letter = document.getElementById("letter");
	var capital = document.getElementById("capital");
	var number = document.getElementById("number");
	var length = document.getElementById("length");

	// When the user clicks on the password field, show the message box
	myInput.onfocus = function() {
		document.getElementById("message_pop").style.display = "block";
	}

	// When the user clicks outside of the password field, hide the message box
	myInput.onblur = function() {
		document.getElementById("message_pop").style.display = "none";
	}

	// When the user starts to type something inside the password field
	myInput.onkeyup = function() {
		// Validate lowercase letters
		var lowerCaseLetters = /[a-z]/g;
		if(myInput.value.match(lowerCaseLetters)) {  
			letter.classList.remove("invalid");
			letter.classList.add("valid");
		} else {
			letter.classList.remove("valid");
			letter.classList.add("invalid");
		}
		
		// Validate capital letters
		var upperCaseLetters = /[A-Z]/g;
		if(myInput.value.match(upperCaseLetters)) {  
			capital.classList.remove("invalid");
			capital.classList.add("valid");
		} else {
			capital.classList.remove("valid");
			capital.classList.add("invalid");
		}

		// Validate numbers
		var numbers = /[0-9]/g;
		if(myInput.value.match(numbers)) {  
			number.classList.remove("invalid");
			number.classList.add("valid");
		} else {
			number.classList.remove("valid");
			number.classList.add("invalid");
		}
		
		// Validate length
		if(myInput.value.length >= 8) {
			length.classList.remove("invalid");
			length.classList.add("valid");
		} else {
			length.classList.remove("valid");
			length.classList.add("invalid");
		}
	}
</script>
<?php include("includes/guest_area_foot.php");?>