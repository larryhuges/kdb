<?php date_default_timezone_set("US/Eastern"); ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<![if !IE]>
<link rel="icon" href="../images/fav.jpg" type="image/x-icon">
<![endif]>
<link rel="shortcut icon" href="../images/fav.jpg" type="image/ico">
<base href='http://kdb.com/staff/'>
<link rel="stylesheet" href="css/admin_area.css" type="text/css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>STAFF AREA</title>
<script type="text/javascript" src="js/index.js"></script>
</head>

<body>
	<script>
function popup(msg,status){

	var modal=document.getElementById('popdown');
	var icon=document.getElementById('display_icon');
	var message=document.getElementById('message');
	var message_title=document.getElementById('message_title');
	
	message.innerHTML=msg;
	modal.className=status;
	if(status=='error'){
		icon.innerHTML="<img src=\"images/close3.png\" width='100'>";
		message_title.innerHTML="Error";
		message_title.style.color="#b00";
	}else if(status=='added'){
		icon.innerHTML="<img src=\"images/success2.gif\" width='100'>";
		message_title.innerHTML="Successful";
		message_title.style.color="#3b3";
	}
}

function close_popup(){
	var y=document.getElementById('pop_alert_box');
	y.style.animation='d_out .5s ease';
	setTimeout(function (){document.getElementById('popdown').classList.remove('added');},500);
	//setTimeout(function (){document.getElementById('popdown').style.display='none';},500);
	
}
</script>
<!-- <div id='modalimg' style='overflow:scroll;' align='center'>
	<div id='close_pop' style='color:#f00; z-index:10000000;' onclick="document.getElementById('modalimg').style.display='none';"><i class='fa fa-close'></i></div>
	<img class='image_resize' id='imgmod' style='margin:auto;'>
</div>
 -->
	<script>

function s_menu(){
	var opt=document.getElementById("side_nav");
	if(opt.style.display=="block"){
		opt.style.animation="undo_drop_side ease .5s";
		setTimeout(function (){opt.style.display="none"},500);
		//opt.style.display="none";
		//document.getElementById("bckgrd").style.display="none";
	}else{
		opt.style.animation="drop_side ease .5s";
		opt.style.display="block";
		
		//document.getElementById("bckgrd").style.display="block";
	}
	
}
</script>

<style>
	
	html{
		font-size: 62.5%;
	}

	*{
		margin:0;
		padding: 0;
		box-sizing: border-box;
	}
	.mainContainer{
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: #0063cc;
		width:100%;
		height: 100vh;
		overflow: hidden;
	}

	.sideNavContainer{
		width: 25rem;
		height: 100%;
		display:block;
		overflow-y: scroll;
		overflow-x: hidden;
		z-index: 10;
	}

	ul.sideNav{
		width:100%;
		height:auto;
		margin:0;
		padding:0;
		overflow: hidden;
	}

	li.sideNav{
		width:100%;
		height:auto;
		list-style:none;
		margin:0;
		color:#aaa;
		font-family:sans-serif;
		font-size: 1.6rem;
		float:left;
		transition:ease .3s;
		text-decoration:none;
		cursor:pointer;
		letter-spacing:1px;
	}

	div.sideNav{
		width:100%;
		height:auto;
		padding:1.2rem 10% 1.2rem 10%;
		margin:0;
		border-left:none;
		color: #8FDAFA;
		transition: all .3s ease;
	}

	div.sideNav:hover{
		color:#fff;
	}

	.bodyContanier{
		width: calc(100% - 25rem);
		height: 100%;
		background-color: #f0f1f8;
		border-radius: 5px 0 0 5px;
		overflow-y: scroll;
		padding-left: 0.4rem;
	}

	.desktop_logo{
		padding: 2rem;
		margin-bottom: 1rem;
	}
</style>

<div class='mainContainer'>
	<div class="sideNavContainer">
		<div class="desktop_logo">
			<img src="../media/images/photo/logo3.png" height="30"> 
		</div>

		<ul class="sideNav">
			
			<a href="staff/"><li class="sideNav"><div class="sideNav"><i class='fa fa-server menu_icons'></i>&nbsp; Dashboard</div></li></a>
			
			<a href="all_members"><li class="sideNav"><div class="sideNav"><i class='fa fa-users menu_icons'></i>&nbsp; All Users</div></li></a>

			<a href="transactions"><li class="sideNav"><div class="sideNav"><i class='fa fa-edit menu_icons'></i>&nbsp; Transactions</div></li></a>
			
			<a href="change_password"><li class="sideNav"><div class="sideNav"><i class='fa fa-lock menu_icons'></i>&nbsp; Change Password</div></li></a>
			<a href="../logout/?key=22"><li class="sideNav"><div class="sideNav"><i class='fa fa-user menu_icons'></i>&nbsp; Logout</div></li></a>

		</ul>
	</div>
	<div class='bodyContanier'>
	<!-- 
	<div style='float:left; width:auto; font-family:sans-serif; font-size:14px; margin-left:10px;'>
		<a href='../index.php' class='first'><i class='fa fa-home social_icon'></i></a>
		
		<a href="../logout/22" class='first'><i class='fa fa-sign-out social_icon'></i></a>
	</div>
	<div style='float:right; width:auto; margin-right:30px; font-family:sans-serif; font-size:14px; margin-top:10px;'>
		<p id='afr' style='margin-right:20px; font-weight:bold;'>ADMIN AREA</p>
		<div id='bars' style='float:right;' onclick='s_menu()'>
			<i class='fa fa-bars' style='font-size:30px;'></i>
		</div>
	</div>
	
</div>
<div id='frame' style='clear:left;'>
		
	<div id="side_nav">
		<ul class="two">
		   
			<a href="index"><li class="two" style='color:#0c0; width:100%; font-family: page_title_font; font-size:25px;'>
				<div class="two_bg" style='background-color:rgba(255,255,255,0.1); text-shadow:0px 0px 5px #000; color:#fff;'>
					<i class='fa fa-tasks menu_icons'></i>&nbsp;DASHBOARD
				</div>

			</li></a>
			 <a href="all_members"><li class="two"><div class="two_bg"><i class='fa fa-group menu_icons'></i>&nbsp; All Users</div></li></a>
			 <a href="deposit_list"><li class="two"><div class="two_bg"><i class='fa fa-credit-card menu_icons'></i>&nbsp;Deposit</li></a>
			 <a href="active_trades"><li class="two"><div class="two_bg"><i class='fa fa-check menu_icons'></i>&nbsp;Active Trade</li></a>
			 <a href="confirm_withdraw"><li class="two"><div class="two_bg"><i class='fa fa-money menu_icons'></i>&nbsp;Withdrawal Requests</li></a>
			 <a href="new_trans"><li class="two"><div class="two_bg"><i class='fa fa-money menu_icons'></i>&nbsp;New Transaction</li></a>
			 <a href="send_mail"><li class="two"><div class="two_bg"><i class='fa fa-envelope menu_icons'></i>&nbsp;Send Mail</li></a>
			 <a href="verify"><li class="two"><div class="two_bg">&nbsp;<i class='fa fa-comments-o menu_icons'></i>&nbsp;Verify Accounts</div></li></a> -->
			<!--	 <a href="https://binafunds.com:2096/cpsess3172984917/webmail/paper_lantern/index.html?mailclient=roundcube" target="_blank"><li class="two"><div class="two_bg"><i class='fa fa-envelope menu_icons'></i>&nbsp;Webmail</li></a>
		<li class="two"><div onclick="show_sub(0)" class="two_bg"><i class='fa fa-credit-card menu_icons'></i>&nbsp;Withdrawal<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
				<ul class="ul_sub_two">
					<a href="confirm_withdraw"><li class="sub_two"><i class='fa fa-money menu_icons'></i>&nbsp;Withdrawal Requests</li></a>
					<a href="deposit_list"><li class="sub_two"><i class='fa fa-credit-card menu_icons'></i>&nbsp;Deposit</li></a>
				</ul>
			</li>-->
				
		<!--	<a href="new_trans"><li class="two"><div class="two_bg">&nbsp;<i class='fa fa-info menu_icons'></i>&nbsp;New Transaction</div></li></a>
			
			<a href="testimonies"><li class="two"><div class="two_bg">&nbsp;<i class='fa fa-comments-o menu_icons'></i>&nbsp;Testimonies</div></li></a>
			
		
			<li class="two"><div onclick="show_sub(0)" class="two_bg"><i class='fa fa-credit-card menu_icons'></i>&nbsp;Withdrawal<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
				<ul class="ul_sub_two">
					<a href="confirm_withdraw"><li class="sub_two"><i class='fa fa-money menu_icons'></i>&nbsp;Cash Requests</li></a>
					<a href="food_request"><li class="sub_two"><i class='fa fa-credit-card menu_icons'></i>&nbsp;Food Requests</li></a>
				</ul>
			</li>
			
			<li class="two"><div onclick="show_sub(1)" class="two_bg"><i class='fa fa-key menu_icons'></i>&nbsp;E-Pin<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
				<ul class="ul_sub_two">
					<a href="gen_epin"><li class="sub_two"><i class='fa fa-key menu_icons'></i>&nbsp;Generate E-Pin</li></a>
					<a href="gen_history"><li class="sub_two"><i class='fa fa-stack-overflow menu_icons'></i>&nbsp;Generated E-Pins</li></a>
				</ul>
			</li>
			
			<li class="two"><div onclick="show_sub(2)" class="two_bg"><i class='fa fa-building-o menu_icons'></i>&nbsp; Depots<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
				<ul class="ul_sub_two">
					<a href="new_depot"><li class="sub_two"><i class='fa fa-plus menu_icons'></i>&nbsp; Create New</li></a>
					<a href="all_depot"><li class="sub_two"><i class='fa fa-edit menu_icons'></i>&nbsp; All Depot</li></a>
				</ul>
			</li>
			
			<a href="notifications"><li class="two"><div class="two_bg">&nbsp;<i class='fa fa-info menu_icons'></i>&nbsp;Notifications</div></li></a>
			
			<a href="inbox"><li class="two"><div class="two_bg"><i class='fa fa-envelope-o menu_icons'></i>&nbsp; Inbox</div></li></a>
		-->
			<!-- <a href="change_password"><li class="two"><div class="two_bg"><i class='fa fa-lock menu_icons'></i>&nbsp; Change Password</div></li></a>
			
			<a href="../logout.php?key=22"><li class="two"><div class="two_bg"><i class='fa fa-sign-out menu_icons'></i>&nbsp;Logout</div></li></a>
		</ul>
	</div>
	<div id="board" style='background-color:#dadada; overflow-y:scroll;'> -->