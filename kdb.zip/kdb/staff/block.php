<?php
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();

	if (isset($_GET['sta']) && !empty($_GET['sta']) && isset($_GET['user']) && !empty($_GET['user'])) {
		$sta = ucfirst(clean_strings($_GET['sta']));
		$user = clean_strings($_GET['user']);
		
		mysqli_query($con, "update wlis_users_info_890 set visible='$sta' where username='$user' limit 1");
		$count_ = mysqli_affected_rows($con);
			if ($count_ == 1) {
				echo "1";
			}else{
				echo "0";
			}
	}
?>