<?php
	$errcode=array();
	$address = $city = $state = $zipcode = $country = array();
	$recipient_address = $recipient_city = $recipient_state = $recipient_zipcode = $recipient_country = array();
	$bank_name = $bank_address = $routing_number = $account_number = $r_account_number = $memo = $recipient_name = $recipient_nickname = $recipient_address = $recipient_memo = $date_of_event = array();

	$t_username = $_SESSION['customer_username'];

	function valid_input($str){
		global $errcode;
		$output = array();
		if(!empty($str) && isset($str)){
			$output['value']=clean_strings($str);
			/*if(!preg_match("/^[a-zA-Z0-9- ]*$/", $output['value'])){
				$output['error']="Only Numbers and Alphabets are allowed";
				$errcode[]=5;
			}
			*/
		}else{
			$output['error']="Input is required";
			$errcode[]=6;
		}
		return $output;
	}

	function check_field($v, $t){
		if($t == 'error'){
			if(isset($v['error'])){
				return "<p style='color:red; font-size:12px; font-style: italic;'>".$v['error']."</p>";
			}else{
				return NULL;
			}
		}elseif($t == 'value'){
			if(isset($v['value'])){
				return $v['value'];
			}else{
				return NULL;
			}
		}else{
			return "error";
		}
	}

	if(isset($_POST['add_recipient'])){
		
		$bank_name = valid_input($_POST['bank_name']);
		$bank_address = valid_input($_POST['bank_address']);
		$city = valid_input($_POST['city']);
		$state = valid_input($_POST['state']);
		$zipcode = valid_input($_POST['zipcode']);
		$country = valid_input($_POST['country']);
		$routing_number = valid_input($_POST['routing_number']);
		$account_number = valid_input($_POST['account_number']);
		$r_account_number = valid_input($_POST['r_account_number']);
		$memo = valid_input($_POST['memo']);
		$recipient_name = valid_input($_POST['recipient_name']);
		$recipient_nickname = valid_input($_POST['recipient_nickname']);
		$recipient_address = valid_input($_POST['recipient_address']);
		$recipient_city = valid_input($_POST['city']);
		$recipient_state = valid_input($_POST['state']);
		$recipient_zipcode = valid_input($_POST['zipcode']);
		$recipient_country = valid_input($_POST['country']);
		$recipient_memo = valid_input($_POST['recipient_memo']);
		
		//print_r($bank_name);
		if(!empty($errcode)){
			$msgbox="You have made an error";//. count($errcode) ." errors";
			echo "
				<script>
					popup('Error Occured!', \"$msgbox\",'error');
				</script>
			";
		}else{
			$combine_address = $bank_address['value']."^".$city['value']."^".$state['value']."^".$zipcode['value']."^".$country['value'];
			$combine_r_address = $recipient_address['value']."^".$recipient_city['value']."^".$recipient_state['value']."^".$recipient_zipcode['value']."^".$recipient_country['value'];
		    $date_of_event=date("Y-m-d H:i:s");
			mysqli_query($con, "insert into recipients (username, bank_name, bank_address, routing_number, account_number, memo, recipient_name, recipient_nickname, recipient_address, recipient_memo, date_added) values ('{$_SESSION['customer_username']}', '{$bank_name['value']}', '$combine_address', '{$routing_number['value']}', '{$account_number['value']}', '{$memo['value']}', '{$recipient_name['value']}', '{$recipient_nickname['value']}', '$combine_r_address', '{$recipient_memo['value']}', '$date_of_event')");
			if(mysqli_affected_rows($con)==1){
				$msg="Recipient Added Successful!!!";
				setcookie("success","$msg",time() + (3600*5),"/");
				redirect_to("transfer?p=2");
			}else{
				echo mysqli_error($con);
			}
		}
	}



	if(isset($_POST['wire_funds'])){
		
		$wire_from = valid_input($_POST['wire_from']);
		$wire_to = valid_input($_POST['wire_to']);
		$wire_amount = valid_input($_POST['wire_amount']);
		$wire_date = valid_input($_POST['wire_date']);
		$wire_memo = clean_strings($_POST['wire_memo']);
		$description = valid_input($_POST['wire_description']);
		
		if(!empty($errcode)){
			//echo $_POST['wire_date'];
			$msgbox="You have made an errors";//. count($errcode) ." errors";
			echo "
				<script>
					popup('Error Occured!', \"$msgbox\",'error');
				</script>
			";
		}else{
		    if($wire_amount['value'] <= 100000){
    		    if($wire_amount['value'] <= $t_current_balance){
        		    $sql = "update users_info set current_balance = current_balance - {$wire_amount['value']}, available_balance = available_balance - {$wire_amount['value']} where username = '{$_SESSION['customer_username']}'";
        		    mysqli_query($con, $sql);
        			if(mysqli_affected_rows($con)==1){
        				$date_of_event=date("Y-m-d H:i:s");
            			mysqli_query($con, "insert into transactions (username, amount, transfer_from, transfer_to, description, h_address, date_of_event, status) values ('{$_SESSION['customer_username']}', {$wire_amount['value']}, '{$wire_from['value']}', '{$wire_to['value']}', '{$description['value']}', '{$wire_memo['value']}', '{$wire_date['value']}', 'pending')");
            			if(mysqli_affected_rows($con)==1){
            				$msg="Your wire transfer was successful!!!";
            				setcookie("success","$msg",time() + (3600*5),"/");
            				redirect_to("transfer?p=1");
            			}else{
            				$msgbox="You have made an error - ".mysqli_error($con);//. count($errcode) ." errors";
            				echo "
            					<script>
            						popup('Error Occured!', \"$msgbox\",'error');
            					</script>
            				";
            			}
        			}else{
        				$msgbox="You have made an error ".mysqli_error($con);//. count($errcode) ." errors";
        				echo "
        					<script>
        						popup('Error Occured!', \"$msgbox\",'error');
        					</script>
        				";
        			}
    		    }else{
    				$msgbox="Insufficient Balance!!!!";
    				echo "
    					<script>
    						popup('Error Occured!', \"$msgbox\",'error');
    					</script>
    				";
    			}
		    }else{
				$msgbox="Maximum limit of $100,000 exceeded!!!!";
				echo "
					<script>
						popup('Error Occured!', \"$msgbox\",'error');
					</script>
				";
			}
		   
		}
	}
?>