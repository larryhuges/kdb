<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
//include("process_transfer.php");
alert_box();
?>

<style type="text/css">

	.text{
		border: .1rem solid #333;
	}
	
	.bankInput{
		display: block;
		max-width: 30rem; 
		cursor: pointer;
		position: relative;
	}

	.bankInput > div{
		position: absolute;
		top: 0;
		right: 0;
		width: 2rem; 
		height: 2rem;
		z-index: 10;
		margin: 1rem
	}

	table.kdbTable, tr.kdbTable{
		width:100%;
		//min-width:60rem;
		height:auto;
		margin:auto;
		margin-bottom:1%;
		border-collapse:collapse;
		font-family:sans-serif;
		border:.1rem solid #ecf0f5;
	}

.bcenter{
	text-align: center;
}

td.kdbTable, th.kdbTable{
	height:auto;
	vertical-align: center;
	margin:auto;
	border-collapse:collapse;
	border:.1rem solid #bcbcbc;
	font-size:1.2rem;
	padding: 1rem;
}
</style>


<div class='rdCover' id='recentTransfer'>
	<div class='rdMiddle'>
		<div class='rdTop'>
			<span>Recent Transfer Details</span> <i class='fa fa-close' onclick='closePopUP("#recentTransfer")'></i>
		</div>
		<div class='rdBottom'>
			<table class='kdbTable'>
				<th class='kdbTable'>Transaction Date</th>
				<th class='kdbTable'>Bank Name</th>
				<th class='kdbTable'>Deposit Account no</th>
				<th class='kdbTable'>Beneficiary</th>
				<th class='kdbTable'>Transfer Amount (KRW)</th>

				<tr class='kdbTable'>
					<td class='kdbTable'>2019 05 13</td>
					<td class='kdbTable'><p rdBank>THE INDUSTRIAL BANK OF KOREA</p></td>
					<td class='kdbTable'><u style='cursor: pointer;' onclick='selectRD(0); closePopUP("#recentTransfer")' rdAccountNumber>6664-9098-8893-22</u></td>
					<td class='kdbTable'>Louis</td>
					<td class='kdbTable' style='text-align: right'>10</td>
				</tr>
			</table>
		</div>

		<div style='text-align: center; margin-bottom: 2rem;'>
			<button class="tbtn tline" onclick='closePopUP("#recentTransfer")'>
				Close
			</button>
		</div>
	</div>
</div>


<div class='sbCover' id='bankList'>
	<div class='sbMiddle'>
		<div class='sbTop'>
			<span>Deposit Bank</span> <i class='fa fa-close' onclick='closePopUP("#bankList")'></i>
		</div>
		<div class='sbBottom'>
			<div class='sbBank' bankName='KOREA DEVELOPMENT BANK'>
				<img src='../media/images/photo/ico_cscont.png' height='50' /> 
				<p>KOREA DEVELOPMENT BANK</p>
			</div>
			<div class='sbBank' bankName='Bank Of America'>
				<img src='../media/images/photo/ico_cscont.png' height='50' /> 
				<p>Bank Of America</p>
			</div>
			<div class='sbBank' bankName='BNP Panbas'>
				<img src='../media/images/photo/ico_cscont.png' height='50' /> 
				<p>BNP Panbas</p>
			</div>
			<div class='sbBank' bankName='Busan Bank'>
				<img src='../media/images/photo/ico_cscont.png' height='50' /> 
				<p>Busan Bank</p>
			</div>
		</div>
	</div>
</div>

	
<div class='vcCover' id='OTPBox'>
	<div class='vcMiddle'>
		<div class='vcTop'>
			<span>OTP Verification</span> <i class='fa fa-close' onclick='closePopUP("#OTPBox")'></i>
		</div>
		<div class='vcBottom'>
			<h3>
				An OTP code has been sent to your registered email address<br>
				<?php echo $t_email?>
			</h3><br>

			<div style='display: flex; align-items: center; justify-content: center;'>
				<input class='confirmCodeText' maxlength=1 minlength=1 id='confirmCode1'/>
				<input class='confirmCodeText' maxlength=1 minlength=1 id='confirmCode2'/>
				<input class='confirmCodeText' maxlength=1 minlength=1 id='confirmCode3'/>
				<input class='confirmCodeText' maxlength=1 minlength=1 id='confirmCode4'/>
			</div>

			<br><br>

			<button class="tbtn tline" name='transfer_fund' onclick='sendCode()'>
				Resend Code
			</button> &nbsp;&nbsp;&nbsp;&nbsp;
			<button class="tbtn tupd" name='transfer_fund' onclick='confirmCode()'>
				Confirm Authentication
			</button>
		</div>
	</div>
</div>


<style>

	.confirmCodeText{
		width: 4rem;
		height: 5rem;
		padding: .2rem;
		border-radius: .5rem;
		border: .1rem solid #333;
		text-align: center;
		font-size: 3rem;
		margin: 1rem;
	}

	.vcCover{
		display: none;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 300;	
		background-color:#0005
	}

	.vcMiddle{
		width: 100%;
		max-width: 70rem;
		margin: 2rem;
		background-color: #fff;
		border-radius:.5rem;
		overflow: hidden;
	}

	.vcTop{
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: 2rem 3rem;
		background-color: #001F5B;
		color: #fff;
		font-size: 2rem;
	}
	
	.vcBottom{
		width: 100%;
		padding: 2rem 3rem ;
		text-align: center;
	}

	.rdCover{
		display: none;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 300;	
		background-color:#0005
	}

	.rdMiddle{
		width: 100%;
		max-width: 70rem;
		margin: 2rem;
		background-color: #fff;
		border-radius:.5rem;
		overflow: hidden;
	}

	.rdTop{
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: 2rem 3rem;
		background-color: #001F5B;
		color: #fff;
		font-size: 2rem;
	}
	
	.rdBottom{
		width: 100%;
		padding: 2rem 3rem ;
	}

	
	.sbCover{
		display: none;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 300;	
		background-color:#0008
	}

	.sbMiddle{
		width: 100%;
		max-width: 70rem;
		margin: 2rem;
		background-color: #fff;
		border-radius:.5rem;
		overflow: hidden;
	}

	.sbTop{
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: 2rem 3rem;
		background-color: #001F5B;
		color: #fff;
		font-size: 2rem;
	}
	
	.sbBottom{
		display: grid;
		grid-template-columns: 50% 50%;
		gap: 1rem;
		width: 100%;
		padding: 2rem 3rem ;
	}

	.sbBank{
		display: flex;
		align-items: center;
		justify-content: flex-start;
		gap: 2rem;
		width: calc(100% - 2rem);
		margin: 2rem auto;
		cursor: pointer;
		padding: 2rem;
		border: none;
		transition: border .5s ease
	}

	.sbBank:hover{
		border-radius: .5rem;
		border: .1rem solid blue;
	}

	.subSectionTitle{
		position: relative;
		font-weight: bold;
		font-size: 2rem;
		width: 100%;
		border-bottom: .2rem solid #333;
		padding: 1rem 0;
		padding-left: 2.5rem;
		color: #001f5b;
	}

	.subSectionTitle::before{
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		background: url('../media/images/photo/bullet.png') no-repeat left center;
		width: 2.5rem;
		height: 5rem;
	}

	.tsform{
		display: flex;
		align-items: flex-start;
		justify-content: flex-start;
		width: 100%;
		padding: 2rem 2rem 0;
	
	}

	.tsform > div{
		padding: 1rem;
	}

	.tsform > div:first-child{
		width: 20rem;
		text-align: right;
		font-weight: bold;
	}
	
	.tsform > div:last-child{
		width: 100%;
	}

	.preAmount{
		display: flex;
		width: 100%;
	}

	.preAmount p{
		padding: .5rem 1rem ;
		margin: 0 .5rem 1rem 0 ;
		background-color: #E0E8EE88;
		width: auto;
		border-radius: .5rem;
		cursor: pointer;
	}

	.contNoti{
		display: flex; 
		align-items: center; 
		justify-content: flex-start; 
		width: 100%; 
		border-bottom: .1rem solid #0056b2;
		
	}

	.contNoti > div:first-child{
		width: 18rem;
		font-weight: bold;
		padding: 2rem; 
		background-color: #E0E8EE88;;
		text-align: center;
	}

	.contNoti > div:last-child{
		padding: 2rem; 
		display: flex; 
		align-items: center; 
		justify-content: flex-start; 
	}

	.contNoti input{
		width: 2rem;
		height: 2rem ;
		background-color: #0063cc;
		color: #0063cc;
		border-color: #0063cc !important;
	}

	.tfPage{
		display: none;
	}

	.tbtn{
		width: auto; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		margin: auto 1rem;
		min-width: 10rem;
		border-radius: 1rem 0 1rem 0
	}

	.tupd{
		background-color: #0063cc;
		color: #fff;
	}

	.tline{
		background-color: transparent;
		border: 1px solid #0063cc;
		color: #0063cc;
	}

	.tupd:hover{
		background-color: #1174dd;
		color: #fff;
	}


</style>

<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #666; font-size: 1.4rem;">
	<div id="inner-frame">
	<form id='form_' method='POST'>
		<div class='tfPage'>
			<div class='col one_col' style='margin-top: 2rem;'>
				<div class='subSectionTitle'>
					Enter Withdrawal Information
				</div>

				<div class='tsform'>
					<div>
						Widthdrawal account no
					</div>
					<div>
						<?php
							$sacc = "select checking_account, current_balance, available_balance, savings_account from users_info where username = '$t_username'";
							$qacc = mysqli_query($con, $sacc);
							
							if(mysqli_affected_rows($con) >= 1){
								$oacc = mysqli_fetch_assoc($qacc);
							}else{
								echo mysqli_query($con);
							}
						?>
						<select class="text" id="t_from" required name="from" style='max-width: 30rem;'>
							<option><?php echo $oacc['checking_account']; ?></option>
						</select>
						<p>
							withdrawable Amount <b><?php echo number_format($oacc['current_balance'], 2); ?></b> KRW | Balance <b><?php echo number_format($oacc['available_balance'], 2); ?></b> KRW
						</p>
					</div>
				</div>

				<div class='tsform'>
					<div>
						Account Password
					</div>
					<div>
						<input type="password" maxlength='4' minlength='4' class="text" id="t_pin" required placeholder="****" style='max-width: 30rem;'><br>
					</div>
				</div>

			</div>

			<div class='col one_col' style='margin-top: 5rem;'>
				<div class='subSectionTitle'>
					Enter Deposit Information
				</div>

				<div class='tsform'>
					<div>
						Deposit account no
					</div>
					<div>
						<div>
							<div class="text bankInput" onclick='openPopUP("#bankList")'>
								<div><i class="fa fa-angle-down"></i></div>
								<p selectBN><span style='opacity: .7'>Bank Name</span></p>
							</div>
							<input type="hidden" id="t_to" placeholder="" value="" />
						</div>
						<div style='display: flex; align-items: center; justify-content: flex-start; width: 100%; margin-top: 1rem;'>
							<input type="text" id="t_accNum" class="text" required placeholder="Account Number" style='max-width: 30rem;' />
							<p>&nbsp;&nbsp;&nbsp;<u style='cursor: pointer' onclick='openPopUP("#recentTransfer")'>Recently Deposited Accounts</u></p>
						</div>
					</div>
				</div>

				<div class='tsform'>
					<div>
						Transfer Amount
					</div>
					<div>
						<div class='preAmount'>
							<p data-v='1000000'>KRW 1,000,000</p>
							<p data-v='500000'>KRW 500,000</p>
							<p data-v='100000'>KRW 100,000</p>
							<p data-v='50000'>KRW 50,000</p>
							<p data-v='10000'>KRW 10,000</p>
						</div>
						<input type="number" class="text" id="t_amount" required placeholder="Enter Transfer Amount" style='max-width: 30rem; text-align: right;'><br>
						<p>
							<b>Transfer Limit</b> | Balance <b>29,999,999</b> KRW | 1 Times <b>10,000,000</b> KRW | 1 Day <b>20,000,000</b> KRW
						</p>
					</div>
				</div>

			</div>

			<div class='col one_col' style='margin-top: 5rem;'>
				<div class='subSectionTitle'>
					Enter Selected Information
				</div>

				<div class='tsform'>
					<div>
						Transfer Date
					</div>
					<div>
						<div>
							<input type="date" class="text" id="t_date" required style='max-width: 50rem;'>
						</div>
						
					</div>
				</div>

				<div class='tsform'>
					<div>
						Memo (Optional)
					</div>
					<div>
						<textarea placeholder="" class="text" id="t_memo" style="line-height: .2; height: 10rem; max-width: 50rem; "></textarea>
					</div>
				</div>
				<div style='text-align: center; margin: 3rem auto'>
					<button class="tbtn tupd" type='submit' style="">Next</button>
				</div>
			</div>
		</div>

		<div class='tfPage'>
			<div class='col one_col' style='margin-top: 5rem;'>
				<div class='subSectionTitle'>
					Confirm Transfer Information
				</div>
				
				<div>
					<table>
						<th colspan=''>Withdrawal Information</th>
						<th></th>
						<th>Deposit Information</th>

						<tr>
							<td style='text-align: left;'>
								<span id='selectedAccount'>028-9311-0988-723</span><br>
								<?php echo $t_fullname?>
							</td>
							<td>
								<div style='display: flex; align-items: center; justify-content: center; flex-direction: column;'>
									<p>Immediate</p>
									<p style='border-radius: 50%; border: 1px solid blue; width: 4rem; height: 4rem; margin-top: 1rem; display: flex; align-items: center; justify-content: center;'>
									<i class = 'fa fa-angle-right'></i>
									</p>
								</div>			
							</td>
							<td style='text-align: right;'>
								<div style='text-align: right;'>
									<div id='toPaybank'>Chase</div>
									<div id='toPayAccount'>028-9311-0988-723</div><br>
									<div>100 KRW</div>
								</div>
							</td>
						</tr>
						<tr>
							<td colspan='3' style='border-top:1px solid lightgray; border-bottom:1px solid lightgray'>
								<div style='text-align: right; font-weight: bold;'>
									Total 1 records &nbsp;|&nbsp; Total Transfer Amount <span>1,000</span> KRW
								</div>
							</td>
						</tr>
					</table>
				</div>
			</div>

			<div class='col one_col' style='margin-top: 5rem; padding: 3rem; border: 1px solid #0056b2; border-radius: 1rem'>
				<div class='col one_col cus' style='padding: 1rem 0 0 7rem; background: url(../media/images/photo/ico_cscont.png) no-repeat 0 0; background-size: contain; height: 5rem'>

					<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem; font-weight: bold;'>Please check again!</span>

				</div>

				<div class='col one_col' style='margin: 2rem 0 0 0;'>
					<ul style='margin-left: 3rem; line-height: 2;'>
						<li>
							If you receive a phone call requesting your OTP number (or security card) do not provide them with any information
						</li>
						<li>
							Please check the transfer information again such as the account number and beneficiary
						</li>
					</ul>
				</div>
			</div>

			<div class='col one_col' style='margin-top: 5rem;'>
				<div class='subSectionTitle'>
					Receive Transfer Failure?
				</div>
				
				<div class='contNoti'>
					<div>
						Receive Status
					</div>
					<div>
						<input type='radio' name='notii' checked /> &nbsp;&nbsp; Agreed tot Receive Notifications &nbsp;&nbsp;&nbsp;

						<input type='radio' name='notii'/> &nbsp;&nbsp; Not Agreed tot Receive Notifications
					</div>
				</div>

				<div class='contNoti'>
					<div>
						Contact Number
					</div>
					<div>
						<?php echo $t_mobile?> &nbsp;&nbsp;
					</div>
				</div>
			</div>

			<div class='col one_col' style='margin-top: 5rem;'>
				<div class='subSectionTitle'>
					Security Verification
				</div>
				
				<div style='padding: 2rem; text-align: center; font-weight: bold; background-color: #E0E8EE88; color: #0063cc'>
					<i class='fa fa-info-circle'></i> Security verification can be different in considiration of the risk per transaction/condition and security service you have applied.
				</div>
				
				<div style='text-align: center; padding: 2rem'>
					<p>
						Send OTP verification code to your registered email to complete transaction
					</p><br>
				</div>

				<div style='text-align: center; margin: 3rem auto'>
					<button class="tbtn tline" onclick='loadPage(0)' style="">Back</button>
					<button class="tbtn tupd" onclick='sendCode()' style="">Send Code</button>
				</div>
			</div>
		</div>

	
<style>

	*{
		box-sizing: border-box;
	}

	table{
		width: 100%;
		border-collapse: collapse;
	}

	th{
		padding: 1.5rem;
		background-color: #E0E8EE88;
	}

	tr{
		width: 100%;
	}

	td{
		text-align: center;
		padding: 1.5rem;
	}
</style>
		
		<div class='tfPage'>
			
			<div class='col one_col' style='margin-top: 5rem; padding: 3rem; border: 1px solid #0056b2; border-radius: 1rem; display: flex; flex-direction:column; justify-content: center; align-items: center'>
				<div class='' style='padding: 0;
    background: #f5f7fb url(../media/images/photo/ico_cscont.png) no-repeat center center; background-size: contain; height: 5rem; width: 5rem; margin: 0; margin-top: -6rem'>
				</div>

				<div style='margin: 3rem auto 2rem; color: #001f5b; font-size: 2rem; font-weight: bold; text-align: center;'>The individual transfers you have requested have been processed as the following</div>

			</div>

			<div class='col one_col' style='margin-top: 5rem;'>
				<div class='subSectionTitle'>
					Transfer Result
				</div>
				
				<div>
					<table>
						<th colspan='3'>Withdrawal Information</th>
						<th>Deposit Information</th>
						<th>Result</th>

						<tr>
							<td style='text-align: right; width: 20%'>
								<input type='checkbox' />
							</td>
							<td style='text-align: left;'>
								<span id='selectedAccount2'>028-9311-0988-723</span><br>
								<?php echo $t_fullname?>
							</td>
							<td>
								<div style='display: flex; align-items: center; justify-content: center; flex-direction: column;'>
									<p>Immediate</p>
									<p style='border-radius: 50%; border: 1px solid blue; width: 4rem; height: 4rem; margin-top: 1rem; display: flex; align-items: center; justify-content: center;'>
									<i class = 'fa fa-angle-right'></i>
									</p>
								</div>
							</td>
							<td style='text-align: left;'>
								<div id='toPaybank2'>Chase</div>
								<div id='toPayAccount2'>028-9311-0988-723</div><br>
								<div>100 KRW</div>
							</td>
							<td>
								Processing
							</td>
						</tr>
						<tr>
							<td colspan='7' style='border-top:1px solid lightgray; border-bottom:1px solid lightgray'>
								<div style='text-align: right; font-weight: bold;'>
									Total 1 records (Success 1item, Error0records) &nbsp;|&nbsp; Total Transfer Amount <span>1,000</span> KRW
								</div>
							</td>
						</tr>
					</table>
				</div>
				
			</div>
		</div>
		</form>
	</div>
</div>
 <!-- 
		Reminders:

• To protect yourself, do not login to SC online banking through hyperlinks embedded in emails, unauthorized or third party websites.

• Our Bank will never ask you for your sensitive account information, e.g. username, password and other confidential account or credit card information by email.

• Standard Chartered Hong Kong has not authorized any third party aggregator applications to access our systems nor customer information. You are reminded not to disclose your online banking usernames and passwords to third parties.

• Please read the Legal Notice and Data Protection and Privacy Policy before using the online services or this Web Site. If you do not accept these terms and conditions, do not access this Web Site and do not use the online service. -->
	<?php
		$page = 0;
		if(isset($_GET['p'])){
			$page = $_GET['p'];
		}
	?>

	<script type="text/javascript" src='./transferjs.js'></script>

<?php 
include("includes/member_foot.php");
?>
