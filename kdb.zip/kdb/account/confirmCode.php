<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
	if(isset($_POST['confirmCode'])){
		$confirmCode = clean_strings($_POST['confirmCode']);
		$email = $_SESSION['customer_email'];
		mysqli_query($con, "select id from users_info where verification_code = '$confirmCode' and email = '$email'");
		if(mysqli_affected_rows($con) == 1){
			$code = mt_rand(1000, 9999);
			//mysqli_query($con, "update users_info set verification_code = '$code' where email = '$email'");
			echo "OK";
		}
	}
?>