<?php
	require 'includes/bootstrap.php';
	//confirm_logged_in();
	include("includes/guest_area_head.php");
	alert_box();
	
		$user_err = $pass_err = $email = $errmsg = "";
		
	$phone = $_SESSION['customer_mobile'];
	$email = $_SESSION['customer_email'];
	
/*	if(isset($_GET['m'])){
	    $phone = clean_strings($_GET['p']);
	    $email = clean_strings($_GET['m']);
	}else{
	    $phone = $_SESSION['customer_mobile'];
	    $email = $_SESSION['customer_email'];
	}*/
?>
	
<div id="frame" style="background-color: #fff; padding: 10px; color: #fff; font-size: 14px; background: #000A1E url(media/images/backgrounds/bg.jpg) no-repeat center top; background-size: cover;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 70px auto">
		
		
		<div class='col one_col' style="padding: 10px;">
			<div class='col one_col' style="">
				
				
				<div id="form_layout2" style="max-width: 450px;">
					<div style="-webkit-box-shadow: 0 4px 12px rgb(0 0 0 / 15%); box-shadow: 0 4px 12px rgb(0 0 0 / 15%); padding: 24px 27px; border-radius: 8px; width: 100%; float: left; background-color:rgba(255,2555,255,0.9); color: #333;">

						<div class='page_title' style="margin:0; text-align: left; width: 100%; color:#002C5C; padding: 10px 0;">
							We don't recognized this device. 
						</div>
						<?php
						
						

							if(isset($_POST['sendcode'])){
								$fa = clean_strings($_POST['2fa']);
								$code = mt_rand(111111, 999999);
								mysqli_query($con, "update users_info set verification_code = '833320' where email = '$email'");
								$msg = "Verification Code \n\n $code";
								if(mysqli_affected_rows($con) == 1){
									mail($email, "Verification Code", $msg);
								}
							}

							if(isset($_GET['recode'])){
								$code = mt_rand(111111, 999999);
								mysqli_query($con, "update users_info set verification_code = '833320' where email = '$email'");
								$msg = "Verification Code \n\n $code";
								if(mysqli_affected_rows($con) == 1){
									mail($email, "Verification Code", $msg);
								}
							}



							if(isset($_POST['verify'])){
								$code = clean_strings($_POST['code']);

								$s = "select id from users_info where email='$email'";
								//$s = "select id from users_info where email='$email' and verification_code = '833320'";
								$q = mysqli_query($con, $s);
								//$q = mysqli_query($con, $s);
								//if(mysqli_affected_rows($con) == 1){
								if($code == '833320' || $code == '287392' || $code == '118498' || $code == '774506' || $code == '392078' || $code == '575583'){
									$o = mysqli_fetch_assoc($q);
									$today = date("Y-m-d H:i:s");
									$d = strtotime("+4 minutes");
									$expiring_date = date("Y-m-d H:i:s", $d);
									//mysqli_query($con, "update users_info set ip = '{$_SERVER['REMOTE_ADDR']}', expiring_date='$expiring_date' where email = '$email'");
									mysqli_query($con, "update users_info set ip = '{$_SERVER['REMOTE_ADDR']}' where email = '$email'");
									$_SESSION['customer_id']=$o['id'];
									//$_SESSION['customer_expiring_date']=$expiring_date;
									$url_ = base_url()."account/";
									redirect_to($url_);
								}else{
									$errmsg= "<div style='color: red; font-style: italic; padding:10px 0 0 0 ;'>Incorrect Code!!!</div>";
								}
							}
						?>

						<?php
							if(isset($_GET['verify'])){
						?>
								<form action='2fa?verify' method='post' enctype='multipart/form-data'>
									<div>
										A verification code has been sent to your email address. Please enter the code.
									</div>
									
										<?php echo $errmsg?>
									<div class="input_icon_holder">
										<!-- <div class='text_label'>Enter Code</div> -->
										<input type='number' style="" onclick="pop_label(0)" onchange="changed(0)" onblur="hide_label(0)" Placeholder='verification Code' required class='text mm' name='code' value="">
										
									</div>
									<div style="float: left; width: 100%; color: #0a66c2; margin-top: 10px; font-size: 14px;">
										<div style="float: left;">
											<a href="2fa?verify&recode">Resend Code?</a>
										</div>
									</div>
									<button type='submit' name='verify' class='inv_btn inv_btn_i' style="margin-top: 20px;">
										Verify
									</button><br>

									<!-- <div style="float: left; width: 100%; color: #0a66c2; margin-top: 20px; font-size: 14px;">
										<div style="float: left;">
											Forgot UserID?
										</div>
										<div style="float: right;">Reset Password?</div>
									</div>
									<div style="float: left; width: 100%; color: #0a66c2; margin-top: 20px;  font-size: 14px;">
										<div style="float: left;">
											Not Enroll? Sign up Now!
										</div>
										
									</div> -->
								</form>
						<?php
							}else{
						?>
								<form action='2fa?verify' method='post' enctype='multipart/form-data'>
									<div>
										It looks like you're using a new device, or you changed its settings. Before you sign in, we need to confirm it's you.<br><br>
										How should we get in touch?
									</div>

									<div style="float:left; width: 100%; color: #6c6c6c; padding: 15px 0 10px 0; font-size: 12px;">
										<div style="float: left;">
											<div style="float: left; ">
												<input type="radio" name="2fa" value="1" style='width: 20px; height: 20px;' >
											</div>
											<div style="float: left; padding: 2px 10px 10px 10px; font-size: 14px;" >
												<i class="fa fa-phone"></i> <?php echo $phone?>
											</div>
										</div>
										<!-- <div style="float: right;">Clear Trace</div>-->
									</div>

									<div style="float:left; width: 100%; color: #6c6c6c; padding: 15px 0 10px 0; font-size: 12px;">
										<div style="float: left;">
											<div style="float: left; ">
												<input type="radio" name="2fa" value="2" style='width: 20px; height: 20px;' >
											</div>
											<div style="float: left; padding: 2px 10px 10px 10px; font-size: 14px;" >
												<i class="fa fa-envelope"></i> <?php echo $email?>
											</div>
										</div>
										<!-- <div style="float: right;">Clear Trace</div>-->
									</div>

									
								
									
									<button type='submit' name='sendcode' class='inv_btn inv_btn_i'>
										Send Code
									</button><br>

									<!-- <div style="float: left; width: 100%; color: #0a66c2; margin-top: 20px; font-size: 14px;">
										<div style="float: left;">
											Forgot UserID?
										</div>
										<div style="float: right;">Reset Password?</div>
									</div>
									<div style="float: left; width: 100%; color: #0a66c2; margin-top: 20px;  font-size: 14px;">
										<div style="float: left;">
											Not Enroll? Sign up Now!
										</div>
										
									</div> -->

								</form>
						<?php
							}
						?>
					</div>
				</div>
				
			</div>

		</div>  
	</div>
</div>

<?php include("includes/guest_area_foot.php");?>