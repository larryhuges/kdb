<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
alert_box();
?>

<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
	<div class='bread_c'>
		<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Purchase Plan
	</div></span>
</div>
<div class="g_col" style="width: 100%; margin: 0; padding: 20px 0; box-shadow: none;  background-color: transparent;">
<?php
$deposit=$plan=$errmsg=$date_pledged=$life_span=$range=$amount=$payment_method=$amount_err=$payment_method_err="";
	if(isset($_POST['submit_deposit'])){
		
		$plan=clean_strings($_POST['plan_input']);

		if(empty($_POST['amount'])){
			$amount_err="Amount is Required";
			$errcheck=1;
		}else{
			$amount=clean_strings($_POST['amount']);
			if(!preg_match("/^[0-9]*$/",$amount)){
				$amount_err="Only Numbers are allowed";
				$errcheck=1;
			}	
		}

		if(empty($_POST['payment_method']) || $_POST['payment_method']=="Select Payment Method"){
			$payment_method_err="Select Payment Method";
			$errcheck=1;
		}else{
			$payment_method=trim(clean_strings($_POST['payment_method']));
			if(!preg_match("/^[a-zA-Z]*$/",$payment_method)){
				$payment_method_err="Only Alphabets and Numbers are allowed";
				$errcheck=1;
			}
				
		}

		if($plan=='SILVER'){
			if($amount<200 || $amount>1000){
				$amount_err="Amount must lie between $200 and $1000 for SILVER Plan";
				$errcheck=1;
			}else{
				$rate=0.1;
				$life_span=1;
			}
		}elseif($plan=='GOLD'){
			if($amount<1000 || $amount>5000){
				$amount_err="Amount must lie between $1000 and $5000 for GOLD Plan";
				$errcheck=1;
			}else{
				$rate=0.1;
				$life_span=2;
			}
		}elseif($plan=='PLATINIUM'){
			if($amount<3000 || $amount>10000){
				$amount_err="Amount must lie between $3000 and $10000 for PLATINIUM Plan";
				$errcheck=1;
			}else{
				$rate=0.1;
				$life_span=3;
			}
		}elseif($plan=='DIAMOND'){
			if($amount<8000 || $amount>30000){
				$amount_err="Amount must lie between $8000 and $30000 for DIAMOND Plan";
				$errcheck=1;
			}else{
				$rate=0.1;
				$life_span=4;
			}
		}

		if($errcheck==1){
			$msg="Mining Subscription (of $ $deposit) was not successful!!!";
			echo "
					<script>
						popup(\"$msg\",'error');
					</script>
				";
		}else{
			$_SESSION['amount']=$amount;
			$_SESSION['payment_method']=$payment_method;
			$_SESSION['plan']=$plan;
			if($payment_method=='Visa' || $payment_method=='Mastercard'){
				redirect_to("../simplex/payments/new");
			}else{
				redirect_to("payment");
			}
		}
	}
?>
	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #fff; box-shadow: 0px 1px 1px #ddd; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; color:#222d32;  font-size: 26px; font-family: signika; font-weight: normal;'>
				SILVER (Stater)
				<hr style="width: 100%; border-color:#222d32;">
			</div>
				
			<div class='m_col' style="padding:2%; width: 50%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$200 - $1,000</h4>
				<h4 style="color: #222d32; font-family: signika;">1 Year Mining Contract</h4>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%; width: 50%;">
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("SILVER")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>

	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #fff; box-shadow: 0px 1px 1px #ddd; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; color:#222d32; font-size: 26px; font-family: signika; font-weight: normal;'>
				GOLD (Best Buy)
				<hr style="width: 100%; border-color:#222d32;">
			</div>
				
			<div class='m_col' style="padding:2%; width: 50%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$1,000 - $5,000</h4>
				<h4 style="color: #222d32; font-family: signika;">2 Years Mining Contract</h4>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%; width: 50%;">
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; color: #222d32; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; color:#222d32; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("GOLD")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>
	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #fff; box-shadow: 0px 1px 1px #ddd; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; color:#222d32; font-size: 26px; font-family: signika; font-weight: normal;'>
				PLATINUM
				<hr style="width: 100%; border-color:#222d32;">
			</div>
				
			<div class='m_col' style="padding:2%; width: 50%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$5,000 - $10,000</h4>
				<h4 style="color: #222d32; font-family: signika;">1 Year Mining Contract</h4>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%; width: 50%;">
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("PLATINUM")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>
	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #fff; box-shadow: 0px 1px 1px #ddd; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; color:#222d32; font-size: 26px; font-family: signika; font-weight: normal;'>
				DIAMOND
				<hr style="width: 100%; border-color:#222d32;">
			</div>
				
			<div class='m_col' style="padding:2%; width: 50%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$800 - $30,000</h4>
				<h4 style="color: #222d32; font-family: signika;">4 Year Mining Contract</h4>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#999; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%; width: 50%;">
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; color:#222d32; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("DIAMOND")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>

</div>
<div id='alert_box_holder'>
	<div id="alert_box_center" style="margin-top: 5%; margin-bottom: 0;">
		<div id='alert_box' style="padding: 10% 5% 5% 5%; border-radius: 0;">
			<form action='' method='post' enctype='multipart/form-data'>
				<h2 style='color:#3b3; text-align: center; font-family: page_font_rob;'>
					Confirm Purchase
				</h2>
				<br>
				<p style='color:#555; text-align: center; font-family: page_title_font; font-size: 16px;'>
					You are about to purchase <b><span name='plan'><?php echo strtoupper($plan);?></span> PLAN</b>
				</p><br>
				
				<div class="input_icon_holder2">
					<div style="display: table-caption;"><?php echo errmessage_design($amount_err)?></div>
					<span class="input_icon2"><i class="fa fa-money"></i></span>
					<input type='text' value="<?php echo $amount;?>" placeholder='Enter Amount Between <?php echo $range;?>' required class='text' name='amount'>
					<input type='hidden' value="<?php //echo $plan_input;?>" required class='text' name='plan_input'>
				</div>

				<div class="input_icon_holder2">
					<div style="display: table-caption;"><?php echo errmessage_design($payment_method_err)?></div>
					<span class="input_icon2"><i class="fa fa-money"></i></span>
					<select type='text' required class='text' name='payment_method'>
						<option>Select Payment Method</option>
						<option>Visa</option>
						<option>Mastercard</option>
						<option>Bitcoin</option>
					</select>
				</div>

				<button type='submit' style="margin:0; float:left;" name='submit_deposit' class='btn upd'>
					Continue <i class="fa fa-carat-right"></i>
				</button>
				<button type='button' onclick="close_alert()" style="margin:0; float:right;" name='submit_deposit' class='btn del'>
					Cancel
				</button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">

	function invest_now(str){
		var range;
		if(str=='SILVER'){
			range="$200 - $1000";
		}else if(str=='GOLD'){
			range="$1000 - $5000";
		}else if(str=='PLATINUM'){
			range="$5000 - $10000";
		}else if(str=='DIAMOND'){
			range="$8000 - $30000";
		}
		var x=document.getElementById('alert_box_holder');
		var amount=document.getElementsByName('amount');
		var plan=document.getElementsByName('plan');
		var plan_input=document.getElementsByName('plan_input');
		amount[0].placeholder="Enter Amount "+range;
		plan[0].innerHTML=str;
		plan_input[0].value=str;
		x.style.display='block';
	}

	function close_alert(){
		var x=document.getElementById('alert_box_holder');
		x.style.display='none';
	}
</script>
<?php 
include("includes/member_foot.php");
?>