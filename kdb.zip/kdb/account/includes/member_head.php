<?php
	$username=$_SESSION['customer_username'];

	$t_query=mysqli_query($con, "select * from `users_info` where username='$username' limit 1");
	$t_out=mysqli_fetch_assoc($t_query);
	$t_fullname=$t_out['firstname']." ".$t_out['lastname'];
	$t_username=$t_out['username'];
	$t_verified=$t_out['verified'];
	$t_referral=$t_out['referral'];
	$t_email=$t_out['email'];
	$t_mobile=$t_out['mobile'];
	$t_photo=$t_out['photo'];
	$t_account_name=$t_out['account_name'];
	$t_checking_account=$t_out['checking_account'];
	$t_saving_account=$t_out['savings_account'];
	$t_credit_card=$t_out['credit_card'];
	$t_bank_name=$t_out['bank_name'];
	$t_current_balance=$t_out['current_balance'];
	$t_available_balance=$t_out['available_balance'];
	$t_s_current_balance=$t_out['s_current_balance'];
	$t_s_available_balance=$t_out['s_available_balance'];
	$t_cc_current_balance=$t_out['cc_current_balance'];
	$t_cc_available_balance=$t_out['cc_available_balance'];
	

	if(trim($_SERVER['REQUEST_URI'], "/") == 'account/index' || trim($_SERVER['REQUEST_URI'], "/") == 'account/index.php' || trim($_SERVER['REQUEST_URI'], "/") == 'account/' || trim($_SERVER['REQUEST_URI'], "/") == 'account'){
		echo null;
	}else{
		if($t_verified == 'No'){
			redirect_to('/account');
		}
	}
	//echo $_SERVER['REQUEST_URI'];
	//exit()

?>

<?php 
		$selecedMPP = '';
	$selecedMPC = '';
	$selecedMP = '';
	$selecedMC = '';
	
	if(isset($_GET['u'])){
		if($_GET['u'] == 'personal'){
			$selecedMPP = 'selected';
			$selecedMPC = '';
			$selecedMP = 'showM';
			$selecedMC = 'hideM';
		}elseif($_GET['u'] == 'corporate'){
			$selecedMPC = 'selected';
			$selecedMPP = '';
			$selecedMC = 'showM';
			$selecedMP = 'hideM';
		}
	}

?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<![if !IE]>
<link rel="icon" href="../media/images/photo/global.png" type="image/x-icon">
<![endif]>
<link rel="shortcut icon" href="../media/images/photo/global.png" type="image/ico">

<link rel="stylesheet" href="../css/my_cssstyle.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title>My Account</title>

</head>

<body style="background-color: #F0F8FF">

<script>
function popup(title, msg, status){

	var modal=document.getElementById('popdown');
	var message=document.getElementById('message');
	var message_title=document.getElementById('message_title');
	var message_icon=document.getElementById('message_icon');
	
	message.innerHTML=msg;
	modal.className=status;
	message_title.innerHTML=title;

	if(status=='error'){
		message_icon.src = '../../media/images/photo/error.png';
		message_title.style.color="#b00";
	}else if(status=='added'){
		message_icon.src = '../../media/images/photo/success.png';
		message_title.style.color="#3b3";
	}
}

function close_popup(){
	var y=document.getElementById('pop_alert_box');
	y.style.animation='d_out .5s ease';
	setTimeout(function (){document.getElementById('popdown').style.display='none';},500);
	
}

function toggle_menu_id2(id){//alert('hhh')
	var x=document.getElementById(id);
	if(x.style.display=='block'){
		x.style.animation='hide_menu_scroll_left .5s ease';
		setTimeout(function (){x.style.display='none'},500);
	}else{
		x.style.animation='show_menu_scroll_left .5s ease';
		x.style.display='block';
	}
}

function s_menu(){
	var opt=document.getElementById("side_nav");
	if(opt.style.display=="block"){
		opt.style.animation="undo_drop_side ease .5s";
		setTimeout(function (){opt.style.display="none"},500);
		//opt.style.display="none";
		//document.getElementById("bckgrd").style.display="none";
	}else{
		opt.style.animation="drop_side ease .5s";
		opt.style.display="block";
		
		//document.getElementById("bckgrd").style.display="block";
	}
	
}
</script>

 
<style>
	
/*=========================================== 로딩 ==============================================*/
.jexjs-indicator-wrap {
	display: none;
	position: fixed;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	width: 100%;
	height: 100%;
	z-index: 9999999990;
	text-align: center;
	background: rgba(0, 0, 0, 0);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#00000000, endColorstr=#00000000);
	background: rgba(255, 255, 255, 0.7);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#40000000, endColorstr=#40000000);
}

.jexjs-indicator-bg {
	position: fixed;
	top: 0;
	left: 0;
	bottom: 0;
	right: 0;
	width: 6rem;
	height: 6rem;
	margin: auto;
	background-color: #fff;
	border-radius: 50%;
	overflow: hidden;
	box-shadow: 0 0 2rem 0 rgba(0, 0, 0, 0.3)
}

.jexjs-indicator-img:before {
	content: '';
	position: relative;
	display: block;
	width: 100%;
	height: 100%;
	background: url(../media/images/photo/bg_loading.png) no-repeat 0 0;
	z-index: 2
}

.jexjs-indicator-img:after {
	content: '';
	position: absolute;
	top: 0;
	left: 0;
	display: block;
	width: 100%;
	height: 100%;
	background: url(../media/images/photo/bg_loading.png) no-repeat 0 bottom;
	z-index: 1
}

/* modal, active */
.jexjs-indicator.modal,
.jexjs-indicator-target.modal {
	background: rgba(255, 255, 255, 0.6);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#40000000, endColorstr=#40000000);
}

.jexjs-indicator.active,
.jexjs-indicator-target.active {
	display: block;
}

.jexjs-indicator-img:after {
	-webkit-animation: jexLoading 0.5s linear infinite;
	animation: jexLoading 0.5s linear infinite;
}

@-webkit-keyframes jexLoading {
	0% {
		transform: rotate(0)
	}

	100% {
		transform: rotate(360deg)
	}
}

@keyframes jexLoading {
	0% {
		transform: rotate(0)
	}

	100% {
		transform: rotate(360deg)
	}
}

.pages{
		display: none
	}

	.tfPage{
		display: none;
	}

	@keyframes showPage {
		from {opacity: 0; margin-top: 2rem;}
		to {opacity: 1; margin-top: 0rem;}
	}

</style>
<div id="jexjs-indicator-wrap" class='jexjs-indicator-wrap'>
	<div name="jexjs-indicator-theme-default" class="jexjs-indicator">
   	<div class="jexjs-indicator-bg"><span class="jexjs-indicator-img"></span></div>
  </div>
  <div name="jexjs-indicator-theme-modal" class="jexjs-indicator modal">
	<div class="jexjs-indicator-bg"><span class="jexjs-indicator-img"></span></div>
  </div>
</div>
<script>
	
const loader = document.querySelector('.jexjs-indicator-wrap')
loader.style.display = 'flex'

	document.addEventListener('DOMContentLoaded', () => {
		console.log('DOM Loaded')
		setTimeout(() => {
			loader.style.display = 'none'
		}, 3000)
	})
</script>
 <style>
        	#inner-frame{
				max-width:110rem;
				width:100%;
				height:auto;
				margin:0 auto;
				padding:1.0rem;
				position:relative;
				overflow-x:hidden;
			}
         ul{
            display: flex;
            list-style: none;
            margin-top: .1rem;
            height: calc(100% - .1rem);
        }

        li{
            margin: auto 2.0rem;
            font-size: 1.2rem;
        }
		  
        .menu{
            position: fixed;
            width: 100%;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
				z-index: 100;
		  }

        .top{
            height: 3.5rem;
            width: 100%;
            background-color: #0063cc;
            position: relative;    
        }

		.top #inner-html{
			height: 100%;   
		}

        .top ul {
            width: 35rem;
            height: 3.0rem;
            margin-top: .5rem;
            border-radius: 1.0rem 1.0rem 0 0;
            background-color: #001f5b;
        }

        .top ul li{
            position: relative;
            background-color: transparent;
            font-weight: 600 ;
            font-size: 1.6rem;
            width: 15rem;
												height: 3rem;
            cursor: pointer;
            color: #fff;
            margin: auto 1.0rem;
												padding: .2rem;
            //padding: auto 2.0rem;
											//background-color: red;
												text-align: center;
        }

		.top ul li p{
            position: relative;
            background-color: transparent;
            font-weight: 600 ;
            font-size: 1.6rem;
            width: 15rem;
			height: 3rem;
            cursor: pointer;
            color: #fff;
			text-align: center;
        }

        .personal, .corporate{
			left: -1rem;
            background-color: #fff;
            position: absolute;
            height: 3.0rem;
            width: 16.5rem;
            bottom: 0;
            border-radius: 1.0rem .6rem 0 0;
			display: none;
        }

		.corporate{
			left: 0;
		}
        
        .selectedAng{
            position: absolute;
            height: 0;
            width: 0;
            bottom: 0;
            right: -1.3rem;
            border-bottom: 2.9rem solid #fff;
            border-right: 1.5rem solid transparent;
        }

		.showM{
			display: block;
		}

		.hideM{
			display: none;
		}

		.top ul li p.selected{
			color: #0063cc;
			border-bottom: 1px solid #0063cc;
        }

		  .middle{
            height: 5.0rem;
            width: 100%;
            background-color: white;
            position: relative;
												border-bottom: 2px solid #0001
        }

        .middle ul{
            position: relative;
            background-color: #fff;
            z-index: 2;
        }
        
		  .middle ul li{
           font-size: 1.6rem;
        }

        .bottom{
				display: none;
            height: 3.5rem;
            width: 100%;
            background-color: #E0E8EE88;
        }

		  .bottom #inner-html{
				display: flex;
				align-items: center;
            height: 3.5rem;   
        	}

			.bottom ul li{
            cursor: pointer;
       	}

        @keyframes hideTop {
            from{ top: 0}
            to{ top: -3.2rem}
        }
        
        @keyframes showTop {
            from{ top: -3.2rem}
            to{ top: 0}
        }
       
        @keyframes moveRight {
            from{ margin-left: 0}
            to{ margin-left: 18.0rem}
        }

         @keyframes moveZero {
            from{ margin-left: 18.0rem}
            to{ margin-left: 0}
        }
       
        @keyframes fadeMenuIn {
            from{ background-color: #E0E8EE88}
            to{ background-color: #0063cc}
        }

         @keyframes fadeMenuOut {
            from{ background-color: #0063cc}
            to{ background-color: #E0E8EE88}
        }

		  
        .popMenuCover{
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #0008;
            z-index: 100;
        }

        .popMenuContentHolder{
            height: 100%;
            width: 50%;
            background-color: #fff;
            float: right;
            
        }

        .popMenuHead{
            background-color: #001f5b;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.0rem 2.0rem;
            color: #fff;
        }

        .popMenuHead span{
            font-size: 3.0rem;
            cursor: pointer;
        }

        .popMenuBody{
            display: flex;
            justify-content: space-between;
        }

        .popMenuContentCols{
            width: 50%;
        }

        .popMenuContent{
            width: 100%;
            height: auto;
            padding: 2.0rem;
        }

        .popMenuContent ul{
            display: flex;
            flex-direction: column;
        }

        .popMenuContent ul li{
            margin: 0;
           padding: 1.0rem;
           font-size: 1.5rem;
		   border-bottom: 1px dotted #0063cc;
		   position: relative;
			padding-left: 2.5rem;
        }

		.popMenuContent ul li::before{
			content:'';
			position: absolute;
			left: 0;
			width: 2rem;
			height: 2rem;
			background: url('../media/images/photo/bullet.png') no-repeat center center;
		}

		  .menuIco{
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
		  }

		   @keyframes fadeIn {
            from{opacity: 0}
            to{opacity: 1}
        }
       
        @keyframes fadeOut {
            from{opacity: 1}
            to{opacity: 0}
        }

         @keyframes menuMoveIn {
            from{margin-right: -10.0rem;}
            to{margin-right: 0;}
        }
       
        @keyframes menuMoveOut {
            from{margin-right: 0;}
            to{margin-right: -10.0rem;}
        }

		  .pTitle{
			float: left; 
			width: 100%; 
			padding: 1.0rem; 
			padding-bottom: 2.0rem;
			border-bottom: .2rem solid #333; 
			color: #0063cc; 
			font-size: 2rem; 
			font-weight: bold;
		  }

    </style>
    <div class="menu">
		 <div class="top">
				<div id="inner-frame" style="padding: 0 1rem; height: 100%;">
					
					<a href='/'>
						<div style="padding: .2rem; padding-top: .7rem; margin-right: 2.0rem; float: left">
							<img src="../media/images/photo/logo3.png" height="20">
						</div>
					</a>
					<ul>
						<a href='?u=personal'><li class="">
							<div class="personal <?php echo $selecedMP?>"><div class="selectedAng"></div></div>
							<p class='<?php echo $selecedMPP?>'>Personal Banking</p>
						</li></a>
						<a href='?u=corporate'><li class="">
							<div class="corporate <?php echo $selecedMC?>"><div class="selectedAng"></div></div>
							<p class='<?php echo $selecedMPC?>'>Corporate Banking</p>
						</li></a>
					</ul>
				</div>
			</div>
			<div class="middle">
				<div id="inner-frame" style="padding: 0 1rem; height: 100%; display: flex; justify-content: space-between; color: red">
		  			<p style="position: absolute; z-index: 1; background-color: #fff; display: flex; align-items: center; justify-content: center; margin-top: 1.2rem ; padding-right: 3.0rem; border-right: .1rem solid #0063cc; font-weight: bold; color: #0063cc; font-size; 2.0rem">
								Personal Banking

							</p>
							<ul>
								<li><a href="/">Accounts</a> </li>
								<li><a href="transfer">Transfer money</a> </li>
								<li><a href="exchange">Exchange</a> </li>
								<li><a href="update_profile">Banking Management</a> </li>
							</ul>
		  			
					<i class='fa fa-bars menuIco' style='color: #0063cc; font-size: 2.5rem' onclick='showPopMenu()'></i>
				</div>
			</div>
			<?php
				$sh = '';
				if(trim($_SERVER['REQUEST_URI'], "/") == 'account/transfer' || trim($_SERVER['REQUEST_URI'], "/") == 'account/transfer.php'){
					$sh = 'style="display: block;"';
				}
			?>
				<div class="bottom" <?php echo $sh?>>
					<div id="inner-frame" style="padding: 0 1rem; height: 100%;">
						<ul>
								<li><a href="transfer.php">Transfer</a></li>
								<li><a href="#">Scehdule Wire</a></li>
								<li><a href="transfer-activities.php">Transfer Activities</a></li>
						</ul>
					</div>
				</div>
			
			
    </div>

    <script>
        let check = false
        document.addEventListener('scroll', (e) => {
            let sb = document.querySelector('.menu')
            if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 40) {
                check = true
                sb.style.top = '-3.2rem'
                sb.style.animation = 'hideTop .3s ease'
                document.querySelector('.middle ul').style.marginLeft = '18.0rem'
                document.querySelector('.middle ul').style.animation = 'moveRight .5s ease'
                document.querySelector('.bottom').style.backgroundColor = '#0063cc'
					 
					 document.querySelectorAll('.bottom li a').forEach((li) => li.style.color = '#ffffff')
                document.querySelector('.bottom').style.animation = 'fadeMenuIn 1s ease'
            } else {
                if (check) {
                    check = false
                    sb.style.top = '0'
                    document.querySelector('.middle ul').style.marginLeft = '0'
                    document.querySelector('.bottom').style.backgroundColor = '#E0E8EE88'
						  document.querySelectorAll('.bottom li a').forEach((li) => li.style.color = '#0063cc')
                    sb.style.animation = 'showTop .3s ease'
                    document.querySelector('.middle ul').style.animation = 'moveZero .5s ease'
                    document.querySelector('.bottom').style.animation = 'fadeMenuOut 1s ease'
                }
            }
            
        })
    </script>
<div id="frame" style=" margin-top:11.5rem; ">
	<div id="inner-frame" style="padding: 0 1rem;">
		
	</div>	
</div>

<div class="popMenuCover">
        <div class="popMenuContentHolder">
            <div class="popMenuHead">
               <div style='display: flex; align-items: center;'>
		  				<div style='width: 4rem; height: 4rem; background-color: white; border-radius: 2rem; margin-right: 1rem;'>
							<img src='../<?php echo $t_photo ?>' style='width: 4rem; border-radius: 2rem;' />
						</div>
		  				<div style='font-weight: bold;'>
							<?php echo $t_fullname?>
						</div>
					</div>
                <span onclick="hidePopMenu()"> &times; </span>
            </div>
            <div class="popMenuBody">
                <div class="popMenuContentCols">
                    <div class="popMenuContent">
                        <ul>
                            <li>Customer Care</li>
                            <li>Locations</li>
                            <li>Privacy</li>
                            <li>Security</li>
                            <li>Carreers</li>
                            <li>Promotions</li>
                        </ul>
                    </div>
                </div>

                <div class="popMenuContentCols">
                    <div class="popMenuContent">
						<?php
							if(isset($_SESSION['customer_id'])){
						?>
							<ul>
								<li><a href='change_pin'>Change PIN</a></li>
								<li><a href='change_password'>Change Password</a></li>
								<li><a href='../logout.php?key=11'>Logout</a></li>
							</ul>
						<?php
							}else{
						?>
							<ul>
								<li><a href='register'>Sign Up</a></li>
								<li><a href='access'>Login</a></li>
							</ul>
						<?php
							}
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
         function showPopMenu(){
            document.querySelector('.popMenuCover').style.display = 'block'
            document.querySelector('.popMenuCover').style.animation = 'fadeIn .5s ease'
            document.querySelector('.popMenuContentHolder').style.animation = 'menuMoveIn 1s ease'
        }

        function hidePopMenu(){
            
            document.querySelector('.popMenuCover').style.animation = 'fadeOut 1s ease'
            document.querySelector('.popMenuContentHolder').style.animation = 'menuMoveOut 1s ease'
            setTimeout(()=>{
                document.querySelector('.popMenuCover').style.display = 'none'
            }, 1000)
        }
    </script>