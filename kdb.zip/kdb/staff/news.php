<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	

<?php
							$title='';
							$message='';
							$title_err='';
							$m_err='';
							$errcheck=0;
							
							if (isset($_POST['add'])){
								if(!empty($_POST['message']) && isset($_POST['message'])){
									$message=clean_strings($_POST['message']);
								}else{
									$m_err="Message Field cannot be empty";
									$errcheck=1;
								}
								if(!empty($_POST['title']) && isset($_POST['title'])){
									$title=clean_strings($_POST['title']);
								}else{
									$m_err="Title Field cannot be empty";
									$errcheck=1;
								}
								
								if($errcheck==1){
									$msgbox="Cross Check For Empty Field(s) or Format Error";
								}else{
									mysqli_query($con,"insert into news (title, content) values ('$title','$message')");
									$msgbox="Sent Successfully!!!";
									//setcookie("success",$msgbox,time()+(3600*5),"/");
									//redirect_to("admin_panel.php?merger=news");
								}
								
							}
							
							if (isset($_POST['update'])){
								if(!empty($_POST['id']) && isset($_POST['id'])){
									$id=clean_strings($_POST['id']);
								}else{
									$errcheck=1;
								}
								
								if(!empty($_POST['message']) && isset($_POST['message'])){
									$message=clean_strings($_POST['message']);
								}else{
									$m_err="Message Field cannot be empty";
									$errcheck=1;
								}
								if(!empty($_POST['title']) && isset($_POST['title'])){
									$title=clean_strings($_POST['title']);
								}else{
									$m_err="Title Field cannot be empty";
									$errcheck=1;
								}
								
								if($errcheck==1){
									$msgbox="Cross Check For Empty Field(s) or Format Error";
								}else{
									mysqli_query($con,"update news set title='$title', content='$message' where id=$id");
									$msgbox="Updated Successfully!!!";
									//setcookie("success",$msgbox,time()+(3600*5),"/");
									//redirect_to("admin_panel.php?merger=news");
								}
					
							}
							
							if (isset($_POST['delete'])){
								if(!empty($_POST['id']) && isset($_POST['id'])){
									$id=clean_strings($_POST['id']);
								}else{
									$errcheck=1;
								}
								
								if($errcheck==1){
									$msgbox="Cross Check For Empty Field(s) or Format Error";
								}else{
									mysqli_query($con,"delete from news where id=$id");
									$msgbox="Deleted Successfully!!!";
									//setcookie("success",$msgbox,time()+(3600*5),"/");
									//redirect_to("admin_panel.php?merger=news");
								}
							}
?>
	<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-group'></i> Information Popup
				<br><hr>
			</div>
			<br>
					<div style='width:28%; height:450px; padding:10px; font-weight:bold; float:left;'>
						<?php
					
							$sql_b="select * from news order by date_added desc";
							$query_b=mysqli_query($con,$sql_b);
							if(!$query_b){
								echo mysqli_error($con);
							}
							while($out_b=mysqli_fetch_assoc($query_b)){
								echo "<div class='dd'><a href='news.php?id={$out_b['id']}'>{$out_b['title']}</a></div>";
							}
						?>
						</div>
						<div style='float:right; width:70%;'>
							<?php
								if(!empty($msgbox) && isset($msgbox)){ 
									echo "<div id='erralert' align='center' style='color:red; font-style:italic;'>";
									echo $msgbox;
									echo "</div>";
								}else{
									echo null;
								}
							
							if(isset($_GET['id']) && !empty($_GET['id'])){
									
									$id=clean_strings($_GET['id']);
									if(!preg_match("/^[0-9]*$/",$id)){
										echo "Only numbers are allowed";
										$errcheck=1;
									}
								if($errcheck==1){
									echo "error occured!!";
								}else{
									$sql="select * from news where id=$id";
									$query=mysqli_query($con,$sql);
									$out=mysqli_fetch_assoc($query);
									$title=$out['title'];
									$message=$out['content'];
								}
								$aud=true;
							}else{
								$id="";
								$out['title']="";
								$out['content']="";
								$aud=false;
							}
						?>

							<form name=\"form1" method="post" onsubmit="return myFunction('Are you sure?')" action="news.php?id=<?php echo $id;?>" enctype="multipart/form-data">
								<input type='hidden' name='id' value="<?php echo $id;?>"/>
								<p>
									<input class='text' type='text' name='title' value="<?php echo $title;?>" placeholder='Title'/>
								</p><br>
								
								<p>
									<textarea class="text" name="message" rows="10" cols="50" placeholder="Enter Notification"><?php echo $message;?></textarea>
									  <span style='color:red; font-style:italic;'>
									  <?php echo $m_err;?></span>
								</p><br>
								<p>
								<?php
									if($aud==true){
										echo "
										<button class='btn upd' type='submit' name='update' style='float:none; width:auto;'>
											Update
										</button>
										<button class='btn del' type='submit' name='delete' style='float:none; width:auto;'>
											Delete
										</button>";
									}else{
										echo "
										<button class='btn add' type='submit' name='add' style='float:none;'>
											Add
										</button>
										";
									}
								?>
									
								</p>
							</form>
						</div>
				
		</div>
	</div>
<?php 
include("includes/admin_foot.php");
?>