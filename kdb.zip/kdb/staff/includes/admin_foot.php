
</div>
</div>
<script>
	
	function show_sub(index){

		var x=document.getElementsByClassName("ul_sub_two");
		var y=document.getElementsByClassName("drop_sign");
		
		if(x[index].style.display=="block"){
			
			x[index].style.animation="undo_drop_sub ease .5s";
			setTimeout(function (){x[index].style.display="none"},500);
			y[index].innerHTML="<i class='fa fa-angle-down'></i>";
			
		}else{
			x[index].style.display="block";
			x[index].style.animation="drop_sub ease .5s";
			y[index].innerHTML="<i class='fa fa-angle-up'></i>";
		}
	}
	
	function showImage(imgsrc){
		document.getElementById('modalimg').style.display='block';
		document.getElementById('imgmod').src=imgsrc;
	}
	
	
function myFunction(msg){
	var x=confirm(msg);
	if(x==true){
		return true;
	}else{
		return false;
	}
	
}
</script>
<?php
if(isset($_COOKIE['err']) && !empty($_COOKIE['err'])){
?>
		<script>
			popup("<?php echo $_COOKIE['err'];?>","error");
		</script>
<?php
	setcookie("err","",time() - (3600*50),"/");
}
?>

<?php
if(isset($_COOKIE['success']) && !empty($_COOKIE['success'])){
?>
		<script>
			popup("<?php echo $_COOKIE['success'];?>","added");
		</script>
<?php
	setcookie("success","",time() - (3600*50),"/");
}
?>
</body>
</html>
<?php 
	mysqli_close($con);
	ob_end_flush();
?>