<?php
	require 'includes/bootstrap.php';
	//confirm_logged_in();
	include("includes/guest_area_head.php");
	alert_box();
?>
<style type="text/css">
	.s_title{
		font-size: 16px; 
		font-weight: bold;
	}

	ul{
		margin-left: 20px;
	}

	li{
		line-height: 1.6;
	}
</style>
<?php echo page_header("INVESTMENTS & ANNUITIES", "media/images/backgrounds/bg.jpg")?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 70px auto">
		<h3>A service of INFINEX Investments, Inc. and Emigrant Agency, Inc.</h3><br>
		<p>
			People are living longer in retirement and costs are going up. How much you have tomorrow will depend on what you do today. Emigrant Financial Services can help you put your retirement plan in focus with our wide range of investment choices.
		</p>
		<br>

		<p class="s_title">Fixed Annuities</p><br>
		<ul>
		    <li>Competitive fixed yield with minimum rate guarantee.</li>
		   <li> Safety of principal.</li>
		   <li> Tax-deferred growth.</li>
		   <li> Unlimited contributions.</li>
		   <li> Stream of income you cannot outlive.</li>
		</ul><br>

		<p class="s_title">Variable Annuities</p><br>
		<ul>
		   <li> Potential for long-term growth.</li>
		    <li>A wide range of investment choices.</li>
		    <li>Tax advantages of a fixed annuity.</li>
		    <li>Protection for your beneficiaries.</li>
		    <li>Lifetime benefits.
		    </li>
		</ul><br>
		<p class="s_title">Mutual Funds</p><br>
		<ul>
		    <li>Greater potential for growth.</li>
		    <li>Invest with experienced money managers.</li>
		    <li>Opportunities to diversify your portfolio.</li>
		</ul><br>
		<p>
			Ask us about improving your retirement outlook today. Call (212) 850-4480 Monday through Friday, 9:00 AM - 5:00 PM ET to speak with a Financial Consultant at Emigrant Financial Services.<br><br>

			Investment and insurance products and services are offered through INFINEX INVESTMENTS, INC. Member FINRA/SIPC. Emigrant Financial Services is a trade name of Emigrant Bank. Certain insurance products are offered through Emigrant Agency, Inc., a licensed affiliate of Emigrant Bank. Infinex is not affiliated with Emigrant Financial Services, Emigrant Agency Inc. or Emigrant Bank. Products and services made available through Infinex, Emigrant Financial Services and/or Emigrant Agency, Inc. are not insured by the FDIC or any other agency of the United States and are not deposits or obligations of nor guaranteed or insured by any bank or bank affiliate. These products are subject to investment risk, including the possible loss of value.
		</p>
		
		<br>
		
		<p>
			<b>Withdrawals from annuities before age 59 1/2 may be subject to a 10% penalty by the IRS.</b> Variable annuities and mutual funds are sold by prospectus which contain important information about fees and expenses. You may obtain a prospectus for a variable annuity or mutual fund from your investment representative. Always read the prospectus before you invest.
		</p>
		
	</div>
</div>

<?php include("includes/guest_area_foot.php");?>