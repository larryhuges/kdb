<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
alert_box();
?>

<style type="text/css">
	#inner-frame{
		max-width:1100px;
		width:100%;
		height:auto;
		margin:0 auto;
		padding:10px;
		position:relative;
		overflow-x:hidden;
	}

	.tabs_{
		float: left;
		position: relative;
		padding: 20px 20px;
		font-size: 14px;
		//background-color: red;
		text-align: center;
		cursor: pointer;

	}

	.ang_up {
		position: absolute;
		bottom: 0;
		left: 50%;
		width: 0; 
		height: 0; 
		border-left: 15px solid transparent;
		border-right: 15px solid transparent;
		border-bottom: 20px solid #f0f2f5;
		display: none;
	}

	.pages{
		float: left;
		padding: 0; 
		margin:0; 
		width: 100%; 
		margin-top: 10px;
		display: none;
	}

	.text{
		border: 1px solid #333;
	}

	table.bsheet, th.bsheet, tr.bsheet, td.bsheet{
		border: none;
		font-size: 14px;
	}

	td.bsheet{
		width: 50%;
	}
</style>

<?php
	$errcode=array();
	$address = $city = $state = $zipcode = $country = array();
	$recipient_address = $recipient_city = $recipient_state = $recipient_zipcode = $recipient_country = array();
	$bank_name = $bank_address = $routing_number = $account_number = $r_account_number = $memo = $recipient_name = $recipient_nickname = $recipient_address = $recipient_memo = $date_of_event = array();

	$t_username = $_SESSION['customer_username'];

	function valid_input($str){
		global $errcode;
		$output = array();
		if(!empty($str) && isset($str)){
			$output['value']=clean_strings($str);
			/*if(!preg_match("/^[a-zA-Z0-9- ]*$/", $output['value'])){
				$output['error']="Only Numbers and Alphabets are allowed";
				$errcode[]=5;
			}
			*/
		}else{
			$output['error']="Input is required";
			$errcode[]=6;
		}
		return $output;
	}

	function check_field($v, $t){
		if($t == 'error'){
			if(isset($v['error'])){
				return "<p style='color:red; font-size:12px; font-style: italic;'>".$v['error']."</p>";
			}else{
				return NULL;
			}
		}elseif($t == 'value'){
			if(isset($v['value'])){
				return $v['value'];
			}else{
				return NULL;
			}
		}else{
			return "error";
		}
	}

	
?>

<div id="frame" style="background-color: #fff; border-top: 1px solid #ccc; padding: 0; color: #333; font-size: 14px;">
	<div id="inner-frame" style="padding: 0 10px;">
		<div class='col one_col' style="">
			<div class="tabs_" style="background-color: grey; color: #fff">
				Transfer Funds
			</div>
			<div class="tabs_" onclick="arrow(0)">
				Schedule Transfer
				<div class="ang_up"></div>
			</div>
			<div class="tabs_" onclick="arrow(1)">
				Transfer Activity
				<div class="ang_up"></div>
			</div>
			<div class="tabs_" onclick="arrow(2)">
				Schedule Wire
				<div class="ang_up"></div>
			</div>
			<div class="tabs_" onclick="arrow(3)">
				External Accounts
				<div class="ang_up"></div>
			</div>		
		</div> 
		
	</div>	
</div>
<style>
	.vcCover{
		display: none;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 300;	
		background-color:#0008
	}

	.vcMiddle{
		width: 100%;
		max-width: 70rem;
		margin: 2rem;
		background-color: #fff;
		border-radius:.5rem;
		overflow: hidden;
	}

	.vcTop{
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: 2rem 3rem;
		background-color: blue;
		color: #fff;
		font-size: 2rem;
	}
	
	.vcBottom{
		width: 100%;
		padding: 2rem 3rem ;
		text-align: center;
	}

	.rdCover{
		display: none;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 300;	
		background-color:#0008
	}

	.rdMiddle{
		width: 100%;
		max-width: 70rem;
		margin: 2rem;
		background-color: #fff;
		border-radius:.5rem;
		overflow: hidden;
	}

	.rdTop{
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: 2rem 3rem;
		background-color: blue;
		color: #fff;
		font-size: 2rem;
	}
	
	.rdBottom{
		width: 100%;
		padding: 2rem 3rem ;
	}

	
	.sbCover{
		display: none;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 300;	
		background-color:#0008
	}

	.sbMiddle{
		width: 100%;
		max-width: 70rem;
		margin: 2rem;
		background-color: #fff;
		border-radius:.5rem;
		overflow: hidden;
	}

	.sbTop{
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: 2rem 3rem;
		background-color: blue;
		color: #fff;
		font-size: 2rem;
	}
	
	.sbBottom{
		display: grid;
		grid-template-columns: 50% 50%;
		gap: 1rem;
		width: 100%;
		padding: 2rem 3rem ;
	}

	.sbBank{
		display: flex;
		align-items: center;
		justify-content: flex-start;
		gap: 2rem;
		width: calc(100% - 2rem);
		margin: 2rem auto;
		cursor: pointer;
		padding: 2rem;
		border: none;
		transition: border .5s ease
	}

	.sbBank:hover{
		border-radius: .5rem;
		border: .1rem solid blue;
	}

	.subSectionTitle{
		position: relative;
		font-weight: bold;
		font-size: 2rem;
		width: 100%;
		border-bottom: .2rem solid #0063cc;
		padding: 1rem 0;
		padding-left: 7rem;
	}

	.subSectionTitle::before{
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		background: red;
		width: 5rem;
		height: 5rem;
	}

	.tsform{
		display: flex;
		align-items: flex-start;
		justify-content: flex-start;
		width: 100%;
		padding: 2rem 2rem 0;
	
	}

	.tsform > div{
		padding: 1rem;
	}

	.tsform > div:first-child{
		width: 20rem;
		text-align: right;
		font-weight: bold;
	}
	
	.tsform > div:last-child{
		width: 100%;
	}

	.preAmount{
		display: flex;
		width: 100%;
	}

	.preAmount p{
		padding: .5rem 1rem ;
		margin: 0 .5rem 1rem 0 ;
		background-color: lightgray;
		width: auto;
		border-radius: .5rem;
		cursor: pointer;
	}

	.contNoti{
		display: flex; 
		align-items: center; 
		justify-content: flex-start; 
		width: 100%; 
		border-bottom: .1rem solid #0056b2;
		
	}

	.contNoti > div:first-child{
		width: 18rem;
		font-weight: bold;
		padding: 2rem; 
		background-color: lightgray;
		text-align: center;
	}

	.contNoti > div:last-child{
		padding: 2rem; 
		display: flex; 
		align-items: center; 
		justify-content: flex-start; 
	}

	.contNoti  input{
		width: 2rem;
		height: 2rem 
	}

	.tfPage{
		display: none;
	}


</style>

<div id="frame" style="background-color: #F0F8FF; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame">
		<div id="page1" class="pages col_bg">
			<div style="float: left; width: 100%; padding: 20px; margin: 0px 0; background-color: #fff;">
				<div class="col one_col" style="margin-bottom: 30px;">
					<div style="float: left; width: auto; padding: 10px 0; font-size: 20px; ">
						Schedule Wire & Global Transfer
					</div>
					<div style="float: right; width: auto">
						<button class="btn upd" style="width: 250px; padding:15px 20px; font-size: 16px;"  onclick="popWire()"><i class="fa fa-plus-circle"></i> Add New Recipient</button>
					</div>
				</div>

				<?php
					$s = "select * from recipients where username = '$t_username'";
					$q = mysqli_query($con, $s);
					if(mysqli_affected_rows($con) >= 1){
						while ($o = mysqli_fetch_assoc($q)) {
				?>
							<div class="col one_col" style="margin-top: 0px; border-bottom: 1px solid #ccc; padding: 10px 0;">
								<div>
									<div style="float: left; padding: 15px 0;">
										<?php echo ucwords($o['recipient_name'])?>
									</div>
									<div style="float: right; width: auto;">
										<!-- <button class="btn " style="width: 180px; padding:10px 15px; font-size: 14px;" >See recipient details</button> -->
										<button class="btn upd" style="width: 120px; padding:10px 15px; font-size: 14px;" onclick="pop_send_money()">Send Money</button>
									</div>
								</div>
							</div>
				<?php
						}
					}else{
				?>
						<div class="col one_col" style="margin-top: 0px; border-bottom: 1px solid #ccc; padding: 10px 0; text-align: center;">
							No Recipient Found!
						</div>
				<?php
					}
				?>
				
			</div>				
		</div>

		<div id="page2" class="pages col_bg" style="line-height: 1.5;">
			<div class='tfPage'>
				<div class='col one_col' style='margin-top: 2rem;'>
					<div class='subSectionTitle'>
						Enter Withdrawal Information
					</div>

					<div class='tsform'>
						<div>
							Widthdrawal account no
						</div>
						<div>
							<?php
								$sacc = "select checking_account, current_balance, available_balance, savings_account from users_info where username = '$t_username'";
								$qacc = mysqli_query($con, $sacc);
								
								if(mysqli_affected_rows($con) >= 1){
									$oacc = mysqli_fetch_assoc($qacc);
								}else{
									echo mysqli_query($con);
								}
							?>
							<select class="text" id="t_from" required name="from" style='max-width: 30rem;'>
								<option><?php echo $oacc['checking_account']; ?></option>
							</select>
							<p>
								withdrawable Amount <b><?php echo number_format($oacc['current_balance'], 2); ?></b> KRW | Balance <b><?php echo number_format($oacc['available_balance'], 2); ?></b> KRW
							</p>
						</div>
					</div>

					<div class='tsform'>
						<div>
							Account Password
						</div>
						<div>
							<input type="password" class="text" id="" required placeholder="****" style='max-width: 30rem;'><br>
						</div>
					</div>

				</div>

				<div class='col one_col' style='margin-top: 5rem;'>
					<div class='subSectionTitle'>
						Enter Deposit Information
					</div>

					<div class='tsform'>
						<div>
							Deposit account no
						</div>
						<div>
							<div>
								<select class="text" style='max-width: 30rem;' id="w_to" required name="">
									<option value="">---Select Recipient---</option>
									<?php
										$s = "select * from recipients where username = '$t_username'";
										$q = mysqli_query($con, $s);
										if(mysqli_affected_rows($con) >= 1){
											while ($o = mysqli_fetch_assoc($q)) {
									?>
												<option><?php echo $o['recipient_name']?> <?php echo "(*****".substr($o['account_number'], 5) .")" ?></option>
												
									<?php
											}
										}
									?>
								</select>
								<input type="hidden" id="" required placeholder="" >
							</div>
							
						</div>
					</div>

					<div class='tsform'>
						<div>
							Transfer Amount
						</div>
						<div>
							<div class='preAmount'>
								<p data-v='1000000'>KRW 1,000,000</p>
								<p data-v='500000'>KRW 500,000</p>
								<p data-v='100000'>KRW 100,000</p>
								<p data-v='50000'>KRW 50,000</p>
								<p data-v='10000'>KRW 10,000</p>
							</div>
							<input type="number" class="text" id="t_amount" required placeholder="Enter Transfer Amount" style='max-width: 30rem; text-align: right;'><br>
							<p>
								<b>Transfer Limit</b> | Balance <b>29,999,999</b> KRW | 1 Times <b>10,000,000</b> KRW | 1 Day <b>20,000,000</b> KRW
							</p>
						</div>
					</div>

				</div>

				<div class='col one_col' style='margin-top: 5rem;'>
					<div class='subSectionTitle'>
						Enter Selected Information
					</div>

					<div class='tsform'>
						<div>
							Transfer Date
						</div>
						<div>
							<div>
								<input type="date" class="text" id="t_date" required style='max-width: 50rem;'>
							</div>
							
						</div>
					</div>

					<div class='tsform'>
						<div>
							Memo (Optional)
						</div>
						<div>
							<textarea placeholder="" class="text" id="t_memo" style="line-height: .2; height: 10rem; max-width: 50rem; "></textarea>
						</div>
					</div>
					<button class="btn upd" onclick='loadPage(1)' style="width: 45%; font-weight: bold; margin-left: 2.0rem; float: right;">Next</button>
				</div>
			</div>


			<div class='tfPage'>
				<div class='col one_col' style='margin-top: 5rem;'>
					<div class='subSectionTitle'>
						Confirm Transfer Information
					</div>
					
					<div>
						<table>
							<th colspan=''>Withdrawal Information</th>
							<th></th>
							<th>Deposit Information</th>

							<tr>
								<td style='text-align: left;'>
									028-9311-0988-723<br>
									Muha Nav
								</td>
								<td>
									Immediate<br>
									>
								</td>
								<td style='text-align: right;'>
									<div style='text-align: right;'>
										<div>028-9311-0988-723</div><br>
										<div>100 KRW</div>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan='3' style='border-top:1px solid lightgray; border-bottom:1px solid lightgray'>
									<div style='text-align: right;'>
										Total 1 records &nbsp;|&nbsp; Total Transfer Amount <span>1,000</span> KRW
									</div>
								</td>
							</tr>
						</table>
					</div>
				</div>

				<div class='col one_col' style='margin-top: 5rem; padding: 3rem; border: 1px solid #0056b2; border-radius: 1rem'>
					<div class='col one_col cus' style='padding: 1rem 0 0 7rem;
		background: url(../media/images/photo/ico_cscont.png) no-repeat 0 0; background-size: contain; height: 5rem'>

						<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem; font-weight: bold;'>Please check again!</span>

					</div>

					<div class='col one_col' style='margin: 2rem 0 0 0;'>
						<ul style='margin-left: 3rem; line-height: 2;'>
							<li>
								If you receive a phone call requesting your OTP number (or security card) do not provide them with any information
							</li>
							<li>
								Please check the transfer information again such as the account number and beneficiary
							</li>
						</ul>
					</div>
				</div>

				<div class='col one_col' style='margin-top: 5rem;'>
					<div class='subSectionTitle'>
						Enter Contact Number for Transfer Failure
					</div>
					
					<div class='contNoti'>
						<div>
							Receive Status
						</div>
						<div>
							<input type='radio' name='notii' checked /> &nbsp;&nbsp; Agreed tot Receive Notifications &nbsp;&nbsp;&nbsp;

							<input type='radio' name='notii'/> &nbsp;&nbsp; Not Agreed tot Receive Notifications
						</div>
					</div>

					<div class='contNoti'>
						<div>
							Contact Number
						</div>
						<div>
							010 764-8473 &nbsp;&nbsp; <u>Change</u>
						</div>
					</div>
				</div>

				<div class='col one_col' style='margin-top: 5rem;'>
					<div class='subSectionTitle'>
						Enter Security Method
					</div>
					
					<div style='padding: 2rem; text-align: center; font-weight: bold; background-color: lightgray; color: #0063cc'>
						<i class='fa fa-info-circle'></i> Security verification can be different in considiration of the risk per transaction/condition and security service you have applied.
					</div>
					
					<div style='text-align: center; padding: 2rem'>
						<p>
							Send OTP verification code to your registered email to complete transaction
						</p><br>

						<button class="btn upd" style="" onclick='loadPage(0) '>Back</button>
						
						<button class="btn upd" type="submit" style="" onclick='openPopUP("#OTPBox")'>Send Code</button>
					</div>
				</div>
			</div>

			<style>

				*{
					box-sizing: border-box;
				}

				table{
					width: 100%;
					border-collapse: collapse;
				}

				th{
					padding: 1.5rem;
					background-color: lightgray;
				}

				tr{
					width: 100%;
				}

				td{
					text-align: center;
					padding: 1.5rem;
				}
			</style>
		
			<div class='tfPage'>
				
				<div class='col one_col' style='margin-top: 5rem; padding: 3rem; border: 1px solid #0056b2; border-radius: 1rem'>
					<div class='' style='padding: 1rem 0 0 7rem;
		background: url(../media/images/photo/ico_cscont.png) no-repeat 0 0; background-size: contain; height: 5rem'>
					</div>

					<div style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem; font-weight: bold; text-align: center;'>The individual transfers you have requested have been processed as the following</div>

				</div>

				<div class='col one_col' style='margin-top: 5rem;'>
					<div class='subSectionTitle'>
						Confirm Transfer Result
					</div>
					
					<div>
						<table>
							<th colspan='3'>Withdrawal Information</th>
							<th>Deposit Information</th>
							<th>Result</th>

							<tr>
								<td style='text-align: right; width: 20%'>
									<input type='checkbox' />
								</td>
								<td style='text-align: left;'>
									028-9311-0988-723<br>
									Muha Nav
								</td>
								<td>
									Immediate<br>
									>
								</td>
								<td style='text-align: left;'>
									THE INDUSTRIAL
								</td>
								<td>
									Success
								</td>
							</tr>
							<tr>
								<td colspan='7' style='border-top:1px solid lightgray; border-bottom:1px solid lightgray'>
									<div style='text-align: right;'>
										Total 1 records (Success 1item, Error0records) &nbsp;|&nbsp; Total Transfer Amount <span>1,000</span> KRW
									</div>
								</td>
							</tr>
						</table>
					</div>
					
				</div>
			</div>
		
		</div>

		
		<div id="page3" class="pages col_bg" style="line-height: 1.5;">
			<div class="col one_col">
				
				<div class="col one_col" style="text-align:left; padding: 20px;">
					<div style="float: left; width: 100%; padding: 10px 0; font-size: 20px; border-bottom: 1px solid #ccc;">
						Account Details
					</div>
					<table class="bsheet" style=" width: 100%; font-size: 20px;">
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Wire to&nbsp;</td>
							<td class="bsheet">
								&nbsp;Mr Ken
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Wire from&nbsp;</td>
							<td class="bsheet">
								&nbsp;TOTAL CHECKING (...1293)
							</td>
						</tr>
						
					</table>
				</div>

				<div class="col one_col" style="text-align:left; padding: 20px;">
					<div style="float: left; width: 100%; padding: 10px 0; font-size: 20px; border-bottom: 1px solid #ccc;">
						Sender Information
					</div>
					<table class="bsheet" style=" width: 100%; font-size: 20px;">
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Wire date&nbsp;</td>
							<td class="bsheet">
								&nbsp;Mar 11, 2022
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Wire amount&nbsp;</td>
							<td class="bsheet">
								&nbsp;$100.00 USD
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Outgoing Wire Transfer Fee&nbsp;</td>
							<td class="bsheet">
								&nbsp;$25.00 USD
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;"><b>Total</b>&nbsp;</td>
							<td class="bsheet">
								&nbsp;<b>$125.00 USD</b>
							</td>
						</tr>
						
					</table>
				</div>

				<div class="col one_col" style="text-align:left; padding: 20px;">
					<div style="float: left; width: 100%; padding: 10px 0; font-size: 20px; border-bottom: 1px solid #ccc;">
						Additional Information
					</div>
					<table class="bsheet" style=" width: 100%; font-size: 20px;">
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Message to recipient bank&nbsp;</td>
							<td class="bsheet">
								&nbsp;None
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Message to recipient&nbsp;</td>
							<td class="bsheet">
								&nbsp;None
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="text-align: right;">Memo&nbsp;</td>
							<td class="bsheet">
								&nbsp;None
							</td>
						</tr>
					</table>
				</div>

				<div class="col one_col" style="text-align:left; padding: 20px;">
					
					<div style="line-height: 1;">
						
					</div>
					<div>
						<button class="btn" type="button" style="width: 150px; color: #888; font-weight: bold; float: left;" onclick="cancel_funding()">Cancel</button>
						<button class="btn upd" type="submit" style="width: 150px; font-weight: bold; margin-left: 20px; float: right;">Next</button>
						<button class="btn" type="button" style="width: 150px; color: #888; font-weight: bold; float: right;" onclick="cancel_funding()">Cancel</button>
					</div>
				</div>
			</div>		
		</div>

	</div>
</div>

<style type="text/css">
	.l_title{
		color: #002C5C;
	}

	#ext_acct_holder{
		position: absolute; top: 0; left: 0; width: 50%; height: 100vh; background-color: #fff; z-index: 200; padding: 20px 40px; overflow: scroll; color: #333; font-size: 14px; display: none;
	}

	#wire_holder{
		position: absolute; 
		top: 0; 
		left: 0; width: 50%; height: 100vh; background-color: #fff; z-index: 200; padding: 20px 40px; overflow: scroll;  font-size: 14px; display: none; color: #333;
	}

	@media screen and (max-width: 700px){
		#wire_holder{
			width: 100%;
		}

		#ext_acct_holder{
			width: 100%;
		}

	}
</style>
		
		<div id="wire_holder" style="">
			<!-- <div class="col one_col" style="text-align: center; font-weight: bold; font-size: 20px; padding: 0;">
				Add Wire Recipient
			</div>
 -->
			<div style="position: absolute; top: 0; right: 0; font-size: 40px; padding: 0 10px; cursor: pointer;" onclick="closeWire()"> &times; </div>

			<div class="wire_inner">
				<div class="col one_col">
					<div class="l_title" style="font-size: 20px; padding: 20px 0 0; font-family: ;">
						Add Wire Recipient
					</div>
					<div style="font-size:12px; padding: 10px 0;">
						Your total transfer limit is $100,000.00. This limit applies to transfer you send from all the accounts in this profile before 4PM ET each business day. If you need to send a transfer for more than your limit, you can write to finance@kdb.com
					</div>
				</div>
				<form action="" method="post">
					<div class="col one_col" style="margin-top: 30px;">
						<div class="l_title" style="font-size: 20px; padding: 20px 0 0; font-family: ; border-bottom: 1px solid #ccc; margin-bottom: 20px;">
							Please tell us about the recipient's bank
						</div>
					

						<table class="bsheet">
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Bank Name</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($bank_name, 'value');?>" name="bank_name" required>
									<?php echo check_field($bank_name, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Address</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($bank_address, 'value');?>" name="bank_address" required>
									<?php echo check_field($bank_address, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">City</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($city, 'value');?>" name="city" required>
									<?php echo check_field($city, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">State</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($state, 'value');?>" name="state" required>
									<?php echo check_field($state, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Zip Code</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($zipcode, 'value');?>" name="zipcode" required>
									<?php echo check_field($zipcode, 'error'); ?>
								</td>
							</tr>
							
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Country</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($country, 'value');?>" name="country" required>
									<?php echo check_field($country, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Routing number</td>
								<td class="bsheet">
									<input type="number" maxlength="9" class="text" value="<?php echo check_field($routing_number, 'value');?>" name="routing_number" required>
									<?php echo check_field($routing_number, 'error'); ?>
									<div>
										This 9-digit number on your check identifies your bank and tells us where to find your account
									</div>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Account number</td>
								<td class="bsheet">
									<input type="password" class="text" value="<?php echo check_field($account_number, 'value');?>" name="account_number" required>
									<?php echo check_field($account_number, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Confirm Account number</td>
								<td class="bsheet">
									<input type="password" class="text" value="<?php echo check_field($r_account_number, 'value');?>" name="r_account_number" required>
									<?php echo check_field($r_account_number, 'error'); ?>
								</td>
							</tr>
							<!-- <tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Account type</td>
								<td class="bsheet">
									<input type="text" class="text" id="account_type" required>
								</td>
							</tr> -->
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;"></td>
								<td class="bsheet">
									<input type="checkbox"> Show account number
								</td>
							</tr>
							<!-- <tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Account Purpose</td>
								<td class="bsheet">
									<input type="text" class="text" id="account_purpose" required>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Bank Name</td>
								<td class="bsheet">
									<input type="text" class="text" id="bank_name" required>
								</td>
							</tr> -->
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Memo</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($memo, 'value');?>" name="memo">
									<?php echo check_field($memo, 'error'); ?>
								</td>
							</tr>

							
						</table>
					
						<div class="l_title" style="font-size: 20px; padding: 20px 0 0; font-family: ; border-bottom: 1px solid #ccc; margin-bottom: 20px;">
							Enter Recipient Information
						</div>
					
						<table class="bsheet">
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Recipient Name</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_name, 'value');?>" name="recipient_name" required>
									<?php echo check_field($recipient_name, 'error'); ?>

								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Recipient Nickname</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_nickname, 'value');?>" name="recipient_nickname">
									<?php echo check_field($recipient_nickname, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Address</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_address, 'value');?>" name="recipient_address" required>
									<?php echo check_field($recipient_address, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">City</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_city, 'value');?>" name="recipient_city" required>
									<?php echo check_field($recipient_city, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">State</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_state, 'value');?>" name="recipient_state" required>
									<?php echo check_field($recipient_state, 'error'); ?>
								</td>
							</tr>
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Zip Code</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_zipcode, 'value');?>" name="recipient_zipcode" required>
									<?php echo check_field($recipient_zipcode, 'error'); ?>
								</td>
							</tr>
							
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Country</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_country, 'value');?>" name="recipient_country" required>
									<?php echo check_field($recipient_country, 'error'); ?>
								</td>
							</tr>
							
							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;">Memo</td>
								<td class="bsheet">
									<input type="text" class="text" value="<?php echo check_field($recipient_memo, 'value');?>" name="recipient_memo">
									<?php echo check_field($recipient_memo, 'error'); ?>
								</td>
							</tr>

							<tr class="bsheet">
								<td class="bsheet" style="font-size: 14px; text-align: right;"></td>
								<td class="bsheet">
									<button class="btn" type="button" style="width: 45%; color: #888; font-weight: bold; float: left;" onclick="close_ext_acct()">Cancel</button>
									<button class="btn upd" type="submit" name="add_recipient" style="width: 45%; font-weight: bold; margin-left: 20px; float: right;">Next</button>
								</td>
							</tr>

						</table>
					</div>
				</form>
			</div>

		</div>

<style type="text/css">
	
	table.c_tb, tr.c_tr{
		width:100%;
		height:auto;
		margin:auto;
		border-collapse:collapse;
		font-family:sans-serif;
	}

	td.c_td{
		height:auto;
		vertical-align: center;
		margin:auto;
		border-collapse:collapse;
		font-size:16px;
		padding: 10px 0px;
		color: #000;
	}


	td.c_td:nth-child(even){
		text-align: right;
	}


</style>

		
	<?php
		$page = 0;
		if(isset($_GET['p'])){
			$page = $_GET['p'];
		}
	?>

	<script type="text/javascript" src='transfer.js'></script>

<?php 
include("includes/member_foot.php");
?>
