<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
		
		<div id="inner-frame">
			<div id='log_form'> 
				<table class='pay'>
					<th colspan='3' class='pay'>Actions</th>
					<th class='pay'>Username</th>
					<th class='pay'>Full Name</th>
					<th class='pay'>Mobile</th>
					<th class='pay'>Email</th>
					<th class='pay'>Date Joined</th>
					<th class='pay'>Current Level</th>
					<th class='pay'>EWallet</th>
					<th class='pay'>Referral</th>
				<?php
					$i=0;
					$sql="select * from users_info where verified='Yes'";
					$query=mysqli_query($con, $sql);
					if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_array($query)){
				?>
						<tr class='pay'>
							
								<?php
									
									echo "<td id='change_btn$i' class='pay' align='center'>";
									if($out['visible']=='No'){
										echo "
											<button class='btn upd' onclick='block_unblock(\"Yes\",\"{$out['username']}\",$i)'>Unblock</button>
										";
									}else{
										echo "
											<button class='btn del' onclick='block_unblock(\"No\",\"{$out['username']}\",$i)'>Block</button>
										";
									}
								?>
							   
							</td>
							<td class='pay'><a href='edit_member.php?user=<?php echo $out['username'];?>' target='_blank' class="btn add">Edit</a></td>
							<td class='pay'><a href='view_downliners.php?user=<?php echo $out['username'];?>&user_stage=<?php echo $out['current_stage'];?>' target='_blank' class="btn upd">Downliners</a></td>
							<td class='pay'><?php echo $out['username'];?></td>
							<td class='pay'><?php echo $out['firstname']." ".$out['lastname'];?></td>
							<td class='pay'><?php echo $out['mobile']?></td>
							<td class='pay'><?php echo $out['email']?></td>
							<td class='pay'><?php echo $out['date_joined']?></td>
							<td class='pay'><?php echo $out['current_stage']?></td>
							<td class='pay'><?php echo $out['ewallet']?></td>
							<td class='pay'><?php echo $out['referral']?></td>
							
						<tr>
				<?php
						$i++;
					}
					}else{
						echo "
							<tr class='pay'>
								<td class='pay' colspan='11'>No Record Found</td>	
							<tr>
						";
					}
				?>
				</table>
				
			</div>
		</div>
		<script>
			function block_unblock(stat,userName,id){ 
			
				var xhttp=new XMLHttpRequest();
				xhttp.onreadystatechange=function(){
					if(this.readyState==4 && this.status==200){
						
						if(xhttp.responseText==1 && stat=='Yes'){
							document.getElementById('change_btn'+id).innerHTML="<button class='btn del' onclick='block_unblock(\"No\",\""+userName+"\","+id+")'>Block</button>";
							//document.getElementById('block_info').innerHTML=userName + " was BLOCK SUCCESSFUL!";
						}else if(xhttp.responseText==1 && stat=='No'){
							document.getElementById('change_btn'+id).innerHTML="<button class='btn upd' onclick='block_unblock(\"Yes\",\""+userName+"\","+id+")'>Unblock</button>";
							//document.getElementById('block_info').innerHTML=userName + " was UNBLOCK SUCCESSFUL!";
						}else if(xhttp.responseText==0){
							alert("Error Blocking " + UserName);
						}else{
							alert(stat+userName+id);
						}
					}else{
						document.getElementById('change_btn'+id).innerHTML="<img src='images/source.gif' width='25'>";
					}
				}; 
			
				xhttp.open("GET","block.php?sta="+stat+"&user="+userName,true);
				xhttp.send(null);
			}
		</script>
			
<?php 
include("includes/admin_foot.php");
?>