<?php
	require 'includes/bootstrap.php';
	//confirm_logged_in();
	include("includes/guest_area_head.php");
	alert_box();
?>
<style type="text/css">
	.s_title{
		font-size: 16px; 
		font-weight: bold;
	}

	ul{
		margin-left: 20px;
	}

	li{
		line-height: 1.6;
	}
</style>
<?php echo page_header("MORTGAGES", "media/images/backgrounds/bg.jpg")?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 70px auto">
		<p>
			KeyVest Mortgage, a Division of KeyVest Bank - NMLS# 607759 (KeyVest) provides personal service, flexible terms, and customized mortgage options for home buyers:
		</p>
		<br>

		<ul>
		    <li>Adjustable and Fixed Rate Mortgages</li>
		    <li>Loans for 1-4 Family Homes, Co-ops and Condominiums</li>
		    <li>Purchases, Rate/Term and Cash-Out Refinancing</li>
		    <li>Cooperative Financing Eligible</li>
		    <li>Jumbo Mortgages</li>
		    <li>First-Time Home Buyers - Low Down Payment Programs</li>
		   <li> FNMA / FHLMC Loans
			   <ul>
			        <li>Federal National Mortgage Association</li>
			        <li>Freddie Mac</li>
			    </ul>
			</li>
		    <li>SONYMA Loans
		    	<ul>
			        <li>State of New York Mortgage Agency</li>
			        <li>Low Interest Rate Mortgage Program</li>
			    </ul>
		    </li>
		    <li>Vacation/2nd Home and Investment Property Programs</li>
		</ul>

		<br><br>

		Click to view Current Mortgage Promotions<br><br>

		Working closely with you from application to closing, our knowledgeable mortgage consultants will draw upon KeyVest's variety of mortgage loan options and help you decide which financing solution best meets your needs. No matter how unique your situation, KeyVest can design a financing solution that is right for you.<br><br>

		KeyVest originates loans in CT, FL, MA, NJ, NY, and PA.<br><br>

		<b>For properties located in the following areas, contact the Mortgage Consultant listed below:</b><br><br>

		<b>Properties located in the Boroughs of Manhattan, Bronx, Brooklyn,<br>
		Queens and Westchester, contact:</b><br>
		(212) 850-4848 / CommunityLending@KeyVest.com<br><br>

		<b>Properties located on Long Island, contact:</b><br>
		Veronica Ferrero, Senior Mortgage Consultant - NMLS#343789<br>
		(516) 822-6992 / FerreroV@KeyVestMortgage.com<br><br>

		<b>Properties located in New Jersey, contact:</b><br>
		Jack Coll, Senior Vice President & Sales Manager - NMLS#13478<br>
		(914) 649-2195 / CollJ@KeyVest.com<br><br>

		Mortgage Brokers, click KeyVest MORTGAGE.<br>
		<br>

		<p class="s_title">Current Mortgage Holders</p><br>

		KeyVest Mortgage Company, Inc. NMLS#1577 (EMC) a subsidiary of KeyVest Bank performs the servicing of KeyVest's residential mortgage loans.<br><br>

		<ul>
		    <li>You may direct inquires and complaints to our Mortgage Servicing Department at 1-800-836-1260 during our regular business hours from 9 AM to 5PM, Eastern Time or by mail to KeyVest Mortgage Company, 7 Westchester Plaza, Elmsford, NY 10523, attn: Mortgage Servicing Department.</li>
		    <li>In addition, you can also utilize our automated phone system at 212-850-3333 to access your Mortgage account information.</li>
		   <li> Pay your Mortgage with an automatic debit from your checking or savings account.</li>
		   <li> EMC is registered with the New York Superintendent. You may file complaints and obtain further information about EMC by contacting the New York State Department of Financial Services Consumer Assistance Unit at 1-800-342-3736 or by visiting the Department's website at www.dfs.ny.gov.</li>
		    <li>EMC utilizes third party providers to assist in the servicing of accounts secured by properties in New York, including with respect to mortgage servicing practices, insurance administration, and the bankruptcy and foreclosure process. EMC remains responsible for all actions taken by third-party providers to the extent required under New York law.</li>
		</ul>

	</div>
</div>

<?php include("includes/guest_area_foot.php");?>