<?php
	require_once("includes/sessions.php");	
	require_once("includes/connection.php");
	require_once("functions/functions.php");
	confirm_admin_logged_in();

	if(isset($_GET['user']) && !empty($_GET['user'])){
		$username = clean_strings($_GET['user']);
	}else{
		$username = "";
	}
?>
	<h2>Bonus History</h2>
		<table class='pay'>
			<th style='width:20px;' class='pay'>id</th>
			<th class='pay'>Username</th>
			<th class='pay'>Amount</th>
			<th class='pay'>Description</th>
			<th class='pay'>Date</th>
			<th class='pay'>Status</th>
		<?php
			$i=1;
			$sql="select * from bonuses where username = '$username'";
			//echo $sql;
			$query=mysqli_query($con, $sql);
			if(mysqli_affected_rows($con) <= 0){
		?>
				<tr class='pay'>
					<td class='pay' colspan="8">No Record Found</td>
				<tr>
		<?php
			}else{
				while($out=mysqli_fetch_array($query)){
		?>
					<tr class='pay'>
						<td style='width:20px;' class='pay'><?php echo $i;?></td>
						<td class='pay'><?php echo $out['username'];?></td>
						<td class='pay'>$ <?php echo $out['amount']?></td>
						<td class='pay'><?php echo $out['description']?></td>
						<td class='pay'><?php echo $out['date_added']?></td>
						<td class='pay'><?php echo $out['status']?></td>
						
					<tr>
		<?php
					$i++;
				}
			}
		?>
		</table>