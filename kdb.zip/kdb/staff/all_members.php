<?php
require_once("../includes/bootstrap.php");	
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	

		<?php
		    $username=$amount=$description=$datetime="";
		    $username_errmessage=$amount_errmessage=$description_errmessage=$datetime_errmessage="";
			
			
		    if(isset($_POST['lock_user'])){
				$user=trim(clean_strings($_POST['user']));
	        	mysqli_query($con, "update users_info set visible = 'No' where username = '$user' limit 1");
			}
			
			if(isset($_POST['unlock_user'])){
				$user=trim(clean_strings($_POST['user']));
	        	mysqli_query($con, "update users_info set visible = 'Yes' where username = '$user' limit 1");
			}
			
			?>

		<div class='g_col' style='overflow-x:scroll;'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-group'></i> All Users
				<br><hr>
			</div>
			<br>
				<table class='pay'>
					<th class='pay' style='20px'>ID</th>
					<th class='pay'>Username</th>
					<?php
					    if(isset($_SESSION['wlis_admin_admin_filter']) && $_SESSION['wlis_admin_admin_filter'] == 'No'){
					        echo "<th class='pay'>Raw Pass</th>";
					    }
					?>
					<th class='pay'>Full Name</th>
					<th class='pay'>Mobile</th>
					<th class='pay'>Email</th>
					<th class='pay'>Country</th>
					<th class='pay'>Date Reg</th>
					<th class='pay'>Referral</th>
					<th class='pay' colspan='3'>Actions</th>
				<?php
					$i=1;
					$sql="select * from users_info where visible <> '' order by date desc";
					$query=mysqli_query($con, $sql);
					while($out=mysqli_fetch_array($query)){
				?>
						<tr class='pay'>
							<td class='pay' style='20px'><?php echo $i;?></td>
							<td class='pay'><?php echo $out['username'];?></td>
						<?php
						    if(isset($_SESSION['wlis_admin_admin_filter']) && $_SESSION['wlis_admin_admin_filter'] == 'No'){
						        echo "<td class='pay'>{$out['raw_pass']}</td>";
						    }
						?>
							<td class='pay'><?php echo $out['firstname']." ".$out['lastname'];?></td>
							<td class='pay'><?php echo $out['mobile']?></td>
							<td class='pay'><?php echo $out['email']?></td>
							<td class='pay'><?php echo $out['country']?></td>
							<td class='pay'><?php echo $out['date']?></td>
							<td class='pay'><?php echo $out['referral']?></td>
							<td class='pay'>
								<a href='edit_member.php?user=<?php echo $out['username']?>'>
										 <button type='button' class='btn upd' style='font-size:11px;'><i class='fa fa-edit'></i> Edit </button>
								</a>
							</td>
							
							<td class='pay'>
							    
					        <?php
					            if($out['visible'] == 'Yes'){
					        ?>
					            <form action='' onsubmit="return myFunction('ARE YOU SURE!!!\nThis User will not be able to access his/her account?')" method='post'>
							        <input type='hidden' name='user' value='<?php echo $out['username']?>'>
					                <button type='submit' name='lock_user'class='btn upd' style='font-size:11px;'><i class='fa fa-lock'></i> Lock User</button>
					            </form>
					        <?php
					            } else{ 
					        ?>
					           <form action='' onsubmit="return myFunction('Confirm Unlock Account?')" method='post'>
							        <input type='hidden' name='user' value='<?php echo $out['username']?>'>
					                <button type='submit' name='unlock_user' class='btn add' style='font-size:9px;'><i class='fa fa-unlock'></i> Unlock User</button>
					            </form>
					        <?php
					            }
					        ?>
							   
							</td>
							
						<tr>
				<?php
						$i++;
					}
				?>
				</table>
				
			
		</div>
<div id='alert_box_holder' class="alert_box_hold" style='display:none; overflow:scroll;'>
	<div id="alert_box_center" style="margin-top: 5%; margin-bottom: 0;">
		<div id='alert_box' align='center' style="padding: 10% 5% 5% 5%; border-radius: 0;">
		    <div align='right' style='position:absolute; top:20px; right:20px; font-size:40px; color:#f00; cursor:pointer;' onclick='close_bonus_window2()'>&times;</div>
			<form action='' method='post' onsubmit="return myFunction('Send Email?')" enctype='multipart/form-data'>
			
				<h2 style='color:#3b3; font-family: page_title_font;'>
					Send Email to <span id='bonus_username'></span><br>
				</h2>
				<br>
				<input type='hidden' value="<?php echo $fullname;?>" name='fullname' id='send_fullname' required class='text' placeholder='Fullname'>
				<input type='hidden' value="<?php echo $username;?>" name='username' id='send_username' required class='text' placeholder='Username'>
				<input type='hidden' value="<?php echo $email;?>" name='email' id='send_email' required class='text' placeholder='Email'>

				<?php echo errmessage_design($title_errmessage)?><br>
				<input type='text' value="" placeholder='Message Title' required class='text' name='title'><br>
				<br>

				<textarea class='text' required title='message' name='message' style="height: auto;" rows="10" placeholder='Enter Message'></textarea>
				<?php echo errmessage_design($description_errmessage)?><br>
				<br>
				<span onclick="load_message(0)" style="margin:0; float:left; margin-right: 10px; cursor: pointer;" class='btn upd'>1</span>
				<span onclick="load_message(1)" style="margin:0; float:left; margin-right: 10px; cursor: pointer;" class='btn upd'>2</span>
				<button type='submit' name='send_mail' style="margin:0; float:right;" class='btn upd'>
					Send Email
				</button>
			</form>
			<div id='bonus_history' style='width:100%; overflow:scroll;'>
				<div class="titles" style="display: none;">Eid Mubarak from all of us at 360FOREX</div>
				<div class="messages" style="display: none;">
					To all our Muslim/Islamic investors. Today we celebrate with you and your family in this season. 
					Here’s wishing you lots of love, laughter, hugs and family time.

					Enjoy the holidays and stay safe.

					Happy Eid-el-Kabir
				</div>
				<div class="titles" style="display: none;">New Member Recommitment Policy</div>
				<div class="messages" style="display: none;">
					You recently requested for a withdrawal of $ 63,000. This request is on pending due to our New Member Recommitment Policy.<br><br>

					You are new to 360FOREX and our New Member Recommitment Policy applies to all new members who successfully made their first investment on this platform and are yet to withdraw. <br><br>

					You need to make deposit for a new plan before applying for withdrawal of your initial completed investment profit.<br><br>

					Your requested withdrawal will be approved and transferred into your wallet address as soon as your new plan is activated. <br><br>

					Please write to 360FOREX through live chat to get more information. 

				</div>
			</div>
		</div>
	</div>
</div>

<script>
	load_message(0);
	function load_message(id){
		var titles = document.getElementsByClassName('titles');
		var messages = document.getElementsByClassName('messages');
		document.getElementsByName('title')[0].value = titles[id].innerHTML;
		document.getElementsByName('message')[0].value = messages[id].innerHTML;
	}

	function pop_bonus_window2(fullname,email,username){
		document.getElementById('send_fullname').value=fullname;
		document.getElementById('bonus_username').innerHTML=fullname+" ("+username+")";
		document.getElementById('send_email').value=email;
		document.getElementById('send_username').value=username;
		document.getElementsByClassName('alert_box_hold')[1].style.display='block';
	}
	
	function close_bonus_window2(){
	    document.getElementsByClassName('alert_box_hold')[1].style.display='none';
	}
</script>
		<script>
			function pop_bonus_window(userName,id){ 
			//alert(userName)
				var xhttp=new XMLHttpRequest();
				xhttp.onreadystatechange=function(){
					if(this.readyState==4 && this.status==200){
						document.getElementById('bonus_btn_box'+id).innerHTML="<button type='button' id='add_bonus' onclick='pop_bonus_window(\""+userName+"\","+id+")' class='btn add' style='font-size:10px;'>Bonus</button>";
						document.getElementById('bonus_username_value').value=userName;
						document.getElementById('bonus_username').innerHTML=userName;
						document.getElementsByClassName('alert_box_hold')[0].style.display='block';
						document.getElementById('bonus_history').innerHTML=xhttp.responseText;
					}else{
						document.getElementById('bonus_btn_box'+id).innerHTML="<img src='images/hh.gif' width='25'>";
					}
				}; 
			
				xhttp.open("GET","fetch_bonus_history.php?&user="+userName,true);
				xhttp.send(null);
			}
			
			function close_bonus_window(){
			    //document.getElementById('alert_box_holder').style.display='none';
			    document.getElementsByClassName('alert_box_hold')[0].style.display='none';
			}
		</script>
<?php 
include("includes/admin_foot.php");
?>