<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
alert_box();

		$errcode=array();
		$new_password=$r_new_password=$old_password="";
		$new_password_errmessage=$r_new_password_errmessage=$old_password_errmessage="";
		
		if(isset($_POST['change_password'])){

			if(!empty($_POST['old_password']) && isset($_POST['old_password'])){
				$old_password=clean_strings($_POST['old_password']);
				$sql="select * from `users_info` where (username='$username' or email='$username') and pin='$old_password'";
				$query=mysqli_query($con,$sql);
				if(mysqli_affected_rows($con) <= 0){
					$old_password_errmessage="Incorrect old PIN!!";
					$errcode[]=4;
				}
				
			}else{
				$old_password_errmessage="Old Password field cannot be empty";
				$errcode[]=4;
			}
	
			if(!empty($_POST['new_password']) && isset($_POST['new_password'])){
				$new_password=clean_strings($_POST['new_password']);
				
			}else{
				$new_password_errmessage="New PIN field cannot be empty";
				$errcode[]=4;
			}
			
			if(!empty($_POST['r_new_password']) && isset($_POST['r_new_password'])){
				$r_new_password=clean_strings($_POST['r_new_password']);
				
			}else{
				$r_new_password_errmessage="Retype PIN field cannot be empty";
				$errcode[]=6;
			}
			
			if($new_password!=$r_new_password){
				$r_new_password_errmessage="PIN Mismatch";
				$errcode[]=7;
			}else{
				$new_hashed_password=sha1($new_password);
			}
			
			if(!empty($errcode)){
				$msgbox="You have ". count($errcode) ." errors";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{
				mysqli_query($con, "update `users_info` set pin='$new_password' where username='{$_SESSION['customer_username']}'");
				if(mysqli_affected_rows($con)==1){
					$msgbox="PIN Changed Successfully";
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("change_pin");
				}
			}
		}
	?>
	
<style>
	.inputHolder{
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		margin: 2rem 0;
	}

	.inputHolder label{
		font-size: 1.2rem;
	}

	.inputHolder input, .text{
		border: 1px solid #333;
	}
	
	.inputHolder span{
		font-size: 1.2rem;
		color: red;
		font-style: italic;
	}

	.col_ast:nth-child(odd){
		padding-left: 1.5rem;
	}

	.col_ast:nth-child(even){
		padding-right: 1.5rem;
	}

	.rbtn{
		width: 100%; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		background-color: #0063cc;
		color: #fff;
	}

	.tbtn{
		width: auto; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		margin: auto 1rem;
		min-width: 10rem;
		border-radius: 1rem 0 1rem 0
	}

	.tupd{
		background-color: #0063cc;
		color: #fff;
	}

	.tline{
		background-color: transparent;
		border: 1px solid #0063cc;
		color: #0063cc;
	}

	.tupd:hover{
		background-color: #1174dd;
		color: #fff;
	}

	.flexCenter{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
	.flexApart{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

</style>

<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #666; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col_bg' style="float: left; width: 100%; padding: 2.0rem; margin: 00; background-color: #fff;">
			<form id='form1' name='form1' onsubmit="return myFunction('Change PIN?')" method='post' action='change_pin' enctype='multipart/form-data'>
				<div class='col one_col'>
					<div class="pTitle">
						Change PIN
					</div>
					<div class='col one_col flexCenter' style='width: 100%; margin: auto;'>
						<div class='one_col' style='max-width:500px; margin: 3rem auto;'>

							<div class='inputHolder'>
								<label>Old PIN</label>
								<input type='password' minlength=4 maxlength=4  placeholder='Enter Old PIN' required class='text' name='old_password'>
								<?php echo errmessage_design($old_password_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>New PIN</label>
								<input type='password' minlength=4 maxlength=4 placeholder='Enter New PIN' required class='text' name='new_password'>
								<?php echo errmessage_design($new_password_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Retype PIN</label>
								<input type='password' minlength=4 maxlength=4  placeholder='Confirm New PIN' required class='text' name='r_new_password'>
								<?php echo errmessage_design($r_new_password_errmessage)?>
							</div>

							<button type="submit" class="rbtn btn-fill" name="change_password" style="width: 100%; margin-bottom: 20px;">Change Password</button>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php 
include("includes/member_foot.php");
?>