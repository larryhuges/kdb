<?php
require_once("../includes/bootstrap.php");	
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-group'></i> Withdrawal History
				<br><hr>
			</div>
			<br>
			<table class='pay'>
				<tr class='pay'>
					<th class='pay'>S/N</th>
					<th class='pay'>Username</th>
					<th class='pay'>Description</th>
					<th class='pay'>Amount</th>
					<th class='pay'>Date</th>
					<th class='pay'>Status</th>
				</tr>
				
			<?php 
				$sql="select * from transactions order by date_of_event desc";
				$query=mysqli_query($con, $sql);
				$i=1;
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
					<tr class='pay'>	
						<td class='pay'><?php echo $i?></td>
						<td class='pay'><?php echo ucfirst($out['username'])?></td>
						<td class='pay'><?php echo $out['description']?></td>
						<td class='pay'>₦ <?php echo $out['amount']?></td>
						<td class='pay'><?php echo $out['date_of_event']?></td>
						<td class='pay'><?php echo $out['status']?></td>
					</tr>	
			<?php	
						$i++;
					}
				}else{
			?>
					<tr class='pay'>	
						<td class='pay' colspan='6'>No Record Found</td>
					</tr>
			<?php
				}
			?>
			</table>

		</div>
<?php 
include("includes/admin_foot.php");
?>