<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
?>

<style type="text/css">

	.text{
		border: .1rem solid #333;
	}
	
	.bankInput{
		display: block;
		max-width: 30rem; 
		cursor: pointer;
		position: relative;
	}

	.bankInput > div{
		position: absolute;
		top: 0;
		right: 0;
		width: 2rem; 
		height: 2rem;
		z-index: 10;
		margin: 1rem
	}

	table.kdbTable, tr.kdbTable{
		width:100%;
		//min-width:60rem;
		height:auto;
		margin:auto;
		margin-bottom:1%;
		border-collapse:collapse;
		font-family:sans-serif;
		border:.1rem solid #ecf0f5;
	}

.bcenter{
	text-align: center;
}

td.kdbTable, th.kdbTable{
	height:auto;
	vertical-align: center;
	margin:auto;
	border-collapse:collapse;
	border:.1rem solid #bcbcbc;
	font-size:1.2rem;
	padding: 1rem;
}
</style>


<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #666; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col_bg' style="float: left; width: 100%; padding: 2.0rem; margin: 00; background-color: #fff;">

			<div class="pTitle">
				Bills
			</div>
			
		</div>
	</div>
</div>
<?php 
include("includes/member_foot.php");
?>
