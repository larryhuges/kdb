<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<?php
	$message=$user="";
		if(isset($_POST['share'])){
			if(!empty($_POST['user']) && isset($_POST['user'])){
				$user=clean_strings($_POST['user']);
			}else{
				$errcheck=1;
			}

			if(!empty($_POST['message']) && isset($_POST['message'])){
				$message=clean_strings($_POST['message']);
			}else{
				$errcheck=1;
			}
				
			if($errcheck==1){
				$msg="Message Field cannot be empty";
				setcookie("err",$msg,time() + (3600*5),"/");
				redirect_to("testimonies");
			}else{
				if(mysqli_query($con,"insert into testimonies (username, message) values ('$user', '$message')")){
					$msgbox="Sent Successfully";
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("testimonies");
				}
			}
		}
	?>

	<?php
		if(isset($_GET['approved']) && isset($_GET['id']) && !empty($_GET['id'])){
			echo $approve=clean_strings($_GET['approved']);
			echo $id=clean_strings($_GET['id']);
			$delete_msg=null;
		}elseif(isset($_GET['delete_msg']) && isset($_GET['id']) && !empty($_GET['id'])){
			$id=clean_strings($_GET['id']);
			$delete_msg=clean_strings($_GET['delete_msg']);
			$approve=null;
		}else{
			$approve=null;
			$id=null;
			$delete_msg=null;
		}
		
			if($approve=='Yes'){
				mysqli_query($con,"update testimonies set good='No' where id=$id");
				redirect_to("testimonies");
			}elseif($approve=='No'){
				mysqli_query($con,"update testimonies set good='Yes' where id=$id");
				redirect_to("testimonies");
			}
			
			 if($delete_msg=='Yes'){
				mysqli_query($con,"delete from testimonies where id=$id");
				redirect_to("testimonies");
			}
	?>

		<div id="inner-frame">
			
			<div id='log_form'> 
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-comments-o'></i> Write Testimony
			</div><br>
			<hr>
			<br>
			<form name='form1' method='post' onsubmit="return myFunction('POST Testimony?')" action='' enctype='multipart/form-data'>
				<p>
				<input type='text' class='text' name='user' placeholder='Username'><br><br>
			  <textarea name='message' class='text' rows='3' cols='30' placeholder='Write Testimony'><?php echo $message;?></textarea><br><br>
				<button type='submit' class='btn upd' name='share' style='float:none;'>Share</button>
				</p>
			</form>
				
		</div>
	</div>

	<div id="inner-frame">
			<div id=''> 
			<div class='page_title' style='margin:0;'>
				List of Testimonies 
			</div>
			
			<table class='pay'>
				<tr class='pay'>
					<th class='pay'>S/N</th>
					<th class='pay'>UserNames</th>
					<th class='pay'>Message</th>
					<th class='pay'>Delete Message</th>
				</tr>
						<?php
					
						$sql_b="select id, username, message, good from testimonies order by date_sent asc";
						$query_b=mysqli_query($con,$sql_b);
						$i=1;
					if(mysqli_affected_rows($con)>=1){
						while($out_b=mysqli_fetch_assoc($query_b)){
							 echo "
								<tr class='pay'>
								<td class='pay'>$i</td>
								<td class='pay'>{$out_b['username']}</td>
								
								<td class='pay'>{$out_b['message']}</td>
								
								<td style='text-align:center;'><span class='button' onclick='delete_message(\"{$out_b['username']}\",{$out_b['id']})' style='float:none; cursor:pointer; border-radius:0;'><i class='fa fa-check'></i>&nbsp;Delete</span></td>
								</tr>
								
							";
							$i++;
						
						}
						?>
					</table>	
			<?php
					/*	$i++;
					}*/
				}else{
			?>
					<tr class='pay'>	
						<td class='pay' colspan='5'>Empty</td>
					</tr>
			<?php
				}
			?>
			</table>
				
		</div>
	</div>
	<script>
		function confirm_approve(str_value,approve,visible,acct){
			var x=window.confirm("Are You Sure You want to " + approve+ " " + str_value + "'s Testimony?");
			if(x==true){
				window.location.assign("testimonies.php?approved="+visible+"&id="+acct);
			}
		}
		
		function delete_message(str_value,acct){
			var x=window.confirm("Are You Sure You want to Delete " + str_value + "'s Testimony?");
			if(x==true){
				window.location.assign("testimonies.php?delete_msg=Yes"+"&id="+acct);
			}
		}
	</script>

<?php 
include("includes/admin_foot.php");
?>