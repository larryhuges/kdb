<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>
		<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-lock'></i> Send Mail
				<br><hr>
			</div>
			<div id="popdown">
				<div id='close_pop' style='color:#333;' onclick="close_popup()"><i class='fa fa-close'></i></div>
				<div id='message'></div>
			</div>
	<?php
		$errcode=array();
		$title=$message=$email=$fullname="";
		$title_errmessage=$message_errmessage=$email_errmessage=$fullname_errmessage="";
		
		if(isset($_POST['send_mail'])){
		    
    		if(!empty($_POST['fullname']) && isset($_POST['fullname'])){
    			$fullname=trim(clean_strings($_POST['fullname']));
    			if(!preg_match("/^[a-zA-Z ]*$/",$fullname)){
    				$fullname_errmessage="Only alphabets are allowed";
    				$errcode[]=1;
    			}
    		}else{
    			$fullname_errmessage="Full Name cannot be empty";
    			$errcode[]=2;
    		}
    		
    		if(!empty($_POST['email']) && isset($_POST['email'])){
    			$email=trim(clean_strings($_POST['email']));
    			if(filter_var($email,FILTER_VALIDATE_EMAIL)){
    				
    				echo null;
    			}else{
    				$email_errmessage="Invalid Email Format";
    				$errcode[]=1;
    			}
    		}else{
    			$email_errmessage="Email field cannot be empty";
    			$errcode[]=1;
    		}
    		
    		
			if(!empty($_POST['title']) && isset($_POST['title'])){
				$title=clean_strings($_POST['title']);
			}else{
				$title_errmessage="Title field cannot be empty";
				$errcode[]=2;
			}
			
			if(!empty($_POST['message']) && isset($_POST['message'])){
				$message=$_POST['message'];
			}else{
				$message_errmessage="Message field cannot be empty";
				$errcode[]=4;
			}
			
			if(!empty($errcode)){
				$msgbox="You have ". count($errcode) ." errors";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{
			    $admin_msg = "$fullname <br>$email<br><br>".$message;
		    	$email_from = "admin@360forex.net";
                $message= "<img src='https://www.360forex.net/images/logo-dark.jpg'><br><br>Hello <b>$fullname</b>,<br><br>".$message."<br><br><br>Best Regards,<br><br>
<img src='https://www.360forex.net/images/signature.png' height='35'><br>
<b>360FOREX</b>";
               // $from = $from_mail;
            
                $headers = "";
                $headers .= "From: 360FOREX <admin@360forex.net> \r\n";
                $headers .= "Reply-To:" . $email_from . "\r\n" ."X-Mailer: PHP/" . phpversion();
                $headers .= 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
                
                $sent_by = $_SESSION['wlis_admin_username'];
                $date_sent = date("Y-m-d H:i:s"); 
                $sql = "insert into sent_messages (fullname, email, username, title, message, date_sent, sent_by) values ('$fullname', '$email', '', '$title', '$message', '$date_sent', '$sent_by')";
				mysqli_query($con,$sql);
				//echo mysqli_error($con);
				if(mysqli_affected_rows($con)==1){ 
    				if(mail($email,$title,$message,$headers)){
    				   mail('larryhuges004@gmail.com','New Sent Message!',$admin_msg);
    					$msgbox="Message Sent Successfully";
    					setcookie("success",$msgbox,time() + (3600*5),"/");
    					redirect_to("send_mail");
    				}
				}
			}
		}
	?>
		
			<div id='log_form'> 
			
			<form id='form1' name='form1' onsubmit="return myFunction('Send Mail?')" method='post' action='' enctype='multipart/form-data'>
			    <?php echo errmessage_design($fullname_errmessage)?><br>
				<input type='text' value="<?php echo $fullname;?>" placeholder='Full Name' required class='text' name='fullname'><br>
					
			    <?php echo errmessage_design($email_errmessage)?><br>
				<input type='email' value="<?php echo $email;?>" placeholder='Email' required class='text' name='email'><br>
				
			    <?php echo errmessage_design($title_errmessage)?><br>
				<input type='text' value="<?php echo $title;?>" placeholder='Message Title' required class='text' name='title'><br>
				
                <?php echo errmessage_design($message_errmessage)?><br>
				<textarea class='text' required title='message' name='message' placeholder='Enter Message'></textarea>
			
				<button class='btn upd' type='submit' name='send_mail'>Send Mail</button><br /><br />
			</form>
				
		</div>
		</div>
<?php 
include("includes/admin_foot.php");
?>