<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
 $email = $_SESSION['customer_email'];
	$code = mt_rand(1000, 9999);
	mysqli_query($con, "update users_info set verification_code = '$code' where email = '$email'");
	$msg = "OTP Code \n\n $code";
	if(mysqli_affected_rows($con) == 1){
		//mail($email, "Verification Code", $msg);
  echo "OK";
	}
?>