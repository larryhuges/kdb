<?php
require_once("../includes/bootstrap.php");	
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<div class='g_col'>
			
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-group'></i> Confirm Withdrawal
				<br><hr>
			</div>
			<br>
			
				<?php
			/*
				if(isset($_POST['confirm'])){
				    
					$username=trim(clean_strings($_POST['username']));
					$trans_id=trim(clean_strings($_POST['trans_id']));
					$amount=trim(clean_strings($_POST['amount']));
					$id=trim(clean_strings($_POST['id']));
					$plan=trim(clean_strings($_POST['plan']));
					$output = getmemberinfo("firstname, lastname, email", $username);
					mysqli_query($con, "update transactions set status='confirmed' where id='$id' and username='$username'");
					mysqli_query($con, "update users_account set status='completed' where trans_id='$trans_id' and username='$username'");
					if(mysqli_affected_rows($con)==1){
						setcookie("success","Confirmed Successfully",time() + (3600*5),"/");
						$email_from = "admin@360forex.net";
                    
                        $fullname = $output['firstname'].' '.$output['lastname'];
                       // $from_mail = $fullname.'<'.$email_from.'>';
                    
                    
                    
                        $subject = "Withdrawal Sent!";
                        $message = "Hello ".strtoupper($fullname).",<br><br> $".number_format($amount)." has been sent successfully to the Bank Account you provided for the completion of $plan package.<br><br>
                        <b> Summary Bank Account Details:</b><br>
                        <table style='width:250px; border:none;' border='0'>
                             <tr>
                                <td>Bank Name</td>
                                <td>Nordea Bank Danmark</td>
                            </tr>
                            <tr>
                                <td> Account Name</td>
                                <td> Erif Ena Mujdat</td>
                            </tr>
                            <tr>
                                <td>Account Number </td>
                                <td>70003******759</td>
                            </tr>
                            
                            <tr>
                                <td>Routing Number </td>
                                <td>#885***858</td>
                            </tr>
                           
                            <tr>
                                <td>Swift Code </td>
                                <td>031***77</td>
                            </tr>
                            
                            <tr>
                                <td>Amount </td>
                                <td> $".number_format($amount)."  </td>
                            </tr>
                    
                        </table><br>
                            <b>Tips:</b> Earn more profit by referring friends and families to 360FOREX using your referral link.";
                        $message = "<img src='https://www.360forex.net/images/logo-dark.jpg'><br><br>".$message."<br><br>Best Regards,<br><br>
	<img src='https://www.360forex.net/images/signature.png' height='35'><br>
	<b>360FOREX</b>";
                       // $from = $from_mail;
                    
                        $headers = "";
                        $headers .= "From: 360FOREX <admin@360forex.net> \r\n";
                        $headers .= "Reply-To:" . $email_from . "\r\n" ."X-Mailer: PHP/" . phpversion();
                        $headers .= 'MIME-Version: 1.0' . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";    
                        mail($output['email'],$subject,$message,$headers);
                        
                        
                        $message_in = "Hello ".strtoupper($fullname).",<br><br> $".number_format($amount)." has been sent successfully to the Bank Account you provided for the completion of $plan package.<br><br>
                        <b> Summary Bank Account Details:</b><br>
                        <table style=\"width:250px; border:none;\" border=\"0\">
                            <tr>
                                <td>Bank Name</td>
                                <td>Nordea Bank Danmark</td>
                            </tr>
                            <tr>
                                <td> Account Name</td>
                                <td> Erif Ena Mujdat</td>
                            </tr>
                            <tr>
                                <td>Account Number </td>
                                <td>70003******759</td>
                            </tr>
                            
                            <tr>
                                <td>Routing Number </td>
                                <td>#885***858</td>
                            </tr>
                           
                            <tr>
                                <td>Swift Code </td>
                                <td>031***77</td>
                            </tr>
                            
                            <tr>
                                <td>Amount </td>
                                <td> $".number_format($amount)."  </td>
                            </tr>
                    
                        </table><br>
                            <b>Tips:</b> Earn more profit by referring friends and families to 360FOREX using your referral link.";
                        
                        $sent_by = $_SESSION['wlis_admin_username'];    
                        $date_sent = date("Y-m-d H:i:s"); 
                        $sql_in = "insert into sent_messages (fullname, email, username, title, message, date_sent, sent_by) values ('$fullname', '{$output['email']}', '$username', '$subject', '$message_in', '$date_sent', '$sent_by')";
        				mysqli_query($con, $sql_in);
        				echo mysqli_error($con)."<br><br>".$sql_in;
						redirect_to("confirm_withdraw");
					}
				}
				*/
				
			?>
			
			<?php
			/*
				if(isset($_POST['confirm'])){
				    
					$username=trim(clean_strings($_POST['username']));
					$trans_id=trim(clean_strings($_POST['trans_id']));
					$amount=trim(clean_strings($_POST['amount']));
					$id=trim(clean_strings($_POST['id']));
					$plan=trim(clean_strings($_POST['plan']));
					$output = getmemberinfo("firstname, lastname, email", $username);
					mysqli_query($con, "update transactions set status='confirmed' where id='$id' and username='$username'");
					mysqli_query($con, "update users_account set status='completed' where trans_id='$trans_id' and username='$username'");
					if(mysqli_affected_rows($con)==1){
						setcookie("success","Confirmed Successfully",time() + (3600*5),"/");
						$email_from = "admin@360forex.net";
                    
                        $fullname = $output['firstname'].' '.$output['lastname'];
                       // $from_mail = $fullname.'<'.$email_from.'>';
                    
                    
                    
                        $subject = "Withdrawal Sent!";
                        $message = "Hello ".strtoupper("Imani Nia").",<br><br> $".number_format($amount)." has been sent successfully to the Bank Account you provided for the completion of $plan package.<br><br>
                        <b> Summary Bank Account Details:</b><br>
                        <table style='width:250px; border:none;' border='0'>
                            <tr>
                                <td>Bank Name</td>
                                <td>Axos Bank</td>
                            </tr>
                            <tr>
                                <td> Account Name</td>
                                <td> Imani Nia</td>
                            </tr>
                            <tr>
                                <td>Account Number </td>
                                <td>70003******759</td>
                            </tr>
                            
                            <tr>
                                <td>Routing Number </td>
                                <td>#885509858</td>
                            </tr>
                           
                            <tr>
                                <td>Swift Code </td>
                                <td>03163977</td>
                            </tr>
                            
                            <tr>
                                <td>Amount </td>
                                <td> $".number_format($amount)."  </td>
                            </tr>
                    
                        </table><br>
                            <b>Tips:</b> Earn more profit by referring friends and families to 360FOREX using your referral link.";
                        $message = "<img src='https://www.360forex.net/images/logo-dark.jpg'><br><br>".$message."<br><br>Best Regards,<br><br>
	<img src='https://www.360forex.net/images/signature.png' height='35'><br>
	<b>360FOREX</b>";
                       // $from = $from_mail;
                    
                        $headers = "";
                        $headers .= "From: 360FOREX <admin@360forex.net> \r\n";
                        $headers .= "Reply-To:" . $email_from . "\r\n" ."X-Mailer: PHP/" . phpversion();
                        $headers .= 'MIME-Version: 1.0' . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";    
                        mail($output['email'],$subject,$message,$headers);
						redirect_to("confirm_withdraw");
					}
				}
				
				*/
			?>
			
			
			<?php
			
				if(isset($_POST['confirm'])){
					$username=trim(clean_strings($_POST['username']));
					$trans_id=trim(clean_strings($_POST['trans_id']));
					$amount=trim(clean_strings($_POST['amount']));
					$id=trim(clean_strings($_POST['id']));
					$plan=trim(clean_strings($_POST['plan']));
					$output = getmemberinfo("firstname, lastname, email", $username);
					mysqli_query($con, "update transactions set status='confirmed' where id='$id' and username='$username'");
					mysqli_query($con, "update users_account set status='completed' where trans_id='$trans_id' and username='$username'");
					if(mysqli_affected_rows($con)==1){
						setcookie("success","Confirmed Successfully",time() + (3600*5),"/");
						$email_from = "admin@360forex.net";
                    
                        $fullname = $output['firstname'].' '.$output['lastname'];
                       // $from_mail = $fullname.'<'.$email_from.'>';
                    
                    
                    
                        $subject = "Withdrawal Sent!";
                        $message = "Hello ".strtoupper($fullname).",<br><br> $".number_format($amount)." has been sent successfully to your registered Bitcoin wallet address for the completion of $plan package.<br><br>
                            <b>Tips:</b> Earn more profit by referring friends and families to 360FOREX using your referral link.";
                        $message = "<img src='https://www.360forex.net/images/logo-dark.jpg'><br><br>".$message."<br><br>Best Regards,<br><br>
	<img src='https://www.360forex.net/images/signature.png' height='35'><br>
	<b>360FOREX</b>";
                       // $from = $from_mail;
                    
                        $headers = "";
                        $headers .= "From: 360FOREX <admin@360forex.net> \r\n";
                        $headers .= "Reply-To:" . $email_from . "\r\n" ."X-Mailer: PHP/" . phpversion();
                        $headers .= 'MIME-Version: 1.0' . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";    
                        mail($output['email'],$subject,$message,$headers);
                        
                        
                        $message_in = "Hello ".strtoupper($fullname).",<br><br> $".number_format($amount)." has been sent successfully to your registered Bitcoin wallet address for the completion of $plan package.<br><br>
                            <b>Tips:</b> Earn more profit by referring friends and families to 360FOREX using your referral link.";
                            
                        $sent_by = $_SESSION['wlis_admin_username'];    
                        $date_sent = date("Y-m-d H:i:s"); 
                        $sql_in = "insert into sent_messages (fullname, email, username, title, message, date_sent, sent_by) values ('$fullname', '{$output['email']}', '$username', '$subject', '$message_in', '$date_sent', '$sent_by')";
        				mysqli_query($con, $sql_in);
        				
						redirect_to("confirm_withdraw");
					}
				}
				
				
			?>
			
			<table class='pay'>
				<tr class='pay'>
					<th class='pay'>S/N</th>
					<th class='pay'>Username</th>
					<th class='pay'>Description</th>
					<th class='pay'>Amount</th>
					<th class='pay'>Date</th>
					<th class='pay'>Action</th>
				</tr>
				
			<?php 
				$i=1;
				$sql="select * from transactions where description='Withdrawal' and visible = 'Yes' and status='requested' and username<>'Ahmed212' order by date_of_event desc";
				$query=mysqli_query($con, $sql);
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
					<tr class='pay'>	
						<td class='pay'><?php echo $i?></td>
						<td class='pay'><?php echo $out['username']?></td>
						<td class='pay'><?php echo $out['description']?></td>
						<td class='pay'>$ <?php echo number_format($out['amount'])?></td>
						<td class='pay'><?php echo $out['date_of_event']?></td>
						<td class='pay'>
							<form action='' method='post' onsubmit='return myFunction("Confirm Payment?")' enctype='multipart/form-data'>
								<input type='text' value='<?php echo $out['amount']?>' name='amount'>
								<input type='text' value='<?php echo $out['plan']?>' name='plan'>
								<input type='text' value='<?php echo $out['username']?>' name='username'>
								<input type='text' value='<?php echo $out['trans_id']?>' name='trans_id'>
								<input type='text' value='<?php echo $out['id']?>' name='id'>
								<button class='btn upd' name='confirm'>Confirm</button>
							</form>
						</td>
					</tr>	
			<?php
						$i++;
					}
				}else{
			?>
					<tr class='pay'>	
						<td class='pay' colspan='7'>Empty</td>
					</tr>
			<?php
				}
			?>
			</table>
				
		</div>

<?php 
include("includes/admin_foot.php");
?>