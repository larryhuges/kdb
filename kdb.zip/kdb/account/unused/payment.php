<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
alert_box();
?>

	<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
		<div class='bread_c'>
			<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Payment</span>
		</div>
	</div>

	<?php
		if(isset($_GET['en']) && $_GET['en']=='bitcoin'){
	?>
		<div class='g_col' style="box-shadow:none; border-radius: 3px; background-color: transparent;">
		<div class='bread_c' style="max-width: 450px; float: none; width: 100%; margin:0 auto; background-color:#cc0; color: #fff; font-family: SFUITextRegular">
			Sorry! Payment using Debit/Credit card is temporary unavailable. Please complete your mining plan purchase using our bitcoin service
		</div>
	</div>
	<?php
		}
	?>

<?php
		$errcode=array();
		$username=$amount=$btc_addr="";
		$amount_errmessage=$username_errmessage=$btc_addr_errmessage="";
		
		if(isset($_POST['submit'])){
	
			if(!empty($_POST['amount']) && isset($_POST['amount'])){
				$amount=clean_strings($_POST['amount']);
				if(!preg_match("/^[a-z0-9\.]*$/",$amount)){
					$amount_errmessage="Only Numbers are allowed";
					$errcode[]=3;
				}
				
			}else{
				$amount_errmessage="Amount field cannot be empty";
				$errcode[]=4;
			}
			
			if(!empty($_POST['btc_addr']) && isset($_POST['btc_addr'])){
				$btc_addr=clean_strings($_POST['btc_addr']);
				if(!preg_match("/^[a-zA-Z0-9]*$/",$btc_addr)){
					$btc_addr_errmessage="Only Numbers and Alphabets are allowed";
					$errcode[]=5;
				}
				
			}else{
				$btc_addr_errmessage="Address field cannot be empty";
				$errcode[]=6;
			}
			
			if(!empty($errcode)){
				$msgbox="You have made ". count($errcode) ." errors";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{
			    $date_of_event=date("Y-m-d H:i:s");
				mysqli_query($con, "insert into transactions (username, amount, btc_addr, description, date_of_event, plan) values ('{$_SESSION['wlis_member_username']}', $amount, '$btc_addr','Deposit','$date_of_event', '{$_SESSION['plan']}')");
				if(mysqli_affected_rows($con)==1){
					$admin_msg="{$_SESSION['wlis_member_username']} has funded his/her online wallet with the sum of $ $amount Login to confirm this payment";
					send_admin_mail('New Funds',$admin_msg);
					$msgbox="Your BITCOIN ACCOUNT will be credited as soon as we confirm your payment";
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("../miner/transactions");
				}else{
					echo mysqli_error($con);
				}
			}
		}
	?>
		<div class='g_col' style="width:98%; padding:0px 0; margin-top: 0;  background-color: transparent; border:0; box-shadow: none;">

			<div id='log_form'>
				<div align="center" style="width: 100%; position: relative; margin-bottom: 2%;">
					<div style="width:100px; margin:2%; border: 1px solid #333;">
						<img src="../images/qrcode.PNG" width='150px' class="slide_image_resize">
					</div>
					<span style="font-family: page_font_rob;"><?php echo '36s3ERipgoLU434BeKZnoB43rHu7aM9B2S';//$_SESSION['wlis_member_btc_addr'];?></span>
				</div>
				<div id='field_title'><br>
					Please send <b><?php echo usd_to_btc($_SESSION['usd'])." ($ {$_SESSION['usd']})"?></b> to the above address or scan the QR code<br><br>
					
					Note: After depositing please ensure to submit the amount you deposited and track id through the below form for confirmation<br><br>

					We will send you an email when we recieve the payment and your plan will be activated so you can start mining
				</div>
				<form id='form1' name='form1' onsubmit="return myFunction('Submit Form?')" method='post' action='' enctype='multipart/form-data'>
					<div class="input_icon_holder2"><?php echo errmessage_design($amount_errmessage)?>
						<span class="input_icon2"><i class="fa fa-dollar"></i></span>
						<input type='text' placeholder='Enter bitcoin Amount' value='<?php echo $_SESSION['usd'];?>' required class='text' name='amount'>
					</div>
					<div class="input_icon_holder2"><?php echo errmessage_design($btc_addr_errmessage)?>
						<span class="input_icon2"><i class="fa fa-link"></i></span>
						<input type='text' placeholder='Enter Tracking ID' value='<?php echo $btc_addr;?>' required class='text' name='btc_addr'>
					</div>
					
					<button class='btn upd' type='submit' name='submit'>Submit</button><br />
				</form>
					
			</div>
		</div>
</div>
<div id='alert_box_holder'>
	<div id="alert_box_center" style="margin-top: 5%; margin-bottom: 0;">
		<div id='alert_box' style="padding: 10% 5% 5% 5%; border-radius: 0;">
			<form action='' method='post' enctype='multipart/form-data'>
				
				<div align="center">
					<img src="../images/bitcoin.png" width="100">
				</div>
				<div id='errmsg'></div>
				<h2 style='color:#3b3; font-family: page_font_rob;'>
					Hello <?php echo ucwords($_SESSION['wlis_member_firstname']);?>,<br>
				</h2>
				<br>
				<p style='color:#555; font-family: page_title_font; font-size: 16px;'>
					You are about to purchase <b><span name='plan'><?php echo strtoupper($plan);?></span> PLAN</b>
				</p><br>
				
				<input type='hidden' value='<?php echo $plan;?>' name='plan_input' class='text_s'>

				<button type='submit' style="margin:0; float:left;" name='submit_deposit' class='btn upd'>
					Comfirm Purchase
				</button>
				<button type='button' onclick="close_alert()" style="margin:0; float:right;" name='submit_deposit' class='btn del'>
					Cancel Purchase
				</button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">

	function invest_now(str){

		var x=document.getElementById('alert_box_holder');
		var plan=document.getElementsByName('plan');
		var plan_input=document.getElementsByName('plan_input');
		plan[0].innerHTML=str;
		plan_input[0].value=str;
		x.style.display='block';
	}

	function close_alert(){
		var x=document.getElementById('alert_box_holder');
		x.style.display='none';
	}
</script>
<?php 
include("includes/member_foot.php");
?>