<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<div class='g_col' style='overflow-x:scroll;'>
			
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-group'></i> Deposit List
				<br><hr>
			</div>
			<br>
			
			<?php
		
				if(isset($_POST['confirm'])){
					$fullname=trim(clean_strings($_POST['fullname']));
					$email=trim(clean_strings($_POST['email']));
					$username=trim(clean_strings($_POST['username']));
					$amount=trim(clean_strings($_POST['amount']));
					
					$ref_bonus=trim(clean_strings($_POST['ref_bonus']));
					//$id=trim(clean_strings($_POST['id']));
					$trans_id=trim(clean_strings($_POST['trans_id']));
					$ref=trim(clean_strings($_POST['ref']));
					$plan=trim(clean_strings($_POST['plan']));
					
					$date_pledged = date("Y-m-d H:i:s");
					mysqli_query($con, "update users_account set status='in progress', activated='Yes', date_pledged='$date_pledged' where username='$username' and trans_id=$trans_id limit 1");
					
					echo mysqli_error($con)."<br>";
					if(mysqli_affected_rows($con)==1){
					    $welcome_bonus=0;
					    if($plan == 'promo' || $plan == 'trader' || $plan == 'gold'){
        					$wel_bonus_rate = 0.1;
        				}else{
        					$wel_bonus_rate = 0.05;
        				}
					    
        				$sq2="select trans_id from users_account where username='$username'";
        				$qu2=mysqli_query($con,$sq2);
        				echo mysqli_error($con)."2<br>";
        				if(mysqli_affected_rows($con) == 1){
        					$welcome_bonus = $wel_bonus_rate * $amount;
        					mysqli_query($con, "insert into bonuses (username, amount, description) values ('$username', $welcome_bonus, 'Welcome Bonus')");
        					echo mysqli_error($con)."3<br>";
        				}
        				
        				if($ref_bonus > 0){
    					    mysqli_query($con, "insert into bonuses (username, amount, description) values ('$ref', $ref_bonus, 'Referral Bonus For $fullname ($".$amount.") ".ucfirst($plan)." Plan Investment')");
    					    echo mysqli_error($con)."4<br>";
    					}
						setcookie("success","Confirmed Successfully",time() + (3600*5),"/");
						
						$email_from = "admin@360forex.net";
                    
                       // $fullname = $firstname.' '.$lastname;
                       // $from_mail = $fullname.'<'.$email_from.'>';
                    
                    
                    
                        $subject = "CONGRATULATIONS";
                        $message = "Hello ".strtoupper($fullname).",<br><br>Your trading package has been successfully activated. We hope you'll enjoy using our amazing trading platform.<br><br>.";
                        $message = "<img src='https://www.360forex.net/images/logo-dark.jpg'><br><br>".$message."<br><br>Best Regards,<br><br>
	<img src='https://www.360forex.net/images/signature.png' height='35'><br>
	<b>BINAFUNDS</b>";
                       // $from = $from_mail;
                    
                        $headers = "";
                        $headers .= "From: BINAFUNDS <admin@360forex.net> \r\n";
                        $headers .= "Reply-To:" . $email_from . "\r\n" ."X-Mailer: PHP/" . phpversion();
                        $headers .= 'MIME-Version: 1.0' . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";    
                        mail($email,$subject,$message,$headers);
                        
                        $message_in = "Hello ".strtoupper($fullname).",<br><br>Your trading package has been successfully activated. We hope you will enjoy using our amazing trading platform.";
                        
                        $sent_by = $_SESSION['wlis_admin_username'];    
                        $date_sent = date("Y-m-d H:i:s"); 
                        $sql_in = "insert into sent_messages (fullname, email, username, title, message, date_sent, sent_by) values ('$fullname', '$email', '$username', '$subject', '$message_in', '$date_sent', '$sent_by')";
        				mysqli_query($con, $sql_in);
                       
						redirect_to("deposit_list");
					}
				}
				
				
			?>
			
			<table class='pay'>
				<tr class='pay'>
					<th class='pay'>S/N</th>
					<th class='pay'>Username</th>
					<th class='pay'>Plan</th>
					<th class='pay'>Amount</th>
					<th class='pay'>Date</th>
					<th class='pay'>Action</th>
				</tr>
				
			<?php 
				$i=1;
				$restriction = restrict();
				$sql="select * from users_account where activated='No' and status='pending' and trade_status = 'paid'$restriction order by trans_id desc";
				$query=mysqli_query($con, $sql);
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
					<tr class='pay'>	
						<td class='pay'><?php echo $i?></td>
						<td class='pay'><?php echo $out['username']?></td>
						<td class='pay'><?php echo $out['plan']?></td>
						<td class='pay'>$ <?php echo number_format($out['pledge'])?></td>
						<td class='pay'><?php echo $out['date_pledged']?></td>
						<td class='pay'>
							<form action='' method='post' onsubmit='return myFunction("Confirm Payment?")' enctype='multipart/form-data'>
								<input type='text' value='<?php echo $out['email']?>' name='email'>
								<input type='text' value='<?php echo $out['firstname']." ".$out['lastname']?>' name='fullname'>
								<input type='text' value='<?php echo $out['username']?>' name='username'>
								<input type='text' value='<?php echo $out['plan']?>' name='plan'>
								<input type='text' value='<?php echo $out['referral']?>' name='ref'>
								<input type='text' value='<?php echo $out['referral_bonus']?>' name='ref_bonus'>
								<input type='text' value='<?php echo $out['pledge']?>' name='amount'>
								<input type='text' value='<?php echo $out['trans_id']?>' name='trans_id'>
								<button class='btn upd' name='confirm'>Confirm</button>
							</form>
						</td>
					</tr>	
			<?php
						$i++;
					}
				}else{
			?>
					<tr class='pay'>	
						<td class='pay' colspan='7'>Empty</td>
					</tr>
			<?php
				}
			?>
			</table>
				
		</div>

<?php 
include("includes/admin_foot.php");
?>