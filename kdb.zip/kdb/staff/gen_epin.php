<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>
		<div class='g_col'>
			
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-lock'></i> Generate E-Pin
				<br><br><hr>
			</div>
			<div id="popdown">
				<div id='close_pop' style='color:#333;' onclick="close_popup()"><i class='fa fa-close'></i></div>
				<div id='message'></div>
			</div>
		
		<div align='center'> 
		
			<input type='number' placeholder='Enter number of pins' style='width:200px; padding:5px;' class='txt' max='31' id='amt'><br><br>
			<input type='hidden' id='country_name'>
			<select id='country' onchange='set_name()' class='text' style='width:200px; padding:5px;'>
			<?php
				$names=array();
				$codes=array();
				$countries=countries_code();
				for($i=0;$i<count($countries);$i++){
					$names[]=$countries[$i]['name'];
					$codes[]=$countries[$i]['code'];
				}
				
				//sort($names);
				for($i=0;$i<count($names);$i++){
					echo "<option";
					if($codes[$i]=='NG'){
						echo " selected";
					}
					echo " value='{$codes[$i]}' class='country_names'>{$names[$i]}</option>";
				}
			?>
			
			</select><br><br>
			<button class='btn upd' type='button' name='update' onclick='gen_epin()'>Generate E-Pin</button><br /><br /><br />
			
			<div id='gen_code' style="padding:10px; height:auto; font-weight:bold; color:#333; background-color:#dadada; border-radius:5px;">
				# # # # # #
			</div>
		</div>
		</div>
		<script>
		function set_name(){
			var uu=document.getElementById('country').selectedIndex;
			var ii=document.getElementsByClassName('country_names')[uu].innerHTML;
			document.getElementById('country_name').value=ii;
		}
		
			function gen_epin(){ 
			var amt=document.getElementById('amt').value;
			var country=document.getElementById('country').value;
			var country_n=document.getElementById('country_name').value;
				var xhttp=new XMLHttpRequest();
				xhttp.onreadystatechange=function(){
					if(this.readyState==4 && this.status==200){
						document.getElementById('gen_code').innerHTML=xhttp.responseText;
					}else{
						document.getElementById('gen_code').innerHTML="<i class='fa fa-spinner fa-spin' style='font-size:50px;'></i>";
					}
				}; 
			
				xhttp.open("GET","wlis_key_gen.php?amt="+amt+"&country="+country+"&country_n="+country_n,true);
				xhttp.send(null);
			}
			
			function print_epins(){
				document.getElementById('h_bn').style.display="none";
				var print_content=document.getElementById('gen_code').innerHTML;
				print_content +="<div style='float:right; margin:2%;'><button onclick='window.print()'>Print</button></div>";
				var myWin=window.open("","_blank")
				myWin.document.write(print_content);
				myWin.document.print();
			}
		</script>
<?php 
include("includes/admin_foot.php");
?>