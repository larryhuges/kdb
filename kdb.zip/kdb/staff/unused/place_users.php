<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
		
		<div id="inner-frame">
			<div id='log_form'> 
			<?php
				$errcode=array();
				$down=$up="";
				$down_errmessage=$up_errmessage="";
				if(isset($_POST['place'])){
					if(empty($_POST['down'])){
						$down_errmessage="Downliner is Required<br>";
						$errcode[]=1;
					}else{
						$down=trim(clean_strings($_POST['down']));
						if(preg_match("/^[a-zA-Z0-9]*$/",$down)){
							$sql="select username from users_info where username='$down' and referral='afriposter' and verified='No' and num_downline=0 and pop<>''";
							if(mysqli_query($con,$sql) && mysqli_affected_rows($con)==1){
								echo null;
							}else{
								$errcode[]=1;
								$down_errmessage="Invalid Downline Username!!!<br>";
							}
						}else{
							$down_errmessage="Only Alphabets and Numbers are allowed<br>";
							$errcode[]=1;
						}	
											
					}
					
					if(empty($_POST['up'])){
						$up_errmessage="Upliner is Required<br>";
						$errcode[]=1;
					}else{
						$up=trim(clean_strings($_POST['up']));
						if(preg_match("/^[a-zA-Z0-9]*$/",$up)){
							$sql="select username from users_info where username='$up' and referral<>'afriposter' and verified='Yes' and num_downline<5 and pop<>'' ";
							if(mysqli_query($con,$sql) && mysqli_affected_rows($con)==1){
								echo null;
							}else{
								$errcode[]=1;
								$up_errmessage="Invalid Upline Username !!!<br>";
							}
						}else{
							$up_errmessage="Only Alphabets and Numbers are allowed<br>";
							$errcode[]=1;
						}	
											
					}
					$ud="";
					if($down==$up){
						$ud="<br>User cant refer him/herself<br>";
						$errcode[]=1;
					}
					
					if(!empty($errcode)){
						$msgbox="You have ". count($errcode) ." error"; if(count($errcode) >1){ $msgbox.="s";}
						$msgbox.="<br>";
						$msgbox.=$ud;
						$msgbox.=$up_errmessage;
						$msgbox.=$down_errmessage;
						
						echo "
							<script>
								popup(\"$msgbox\",'error');
							</script>
						";
					}else{
						$s_count="select username from users_info where referral='$up' order by date_joined asc";
						$q_count=mysqli_query($con, $s_count);
						$n_count=mysqli_num_rows($q_count);
						if($n_count<5){
							mysqli_query($con, "update users_info set referral='$up' where username='$down'");
							mysqli_query($con, "update users_info set ewallet=ewallet + 3000, num_downline=num_downline + 1 where username='$up'");
							$down="";
							$up="";
							setcookie("success","$down was placed under $up successfully",time() + (3600*5),"/");
							redirect_to("place_user");
						}elseif($n_count>=5){
							$msgbox="The Upline User name cirlce is filled";
							echo "
								<script>
									popup(\"$msgbox\",'error');
								</script>
							";
						}
					}
				}
			?>
				<form action="" method='post' onsubmit='return myFunction("Place User?")' >
					<label>Downliner<br>
					<input type='text' name='down' value='<?php echo $down;?>'>
					</label><br>
					<label>
					Upliner<br>
					<input type='text' name='up' value='<?php echo $up;?>'>
					</label><br>
					<button type='submit' class='btn upd' name='place'>Place User</button>
					
				</form>
			 
				Members without Referral
				<table class='pay'>
				
					<th colspan='3' class='pay'>Actions</th>
					<th class='pay'>Username</th>
					<th class='pay'>Full Name</th>
					<th class='pay'>Date Joined</th>
					<th class='pay'>Current Level</th>
					<th class='pay'>EWallet</th>
					<th class='pay'>Payment Receipt</th>
				<?php
					$i=0;
					$sql="select * from users_info where referral='afriposter' and verified='No' and num_downline=0 and pop<>'' order by date_joined asc";
					$query=mysqli_query($con, $sql);
					while($out=mysqli_fetch_array($query)){
				?>
						<tr class='pay'>
							
								<?php
									
									echo "<td id='change_btn$i' class='pay' align='center'>";
									if($out['visible']=='No'){
										echo "
											<button class='btn upd' onclick='block_unblock(\"Yes\",\"{$out['username']}\",$i)'>Unblock</button>
										";
									}else{
										echo "
											<button class='btn del' onclick='block_unblock(\"No\",\"{$out['username']}\",$i)'>Block</button>
										";
									}
								?>
							   
							</td>
							<td class='pay'><a href='edit_member.php?user=<?php echo $out['username'];?>' target='_blank' class="btn add">Edit</a></td>
							<td class='pay'><a href='view_downliners.php?user=<?php echo $out['username'];?>&user_stage=<?php echo $out['current_stage'];?>' target='_blank' class="btn upd">Downliners</a></td>
							<td class='pay'><?php echo $out['username'];?></td>
							<td class='pay'><?php echo $out['firstname']." ".$out['lastname'];?></td>
							<td class='pay'><?php echo $out['date_joined']?></td>
							<td class='pay'><?php echo $out['current_stage']?></td>
							<td class='pay'><?php echo $out['ewallet']?></td>
							<td class='pay'><img src='<?php echo $out['pop']?>' width='70' style='cursor:pointer;' onclick="showImage('<?php echo $out['pop']?>')"></td>
							
						<tr>
				<?php
						$i++;
					}
				?>
				</table>
				
				Members with incomplete cycle
				<table class='pay'>
				
					<th colspan='3' class='pay'>Actions</th>
					<th class='pay'>Username</th>
					<th class='pay'>No. Downliners</th>
					<th class='pay'>Full Name</th>
					<th class='pay'>Date Joined</th>
					<th class='pay'>Current Level</th>
					<th class='pay'>EWallet</th>
					<th class='pay'>Referral</th>
				<?php
					$i=0;
					$sql="select * from users_info where num_downline<5 and referral<>'afriposter' and verified='Yes' order by date_joined asc";
					$query=mysqli_query($con, $sql);
					while($out=mysqli_fetch_array($query)){
				?>
						<tr class='pay'>
							
								<?php
									
									echo "<td id='change_btn$i' class='pay' align='center'>";
									if($out['visible']=='No'){
										echo "
											<button class='btn upd' onclick='block_unblock(\"Yes\",\"{$out['username']}\",$i)'>Unblock</button>
										";
									}else{
										echo "
											<button class='btn del' onclick='block_unblock(\"No\",\"{$out['username']}\",$i)'>Block</button>
										";
									}
								?>
							   
							</td>
							<td class='pay'><a href='edit_member.php?user=<?php echo $out['username'];?>' target='_blank' class="btn add">Edit</a></td>
							<td class='pay'><a href='view_downliners.php?user=<?php echo $out['username'];?>&user_stage=<?php echo $out['current_stage'];?>' target='_blank' class="btn upd">Downliners</a></td>
							<td class='pay'><?php echo $out['username'];?></td>
							<td class='pay'><?php echo $out['num_downline'];?></td>
							<td class='pay'><?php echo $out['firstname']." ".$out['lastname'];?></td>
							<td class='pay'><?php echo $out['date_joined']?></td>
							<td class='pay'><?php echo $out['current_stage']?></td>
							<td class='pay'><?php echo $out['ewallet']?></td>
							<td class='pay'><?php echo $out['referral']?></td>
							
						<tr>
				<?php
						$i++;
					}
				?>
				</table>
			</div>
		</div>
		<script>
			function block_unblock(stat,userName,id){ 
			
				var xhttp=new XMLHttpRequest();
				xhttp.onreadystatechange=function(){
					if(this.readyState==4 && this.status==200){
						
						if(xhttp.responseText==1 && stat=='Yes'){
							document.getElementById('change_btn'+id).innerHTML="<button class='btn del' onclick='block_unblock(\"No\",\""+userName+"\","+id+")'>Block</button>";
							//document.getElementById('block_info').innerHTML=userName + " was BLOCK SUCCESSFUL!";
						}else if(xhttp.responseText==1 && stat=='No'){
							document.getElementById('change_btn'+id).innerHTML="<button class='btn upd' onclick='block_unblock(\"Yes\",\""+userName+"\","+id+")'>Unblock</button>";
							//document.getElementById('block_info').innerHTML=userName + " was UNBLOCK SUCCESSFUL!";
						}else if(xhttp.responseText==0){
							alert("Error Blocking " + UserName);
						}else{
							alert(stat+userName+id);
						}
					}else{
						document.getElementById('change_btn'+id).innerHTML="<img src='images/source.gif' width='25'>";
					}
				}; 
			
				xhttp.open("GET","block.php?sta="+stat+"&user="+userName,true);
				xhttp.send(null);
			}
		</script>
			
<?php 
include("includes/admin_foot.php");
?>