<?php
	require 'includes/bootstrap.php';
	include("includes/guest_area_head.php");
	alert_box();
?>
<?php
	$user_err = $pass_err = $email = "";
?>
<?php
			$errcheck=0;
			
			$user="";
			$pass="";
			
            $user_err="";
			$pass_err="";
			
	if(isset($_POST['signin'])){

		if(empty($_POST['user'])){
			$user_err="Username is Required";
			$errcheck=1;
		}else{
			$user=trim(clean_strings($_POST['user']));
			if(!preg_match("/^[a-zA-Z0-9+\@\.]*$/",$user)){
				$user_err="Only Alphabets and Numbers are allowed";
				$user="";
				$errcheck=1;
			}
				
		}
		
		if(empty($_POST['pass'])){
			$pass_err="Password Field Cannot be Empty";
			$errcheck=1;
		}else{
			$pass=trim(clean_strings($_POST['pass']));
			if(!preg_match("/^[a-zA-Z0-9]*$/",$pass)){
				$pass_err="Only Alphabets and Numbers are allowed";
				$pass="";
				$errcheck=1;
			}
		}
		if($errcheck==1){

			$msgbox="Invalid data format";
			echo "
				<script>
					popup(\"$msgbox\",'error');
				</script>
			";
		}else{
			$pass=sha1($pass);
			$sql="select id, username, visible, admin_filter from wlis_admin_table_768 where username='$user' and password='$pass'";
			$query=mysqli_query($con,$sql);
			$array_query=mysqli_fetch_assoc($query);
			
	 		if($array_query['visible']=='No'){
				$msgbox="Login Error Please Contact the Administrator";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}elseif(mysqli_affected_rows($con)==1){
				$_SESSION['wlis_admin_id']=$array_query['id'];
				$_SESSION['wlis_admin_username']=$array_query['username'];
				$_SESSION['wlis_admin_admin_filter']=$array_query['admin_filter'];
				redirect_to("staff/");
			}else{
				$msgbox="Incorrect Username or Password";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";				
			}
		}
	}
?>
<style>
	.loginFormBR{
		width: 100%;
		max-width: 50rem;
		background: #ffffff;
		padding: 2rem;
		color: #000;
	}

	.loginText{
		width: 100%;
		font-size: 1.5rem;
		line-height: 1.5;
		color: #29343D;
		background-image: none;
		border-radius: .4rem;
		transition: all .3s;
		background-color: transparent; 
		border: 1px solid #e6e6e6;
		padding:1rem 1.5rem; 
	}
	
</style>

<div id="frame" style="background-color: #fff; padding: 1rem; color: #fff; font-size: 1.4rem;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 7rem auto">
		<div class='col one_col' style="padding: 1rem; display: flex; align-items: center; justify-content: center;">
			
			<div class='loginFormBR'>
				<div class='page_title' style="margin:1rem 00; text-align: left; width: 100%; color:#333; padding: 1rem; float: left">
					Staff Login
				</div>
				
				<form action='' method='post' enctype='multipart/form-data'>
					<div class='inputHolder'>
						<label>Email</label>
						<input type='text' placeholder='Staff Email' required class='loginText mm' name='user' value="<?php echo $email;?>">
						<p class='formError' userError></p>
					</div>
					<br><br>
					<div class='inputHolder'>
						<label>Password</label>
						<input type='password' style="" placeholder='Password' required class='loginText mm' name='pass'>
						<p class='formError' passError></p>
					</div>					
					<br><br>
					<button type='submit' name='signin' class='inv_btn inv_btn_i'>
						Sign in
					</button><br>
					
				</form>
			</div>
			
		</div>  
	</div>
</div>
<?php include("includes/guest_area_foot.php");?>