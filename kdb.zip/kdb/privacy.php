<?php
	require 'includes/bootstrap.php';
	//confirm_logged_in();
	include("includes/guest_area_head.php");
	alert_box();
?>
<style type="text/css">
	.s_title{
		font-size: 16px; 
		font-weight: bold;
	}

	ul{
		margin-left: 20px;
	}

	li{
		line-height: 1.6;
	}
</style>
<?php echo page_header("PRIVACY & SECURITY", "media/images/backgrounds/bg.jpg")?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 70px auto">
		Welcome to Emigrant's Website. Protecting your privacy is fundamental to the way we conduct business, whether over the Internet, in a branch, over the telephone or at an ATM.

When you enter our site you can learn all about Emigrant - our products and services; our job opportunities; where we have branches and ATMs; and other special programs offered by the Bank. You do not need to provide us with any personal information.

Our server automatically collects the domain name but not the e-mail address of visitors to our Website. This allows us to keep track of the domain names used to access our site as well as collect aggregate information on what pages are viewed. The information we collect is used in a number of ways, such as:

    to improve the content of a web page
    to ensure that our site operates efficiently
    to evaluate consumer interest in certain products and services

From time to time, you may provide us with certain personal information such as your e-mail or postal address or telephone number. This information will only be used to respond to your request.

All information we receive through this Website, whether it is collected automatically or you provide it, is treated as confidential and is not shared with non-Emigrant organizations. Information may be shared with corporate affiliates as allowed by federal and state law.
E-mail Communications

At this time, e-mail communications to Emigrant are not encrypted, unless otherwise noted. We suggest that you do not send any confidential financial information about yourself to us by e-mail. For such purposes, you should contact us by telephone at 212-850-4444 or write to us at Emigrant Bank, P.O. Box 1403, New York, NY 10163.
We Value Your Business

If you have any questions or concerns about our policies, please call 212-850-4000 or write to the Customer Service Department, Emigrant Bank, 5 East 42nd Street, New York, NY 10017.
Consumer Privacy Policy

Emigrant's Consumer Privacy Policy describes how we use and protect your customer information. We believe that protecting your privacy is an integral part of the customer service we provide to you.

At Emigrant, we recognize that our relationship with you is based on trust and the protection of your private financial information merits the highest priority. That's why we have taken stringent measures and established corporate-wide procedures that ensure the confidentiality of all of your personal information whether we have received it directly from you or from a third party.

This policy outlines those procedures and will be provided to you each year as long as you maintain an ongoing relationship with us.
The Emigrant Family

Emigrant Family offers consumer-related financial services and includes Emigrant Bank (providing a full range of banking products); Emigrant Mortgage Company, Inc., (offering residential mortgage loans), Emigrant Funding Corporation (offering small balance commercial mortgage loans), Emigrant Agency, Inc. doing business as Emigrant Financial Services (featuring insurance and annuity products), Personal Risk Management Solutions, (a division of Emigrant Bank providing insurance advisory services), New York Private Bank and Trust (a division of Emigrant Bank offering private banking and trust services), New York Private Trust Company (an affiliate of Emigrant Bank offering trust services), Sarasota Private Trust Company (a subsidiary of Emigrant Bank offering wealth management and trust services), Cleveland Private Trust Company (a subsidiary of Emigrant Bank offering wealth management and trust services), EmigrantDirect, DollarSavingsDirect, and MySavingsDirect (each a division of Emigrant Bank offering certain banking products and services via the Internet), and New York Private Finance (an affiliate of Emigrant Bank offering structured loans and financial advisory services to private clients).
Our Business Practices

    We collect only the information we need in order to serve you and conduct our business.

    We treat all personal and financial information about you in a confidential manner. This information may be obtained directly from you or may be collected from other sources or may result from applications you process with us.

    We maintain physical, electronic and procedural safeguards to protect customer information. We utilize state-of-the-art technology for this purpose and upgrade, when appropriate, to improve our privacy protection performance.

    We limit access to your personal and financial information to those of our employees, agents and service providers that are required to have access to it in order to meet your financial needs or conduct our business.

    All of our employees, agents and service providers are responsible for compliance with the policies and procedures we have established to safeguard your personal and financial information.

    Our employees are governed by Emigrant's Code of Conduct which expressly requires the confidentiality of customer information. Our employees receive training in the importance of adhering to the procedures we've established to assure that confidentiality.

    Our data processing and electronic operations are performed in a secure technical environment that is accessed only by authorized personnel to transact legitimate business operations.

    We maintain electronic safeguards to protect customer privacy on our websites. This assures that when you conduct your business with us from your home or office, the privacy of your relationship and the information you furnish us online is protected.

    We carefully monitor our compliance with applicable laws and regulations and our internal security policies and procedures.

Information We Collect and Use

We collect and maintain customer information as part of servicing your account and your customer relationship with us. In the course of serving you, we collect information about you from a variety of sources including: information you provide to us on applications or forms such as your income and accounts with others; information we receive from an outside company such as a credit bureau regarding your credit history or employment status; or information about your transactions or experiences with companies affiliated with Emigrant.
Sharing Information

The customer information we collect is used to service your accounts and meet your financial needs. Information may be shared among the Emigrant Family of companies as well as with authorized third parties for a number of purposes including: to protect your accounts from unauthorized access or identity theft; to process your requests, such as loan applications; to service your accounts by issuing checks and account statements; or to keep you informed about financial services that may be of interest to you.

We may disclose the information we collect, as described above, with nonaffiliated third parties that are acting on our behalf including companies that provide support services for us such as data processors, technical systems consultants and programmers, check printers or companies that help us market Emigrant products and services to you. We may also share certain information with companies that help us conduct surveys or market research.

We may also disclose the customer information we collect to third parties as permitted or required by law. These third parties could include government entities, courts or other entities in response to subpoenas and other legal process or those with whom you have requested us to share information.

We may report information about your account(s) to credit bureaus and/or consumer reporting agencies. Late payments, missed payments, or other defaults on your account(s) may be reflected in your credit report and/or consumer report.

We do not share customer information with other non-affiliated companies for the purpose of marketing their products to you unless you have specifically requested in advance that we do so or unless the sharing is in connection with maintaining or servicing an account with us; or as part of a private label credit card program or offering life insurance-related products on behalf of such company; or with companies with whom we have joint marketing arrangements; or companies that perform advertising services on our behalf. Sharing information with these companies is permitted by law.

The Emigrant Family of companies offers a wide range of banking, loan and other products. By sharing information about your transactions and accounts among our Emigrant Family members or our other affiliates, we give you an opportunity to enjoy the integrated financial services available. This process improves your access to information about all of the account relationships you maintain, and makes it easier for you to conduct business with us. We may disclose all of the information we collect, as described above, within the Emigrant family of companies and other affiliated Emigrant companies including our administrative and service units which service your accounts or prepare your account statements and Emigrant companies that provide financial and other services including mortgage lenders and investment advisors.
Your Choice To Limit Marketing

By law, information that helps us identify you or that is derived from your transactions and experiences with us may be shared among the Emigrant family of companies (a) for purposes other than direct marketing, and (b) unless you instruct us otherwise, for direct marketing purposes. After you open your account you will be able to instruct us at any time not to share other personal information about you with other Emigrant companies. Please note that if you instruct us not to share such information with other Emigrant companies, you may continue to receive marketing information by mail about your existing Emigrant account(s) or receive survey calls. Marketing information may also be included in regular account mailings and statements and when you visit us online or at an ATM.

The policies and practices described in this disclosure are subject to change however, we will communicate any significant changes to you as required by applicable law. The policies and practices described in this disclosure replace all previous notices or statements regarding this subject.
Options To Limit Marketing

The Emigrant Family of companies is providing this notice. You may limit the Emigrant Family of companies, such as the residential mortgage loan or private banking affiliates, from marketing their products or services to you based on your personal information that they receive from other Emigrant companies. This information includes your income, your account history and/or your credit score. Your privacy choice will become effective within approximately thirty days of our receipt and will apply for at least five (5) years from when you tell us your choice. When that period expires, you will receive a renewal notice that will allow you to continue to limit marketing offers from the Emigrant Family of companies for at least another five (5) years.

Once you make a choice to limit marketing offers from the Emigrant Family of companies, you do not need to opt-out again until you receive the renewal notice.

Your preference will apply to all accounts linked to your Social Security (Tax Identification) number. If your account is held jointly, this privacy choice will be applied to that other person's accounts within the Emigrant family.

To limit marketing offers please login to your account at www.emigrant.com, select the "My Profile" tab and scroll to the bottom of the page to the "Privacy Policy" section to make your selection.

For instructions on how to limit marketing offers, click here.

Requires Adobe® Reader or Plugin 
		
	</div>
</div>

<?php include("includes/guest_area_foot.php");?>