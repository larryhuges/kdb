<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
alert_box();

	$firstname=$othernames=$lastname=$house_address=$mobile=$email = $gender = $dob = $country=$doc_name = $doc_id = $selfie = $frontp = $backp = $pin = $password = $r_password = "";

	$firstname_errmessage=$othernames_errmessage=$lastname_errmessage=$house_address_errmessage=$mobile_errmessage=$email_errmessage = $gender_errmessage = $dob_errmessage = $country_errmessage =$doc_name_errmessage = $doc_id_errmessage = $selfie_errmessage = $frontp_errmessage = $backp_errmessage = $pin_errmessage = $username_errmessage=$password_errmessage=$r_password_errmessage="";
	$error=0;
	
	$sql="select * from `users_info` where username='$username' limit 1";
	$query=mysqli_query($con, $sql);
	$out=mysqli_fetch_assoc($query);
	$referral=$out['referral'];
	$firstname=$out['firstname'];
	$othernames=$out['othernames'];
	$lastname=$out['lastname'];
	$mobile=$out['mobile'];
	$gender=$out['gender'];
	$dob=$out['dob'];
	$house_address=$out['house_address'];
	$country=$out['country'];
	$email=$out['email'];
	/* $gender=$out['gender'];
	$country=$out['country'];
	$state=$out['state']; */
	/*$account_name=$out['account_name'];
	$account_number=$out['account_number'];
	$bank_name=$out['bank_name'];
	$account_type=$out['account_type'];*/
	
	
	if(isset($_POST['update'])){
		
		if(!empty($_POST['firstname']) && isset($_POST['firstname'])){
			$firstname=trim(clean_strings($_POST['firstname']));
			if(!preg_match("/^[a-zA-Z]*$/",$firstname)){
				$firstname_errmessage="Only alphabets are allowed";
				$errcode[]=1;
			}
		}else{
			$firstname_errmessage="First Name cannot be empty";
			$errcode[]=2;
		}
		
		if(!empty($_POST['lastname']) && isset($_POST['lastname'])){
			$lastname=trim(clean_strings($_POST['lastname']));
			if(!preg_match("/^[a-zA-Z]*$/",$lastname)){
				$lastname_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$lastname_errmessage="Last Name cannot be empty";
			$errcode[]=4;
		}
		
		/* if(!empty($_POST['mobile']) && isset($_POST['mobile'])){
			$mobile=trim(clean_strings($_POST['mobile']));
			if(!preg_match("/^[0-9+]*$/",$mobile)){
				$mobile_errmessage="Only numbers are allowed";
				$errcode[]=1;
			}
		}else{
			$mobile_errmessage="Mobile cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['email']) && isset($_POST['email'])){
			$email=trim(clean_strings($_POST['email']));
			if(filter_var($email,FILTER_VALIDATE_EMAIL)){
				echo null;
			}else{
				$email_errmessage="Invalid Email Format";
				$errcode[]=1;
			}
		}else{
			$email_errmessage="Email field cannot be empty";
			$errcode[]=1;
		} 
		
		if(!empty($_POST['gender']) && isset($_POST['gender'])){
			$gender=trim(clean_strings($_POST['gender']));
			if(!preg_match("/^[a-zA-Z]*$/",$gender)){
				$gender_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$gender_errmessage="Gender cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['country']) && isset($_POST['country'])){
			$country=trim(clean_strings($_POST['country']));
			if(!preg_match("/^[a-zA-Z]*$/",$country)){
				$country_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$country_errmessage="Country cannot be empty";
			$errcode[]=4;
		}
		
		if(!empty($_POST['state']) && isset($_POST['state'])){
			$state=trim(clean_strings($_POST['state']));
			if(!preg_match("/^[a-zA-Z]*$/",$state)){
				$state_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$state_errmessage="State cannot be empty";
			$errcode[]=4;
		}*/
		
		/* if(!empty($_POST['account_name']) && isset($_POST['account_name'])){
			$account_name=trim(clean_strings($_POST['account_name']));
			if(!preg_match("/^[a-zA-Z ]*$/",$account_name)){
				$account_name_errmessage="Only alphabets are allowed";
				$errcode[]=1;
			}
		}else{
			$account_name_errmessage="Account Name cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['account_number']) && isset($_POST['account_number'])){
			$account_number=trim(clean_strings($_POST['account_number']));
			if(strlen($account_number)!=10){
				$account_number_errmessage.="Account field cannot be more than or less than 10 digit";
				$errcode[]=1;
			}
			if(!preg_match("/^[0-9]*$/",$account_number)){
				$account_number_errmessage="Only numbers are allowed";
				$errcode[]=1;
			}
		}else{
			$account_number_errmessage="Account No Field cannot be empty";
			$errcode[]=1;
		}
		
		if(!empty($_POST['bank_name']) && isset($_POST['bank_name'])){
			$bank_name=trim(clean_strings($_POST['bank_name']));
			if(!preg_match("/^[a-zA-Z ]*$/",$bank_name)){
				$bank_name_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$bank_name_errmessage="Bank Name cannot be empty";
			$errcode[]=4;
		} 
		
		if(!empty($_POST['account_type']) && isset($_POST['account_type'])){
			$account_type=trim(clean_strings($_POST['account_type']));
			if(!preg_match("/^[a-zA-Z ]*$/",$account_type)){
				$account_type_errmessage="Only alphabets are allowed";
				$errcode[]=3;
			}
		}else{
			$account_type_errmessage="Field cannot be empty";
			$errcode[]=4;
		}
		*/
		
			if(!empty($errcode)){
				$msgbox="You have ". count($errcode) ." error"; if(count($errcode) >1){ $msgbox.="s";}
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{//mobile='$mobile', email='$email', account_name='$account_name', account_number='$account_number', bank_name='$bank_name' gender='$gender', country='$country', state='$state' 
				$sql="update wlis_users_info_890 set firstname='$firstname', lastname='$lastname' where username='$username' limit 1";
				mysqli_query($con,$sql);//echo mysqli_error($con);
				if(mysqli_affected_rows($con)==1){
					$msgbox="Updated Successfully";
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("edit_profile");
				}
			}
		
	}
	
	
?>

<style>
	.inputHolder{
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		margin: 2rem 0;
	}

	.inputHolder label{
		font-size: 1.2rem;
	}

	.inputHolder input, .text{
		border: 1px solid #333;
	}
	
	.inputHolder span{
		font-size: 1.2rem;
		color: red;
		font-style: italic;
	}

	.col_ast:nth-child(odd){
		padding-left: 1.5rem;
	}

	.col_ast:nth-child(even){
		padding-right: 1.5rem;
	}

	.rbtn{
		width: 100%; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		background-color: #0063cc;
		color: #fff;
	}

	.tbtn{
		width: auto; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		margin: auto 1rem;
		min-width: 10rem;
		border-radius: 1rem 0 1rem 0
	}

	.tupd{
		background-color: #0063cc;
		color: #fff;
	}

	.tline{
		background-color: transparent;
		border: 1px solid #0063cc;
		color: #0063cc;
	}

	.tupd:hover{
		background-color: #1174dd;
		color: #fff;
	}

	.flexCenter{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
	.flexApart{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

</style>

<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #666; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col_bg' style="float: left; width: 100%; padding: 2.0rem; margin: 00; background-color: #fff;">
			<form action='' method='post' onsubmit="return myFunction('Update Account?')" enctype='multipart/form-data'>
				<div class='col one_col phases currentPhase' id='phase-1' pgn='1'>
					<div class='col one_col'>
						<div class="pTitle">
							Personal Information
						</div>
						<div class='col two_col col_ast'>
							<div class='inputHolder'>
								<label>First Name</label>
								<input type='text' placeholder='First Name' value='<?php echo $firstname?>' name='firstname' required class='text' />
								<?php echo errmessage_design($firstname_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Other Names (Optional)</label>
								<input type='text' placeholder='Other Names (Optional)' value='<?php echo $othernames?>' name='othernames' required class='text' />
								<?php echo errmessage_design($othernames_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Last Name</label>
								<input type='text' placeholder='Last Name' value='<?php echo $lastname?>' name='lastname' required class='text' />
								<?php echo errmessage_design($lastname_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Gender</label>
								<?php
									if(empty($gender)){
										$gen = "<option value=''>--Select Gender--</option>";
									}else{
										$gen = "<option>$gender</option>";
									}
								?>
								<select type='text' value='<?php echo $gender?>' name='gender' required class='text'>
									<?php echo $gen?>
									<option>Male</option>
									<option>Female</option>
								</select>
								<?php echo errmessage_design($gender_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Date Of Birth</label>
								<input type='text' placeholder='Date of Birth' value='<?php echo $dob?>' name='dob' required class='text' />
								<?php echo errmessage_design($dob_errmessage)?>
							</div>

						</div>

						<div class='col two_col col_ast'>
							
							<div class='inputHolder'>
								<label>Phone</label>
								<input type='tel' placeholder='phone' value='<?php echo $mobile?>' name='mobile' required class='text' />
								<?php echo errmessage_design($mobile_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Email</label>
								<input type='email' placeholder='Email Address' value='<?php echo $email?>' name='email' required class='text' />
								<?php echo errmessage_design($email_errmessage)?>
							</div>

							<div class='inputHolder'>
								<label>Resident Address</label>
								<textarea placeholder='Address' name='house_address' required class='text'><?php echo $house_address?></textarea>
								<?php echo errmessage_design($house_address_errmessage)?>
							</div>

							
							<div class='inputHolder'>
								<label>Country</label>
								<input type='text' placeholder='Country' value='<?php echo $country?>' name='country' required class='text' />
								<?php echo errmessage_design($country_errmessage)?>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php 
include("includes/member_foot.php");
?>