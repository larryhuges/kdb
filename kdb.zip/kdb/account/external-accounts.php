<?php 
require_once("../includes/sessions.php");	
require_once("../includes/connection.php");
require_once("../includes/functions.php");
confirm_logged_in();
include("includes/member_head.php");
?>

<style type="text/css">
	#inner-frame{
		max-width:1400px;
		width:100%;
		height:auto;
		margin:0 auto;
		padding:10px;
		position:relative;
		overflow-x:hidden;
	}

	.tabs_{
		float: left;
		position: relative;
		padding: 20px 20px;
		font-size: 14px;
		//background-color: red;
		text-align: center;

	}

	.ang_up {
		position: absolute;
		bottom: 0;
		left: 50%;
		width: 0; 
		height: 0; 
		border-left: 15px solid transparent;
		border-right: 15px solid transparent;
		border-bottom: 20px solid #f0f2f5;
		display: none;
	}

	.pages{
		float: left;
		padding: 0; 
		margin:0; 
		width: 100%; 
		margin-top: 10px;
	}

	.text{
		border: 1px solid #333;
	}

	td.bsheet{
		border: none;
	}
</style>

<div id="frame" style="background-color: #fff; border-top: 1px solid #ccc; padding: 0; color: #333; font-size: 14px;">
	<div id="inner-frame" style="padding: 0 10px;">
		<div class='col one_col' style="">
			<div class="tabs_" style="background-color: grey; color: #fff">
				Transfer Funds
			</div>
			<div class="tabs_" onclick="arrow(0)">
				Schedule Transfer
				<div class="ang_up"></div>
			</div>
			
			<a href="transfer-activities">
				<div class="tabs_">
					Transfer Activity
				</div>
			</a>
			<div class="tabs_" onclick="arrow(1)">
				External Accounts
				<div class="ang_up"></div>
			</div>		
		</div> 
		
	</div>	
</div>


<div id="frame" style="background-color: #F0F8FF; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame">

		<div class="pages col_bg" id="page1">
			<form action="" method="post" onsubmit="return validate_fields()">
				<div class="col three_col" style="text-align:left; padding: 20px;">
					<p class="field_title" >Transfer from</p>
					<input type="text" class="text" id="from_field" required value="Chase Bank">
				</div>
				<div class="col three_col" style="text-align:left; padding: 20px;">
					<p class="field_title" >Transfer to</p>
					<input type="text" class="text" id="to_field" required><br><br><br>

					<p class="field_title" >Transfer date</p>
					<input type="date" class="text" id="date_field" required>
				</div>
				<div class="col three_col" style="text-align:left; padding: 20px;">
					<p class="field_title" >Amount</p>
					<input type="text" class="text" id="amount_field" required placeholder="$"><br><br><br>

					<p class="field_title" >Memo (Optional)</p>
					<div style="line-height: 1;">
						<input type="text" class="text" id="memo_field" style="line-height: .2;">
						<span style="font-size: 12px; line-height: 1;">use letters and numbers only up to 32 characters</span><br><br>
					</div>
					<div>
						<button class="btn" type="button" style="width: 45%; color: #888; font-weight: bold; float: left;" onclick="cancel_funding()">Cancel</button>
						<button class="btn upd" type="submit" style="width: 45%; font-weight: bold; margin-left: 20px; float: right;">Next</button>
					</div>
				</div>
			</form>
		</div>


		<div id="page2" class="pages col_bg">
			<form action="" method="post" onsubmit="return validate_fields_1()">
				<div class="col l_col" style="text-align:left">
					<table class="bsheet">
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Routing number</td>
							<td class="bsheet">
								<input type="text" class="text" id="rounting_number" required>
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Account number</td>
							<td class="bsheet">
								<input type="password" class="text" id="account_number" required>
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Confirm Account number</td>
							<td class="bsheet">
								<input type="password" class="text" id="confirm_account_number" required>
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Account type</td>
							<td class="bsheet">
								<input type="text" class="text" id="account_type" required>
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;"></td>
							<td class="bsheet">
								<input type="checkbox"> Show account number
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Account Purpose</td>
							<td class="bsheet">
								<input type="text" class="text" id="account_purpose" required>
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Bank Name</td>
							<td class="bsheet">
								<input type="text" class="text" id="bank_name" required>
							</td>
						</tr>
						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;">Account nickname</td>
							<td class="bsheet">
								<input type="text" class="text" id="account_nickname" required>
							</td>
						</tr>

						<tr class="bsheet">
							<td class="bsheet" style="font-size: 14px; padding-bottom: 25px; text-align: right;"></td>
							<td class="bsheet">
								<button class="btn" type="button" style="width: 45%; color: #888; font-weight: bold; float: left;" onclick="cancel_funding()">Cancel</button>
								<button class="btn upd" type="submit" style="width: 45%; font-weight: bold; margin-left: 20px; float: right;">Next</button>
							</td>
						</tr>

					</table>
				</div>
				
			</form>
		</div>

		<div class="pages col_bg" id="page3">
			<p class="plan_title" style="padding: 0 20px;">
				Does everything looks OK?
			</p>
			<form action="" method="post">
				<div class="s_col_1" style="text-align:left">
					<p class="field_title" >Transfer from</p>
					<p id="from_label" style="font-weight: bold;">####</p>
				</div>
				<div class="s_col_1" style="text-align:left">
					<p class="field_title" >Transfer to</p>
					<p id="to_label" style="font-weight: bold;">###</p>

					<p class="field_title" >Transfer date</p>
					<p id="date_label" style="font-weight: bold;">###</p>
				</div>
				<div class="s_col_1" style="text-align:left">
					<p class="field_title" >Amount</p>
					<p id="amount_label" style="font-weight: bold;">###</p>

					<p class="field_title" >Memo (Optional)</p>
					<p id="memo_label" style="font-weight: bold;">###</p><br><br>
					
				</div>
			</form>
			<div style="margin-bottom: 20px; padding: 20px;">
				<p>
					Our business day ...
				</p>
				<button class="btn" style="width: 200px; color: #888; font-weight: bold; float: left;" onclick="cancel_funding()">Cancel</button>
				<button class="btn upd" onclick="transfer_key()" style="width:200px; font-weight: bold; margin-left: 20px; float: right;">Transfer money</button>
				<button class="btn" onclick="set_back()" style="width: 200px; color: #888; font-weight: bold; float: right;">Back</button>
			</div>
		</div>
	</div>
</div>

	<script type="text/javascript">

		arrow(0)

		function arrow(index){
			var a = document.getElementsByClassName('ang_up');
			var p = document.getElementsByClassName('pages');
			
			for(i=0; i<p.length; i++){
				a.item(i).style.display='none';
				p.item(i).style.display='none';
			}

		
			a.item(index).style.display='block';
			p.item(index).style.display='block';
		}
		/*

		function validate_fields_1(){
			
			page1=document.getElementById('page1');
			page2=document.getElementById('page2');
			rounting_number=document.getElementById('rounting_number').value;
			account_number=document.getElementById('account_number').value;
			account_type=document.getElementById('account_type').value;
			account_purpose=document.getElementById('account_purpose').value;
			bank_name=document.getElementById('bank_name').value;
			account_nickname=document.getElementById('account_nickname').value;
			document.getElementById('popdown').style.display='block';
			document.getElementById('loader_b').style.display='none';
			document.getElementById('spinner_b').style.display='block';
			setTimeout(function(){
				document.getElementById('popdown').style.display='none';
				document.getElementById('spinner_b').style.display='none';
				page1.style.display="none";
				page2.style.display="block";
			},"2000");

			return false;
		}

		function validate_fields(){
			page3=document.getElementById('page3');
			page2=document.getElementById('page2');
			from=document.getElementById('from_field').value;
			document.getElementById('from_label').innerHTML=from;

			to=document.getElementById('to_field').value;
			document.getElementById('to_label').innerHTML=to;

			date_=document.getElementById('date_field').value;
			document.getElementById('date_label').innerHTML=date_;

			amount=document.getElementById('amount_field').value;
			document.getElementById('amount_label').innerHTML=amount;

			memo=document.getElementById('memo_field').value;
			if(memo.trim()==""){
				document.getElementById('memo_label').innerHTML="None";
			}else{
				document.getElementById('memo_label').innerHTML=memo;
			}
			document.getElementById('popdown').style.display='block';
			document.getElementById('loader_b').style.display='none';
			document.getElementById('spinner_b').style.display='block';
			setTimeout(function(){
				document.getElementById('popdown').style.display='none';
				document.getElementById('spinner_b').style.display='none';
				page2.style.display="none";
				page3.style.display="block";
			},"2000");
			return false;
		}

		function transfer_key(){
			document.getElementById('popdown').style.display='block';
			document.getElementById('loader_b').style.display='block';
			document.getElementById('spinner_b').style.display='none';
			setTimeout(function(){
				document.getElementById('message_title').innerHTML='An Error Occured';
				document.getElementById('message').innerHTML="Please contact constomer service<br><br><button type='button' onclick='close_popup()' style='margin:0;' class='btn upd'>OK</button>";
				document.getElementById('loader_b').style.display='none';
			},"10000");
			return false;
		}

		function cancel_funding(){
			window.location.assign("http://chaseonlinebanking.com/account/");
		}

		function set_back(){
			page3=document.getElementById('page3');
			page2=document.getElementById('page2');
			page2.style.display="block";
			page3.style.display="none";
		}*/

	</script>

<?php 
include("includes/member_foot.php");
?>
