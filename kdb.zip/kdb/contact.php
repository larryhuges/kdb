<?php
	require 'includes/bootstrap.php';
	include("includes/guest_area_head.php");
?>
<?php echo page_header("CONTACT US", "media/images/backgrounds/bg.jpg")?>

<style type="text/css">
	
.m_l_col{
	width:65%;
	margin-left:0%;
	padding: 20px;
	float:left;
}

.m_s_col{
	width:35%;
	margin-left:0%;
	padding: 20px;
	float:left;
}

.text{
	border: 1px solid #333;
	margin: 10px 0;
}

@media screen and (max-width: 700px){
	.m_l_col, .m_s_col{
		width:100%;
	}
}

</style>

<div id="frame" style='bacground-color:#e2e2e2;'>
	<div id="inner-frame" style="max-width: 1100px; margin-bottom: 2%; line-height: 1.6;">
		<div class='m_l_col' style="font-size: 14px; padding: 20px; line-height: 2;">
			<p>
				<b>Secure Messaging using the Customer Service E-mail Form Below:</b> If you want to send sensitive or private information, please do so ONLY through our Secure Message Center, which transmits information in a secure, encrypted way using Secure Socket Layer connections.<br><br><br>

				<b>General Email Inquiries (Not Secure):</b> Sending e-mail over the Internet is not secure. Please do not send any sensitive or private information (e.g., Social Security numbers, account numbers, account information, User IDs, passwords, personal image or name, etc.) using a general messaging system (including the e-mail link that follows). Contact us by phone (at 1-800-836-1998) to discuss other methods of transmitting this data.
			</p>
			

		</div>

		<div class='m_s_col show_second_frame_col_1' style='font-family: sans-serif; padding:20px; font-size: 14px; bacground-color:#e2e2e2; '>
			<h3 class='page_title' style='font-size: 16px; padding: 0;'>
				Customer Service Email
			</h3>
			<br>
			<p>We want to hear from you. Please feel free to contact us with any banking requests, inquiries, or feedback.</p>
			<br>
			<?php
				$fullname_foot=$mobile_foot=$email_foot=$option_foot=$message_foot="";
				$errc=0;
				$errname=$erremail=$errmsg="";
				
			?>
			<form action='' method='post' onsubmit='return myFunction("Send Message?")'>

				<?php 
					if(empty($response)){
						echo null;
					}else{
						echo "<div align='center' id='field_title' style='font-weight:bold; color:#fff;'>$response</div>";
					}
				?>

				<input type='text' value='<?php echo $fullname_foot;?>' style='margin-left:0;' placeholder='Fullname' class='text' name='fullname_foot'><?php echo errmessage_design($errname)?>
					
				<input type='text' value='<?php echo $mobile_foot;?>' style='margin-left:0;' placeholder='Mobile' required class='text' name='mobile_foot'>

				<input type='email' value='<?php echo $email_foot;?>' style='margin-left:0;' placeholder='email' required class='text' name='email_foot'>
				<?php echo errmessage_design($erremail)?>
					
				<textarea name='message_foot' class='text' style='margin-left:0;' required rows='5' placeholder='Message'><?php echo $message_foot;?></textarea>
				<?php echo errmessage_design($errmsg)?>
				
				<button type='submit' style="float: right;" name='send_foot' class='inv_btn inv_btn_i'>
					Send Message
				</button>
			</form>
		</div>
	</div>
</div>

<?php include("includes/guest_area_foot.php");?>