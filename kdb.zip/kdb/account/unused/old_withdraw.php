<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
alert_box();
$plan=$amount=$t_id=$tt_i=$withdrawable=$msg="";
$plan=$amount=$t_id=$tt_i=$withdrawable=$firstname=$lastname=$mobile=$h_address=$bank_name=$name_on_account=$account_number=$account_type=$routing_number="";
	$errmessage=array();
if(isset($_POST['withdraw'])){
	if(!empty($_POST['tt_i']) && isset($_POST['tt_i'])){
		$t_id=clean_strings($_POST['tt_i']);
		if(!preg_match("/^[0-9]*$/",$t_id)){
			$errmessage[]="Only Numbers are allowed<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Id cannot be empty";
		$errcode[]=3;
	}
			
	if(!empty($_POST['r_input']) && isset($_POST['r_input'])){
		$amount=clean_strings($_POST['r_input']);
		if(!preg_match("/^[0-9]*$/",$amount)){
			$errmessage[]="Only Numbers are allowed<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Amount cannot be empty";
		$errcode[]=3;
	}

	if(!empty($_POST['bank_name']) && isset($_POST['bank_name'])){
		$bank_name=clean_strings($_POST['bank_name']);
		if(!preg_match("/^[a-zA-Z]*$/",$bank_name)){
			$errmessage[]="Only Alphabets are allowed for Bank Name<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Bank Name cannot be empty";
		$errcode[]=3;
	}

	if(!empty($_POST['name_on_account']) && isset($_POST['name_on_account'])){
		$name_on_account=clean_strings($_POST['name_on_account']);
		if(!preg_match("/^[a-zA-Z ]*$/",$name_on_account)){
			$errmessage[]="Only Alphabets are allowed for Name on Account<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Name on Account cannot be empty";
		$errcode[]=3;
	}

	if(!empty($_POST['account_number']) && isset($_POST['account_number'])){
		$account_number=clean_strings($_POST['account_number']);
		if(!preg_match("/^[0-9]*$/",$account_number)){
			$errmessage[]="Only Numbers are allowed for Account Number<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Account Number cannot be empty";
		$errcode[]=3;
	}

	if(!empty($_POST['account_type']) && isset($_POST['account_type'])){
		$account_type=clean_strings($_POST['account_type']);
		if(!preg_match("/^[a-zA-Z ]*$/",$account_type)){
			$errmessage[]="Only Alphabets are allowed for Account Type<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Account Type cannot be empty";
		$errcode[]=3;
	}

	if(!empty($_POST['mobile']) && isset($_POST['mobile'])){
		$mobile=clean_strings($_POST['mobile']);
		if(!preg_match("/^[0-9+]*$/",$mobile)){
			$errmessage[]="Only Numbers are allowed for Mobile<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Mobile cannot be empty";
		$errcode[]=3;
	}

	if(!empty($_POST['h_address']) && isset($_POST['h_address'])){
		$h_address=clean_strings($_POST['h_address']);
	}else{
		$errmessage[]="Home Address cannot be empty";
		$errcode[]=3;
	}
    $date_of_event=date("Y-m-d H:i:s");
	$sql="insert into transactions (firstname, lastname, mobile, h_address, bank_name, name_on_account, account_number, account_type, method_of_withdrawal, username, amount, description, user_id, date_of_event) values ('{$_SESSION['wlis_member_firstname']}', '{$_SESSION['wlis_member_lastname']}', '$mobile', '$h_address', '$bank_name', '$name_on_account', '$account_number', '$account_type', 'bank account', '{$_SESSION['wlis_member_username']}', $amount, 'Cash Withdrawal', $t_id, '$date_of_event')";

	$o="";
	if(!empty($errmessage)){
		foreach ($errmessage as $value) {
			$msg.=$value.'<br>';
		}
		$msg.="<br>$withdrawable";	
		echo "
			<script>
				popup(\"$msg\",'error');
			</script>
		";
	}else{
		if($amount<2000){
			$msg="Minimum withdrawable is $ 2,000";	
				echo "
					<script>
						popup(\"$msg\",'error');
					</script>
				";
		}else{
			$withdrawable=withdraw_bal($t_id);
			$earning=earning($t_id);
			if($withdrawable>=$amount){
			    if($amount==$earning){
    			    mysqli_query($con, $sql);
    				if(mysqli_affected_rows($con)==1){
    					$query=mysqli_query($con, "update `users_account` set withdrawn = $earning, status='pending' where username='{$_SESSION['wlis_member_username']}' and trans_id=$t_id");
    					if(mysqli_affected_rows($con)==1){
    						$msg="Withdrawal Request (of $ $amount) was Sent Successfully!!!<br>Your Account will be credited in less than 24hrs by Mr. Bones";
    						setcookie("success","$msg",time() + (3600*5),"/");
    						redirect_to("withdraw");
    					}
    				}
			    }else{
    				$msg="Amount must be same as Earning";	
    				echo "
    					<script>
    						popup(\"$msg\",'error');
    					</script>
    				";
    			}
			}else{
				$msg="Insufficient Balance";	
				echo "
					<script>
						popup(\"$msg\",'error');
					</script>
				";
			}
		}
	}
}
?>

<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
	<div class='bread_c'>
		<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Request Funds</span>
	</div>
</div>
<div class="g_col">
	<div id='' style='font-size:16px; overflow-x:scroll; color:#4CAF50;'> 
		<table class='pay'>
			<tr class='pay'>
				<th class='pay' style="color:#fff; background-color: #2196F3;">PLAN</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">RETURNABLE</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">TRADE GROWTH</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">AMOUNT</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">ACTION</th>
			</tr>

			<?php 
				$sql="select * from users_account where username='{$_SESSION['wlis_member_username']}' and status='in progress' order by trans_id desc";
				$query=mysqli_query($con,$sql);
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
						//$withdrawable=withdrawable($out['trans_id']);
			?>
						<tr class='pay'>
							<td class='pay'>&nbsp;<b><?php echo strtoupper($out['plan'])." (".($out['rate']*100)."%)";?></b>&nbsp;</td>
							<?php
						    	$mod = $out['returnable']%100;
						    	if($mod == 0){
						    	    $earn=$out['returnable'];
						    	}else{
						    	    $earn=$out['returnable']-$mod;
						    	}
                                
                            ?>
							<td class='pay'>&nbsp;$ <?php echo $earn;?>&nbsp;
							</td>
							<td class='pay'>&nbsp;$ <span id='t_widh<?php echo $out['trans_id'];?>'><?php echo $out['trade_growth'];?></span>&nbsp;</td>
							<!--<form action='withdraw' onsubmit='return JSalert()' method='post' enctype='multipart/form-data'>-->
								<td class='pay'>&nbsp;
									<input type='number' min='0' max='500000' id='g_am<?php echo $out['trans_id'];?>' name='<?php echo $out['trans_id'];?>' class='text_s' placeholder='Enter Amount' required>
									<input type='hidden' name='t_id' value="<?php echo $out['trans_id'];?>">&nbsp;
								</td>
								<td class='pay'>&nbsp;
									<button type='button' onclick='select_option("<?php echo $out['trans_id'];?>")' class='btn upd'>	Request Cash
									</button>
									&nbsp;
								</td>
							<!--</form>-->
						</tr>
			<?php 
					}
				}else{
			?>
					<tr class='pay'>
						<td class='pay' colspan="5" style="color: #888; text-align: center;">
							&nbsp; No Transactions Found &nbsp;
						</td>
					</tr>
			<?php
				}
			?>
		</table>
		
	</div>
</div>
<!--
<div id='alert_box_holder' style="overflow-y: scroll;">
	<div id="alert_box_center" style="margin-top: 5%; margin-bottom: 0;">
		<div id='alert_box' style="padding: 10% 5% 5% 5%; border-radius: 0;">
			
		</div>
	</div>
</div>

<script type="text/javascript">
	function select_option(str){
		var x=document.getElementById('alert_box_holder');
		var y=document.getElementById('alert_box');
		y.innerHTML+="<div id='s_form2'><form action='' method='post'><input type='text' placeholder='Bank Name' required class='text_s' name='bank_name'> <input type='text' placeholder='Name on Account' name='name_on_account' required class='text_s'><input type='text' name='account_number' required class='text_s' placeholder='Account Number'><select class='text_s' required name='account_type'><option value=''>---Account Type---</option><option>Checking Account</option><option>Savings Account</option></select>					<input type='text' name='mobile' required class='text_s' placeholder='Mobile'><br><textarea class='text_s' name='h_address' required placeholder='Home Address and Zip Code'></textarea> <button type='submit' style='margin:0; float:left;' name='withdraw' class='btn upd'>					SUBMIT				</button><input type='hidden' value='' id='r_input' name='r_input' class='text_s'><input type='hidden' value='' name='tt_i' class='text_s'> <button type='button' onclick='close_alert()' style='margin:0; float:right;' class='btn del'>BACK</button></form></div>"; 

		y.innerHTML+="";
		//y.style.animation='d_in .5s ease';
		//var display=document.getElementById('plann');
		var input=document.getElementsByName(str);
		var r_input=document.getElementById('r_input');
		var tt_i=document.getElementsByName('tt_i');
		//display.innerHTML=input[0].value;//alert(r_input.value);
		r_input.value=input[0].value;
		
		tt_i[0].value=str;
		x.style.display='block';
	}


	function close_alert(){
		var x=document.getElementById('alert_box_holder');
		var y=document.getElementById('alert_box');
		x.style.display='none'; 
		y.innerHTML="";
	}
	
</script>
-->
<?php 
include("includes/member_foot.php");
?>