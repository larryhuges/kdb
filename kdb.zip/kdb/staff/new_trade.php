<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>
		<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-lock'></i> Add New Transaction
				<br><hr>
			</div>
			<div id="popdown">
				<div id='close_pop' style='color:#333;' onclick="close_popup()"><i class='fa fa-close'></i></div>
				<div id='message'></div>
			</div>
	<?php
		$errcode=array();
		$username=$amount=$description="";
		$username_errmessage=$amount_errmessage=$description_errmessage="";
		
		if(isset($_POST['update'])){
			if(!empty($_POST['username']) && isset($_POST['username'])){
				$username=clean_strings($_POST['username']);
				if(!preg_match("/^[a-zA-Z0-9]*$/",$username)){
					$username_errmessage="Only Numbers and Alphabets are allowed";
					$errcode[]=1;
				}
			}else{
				$username_errmessage="Username field cannot be empty";
				$errcode[]=2;
			}
			
			if(!empty($_POST['amount']) && isset($_POST['amount'])){
				$amount=clean_strings($_POST['amount']);
				if(!preg_match("/^[0-9]*$/",$amount)){
					$amount_errmessage="Only Numbers are allowed";
					$errcode[]=3;
				}
				
			}else{
				$amount_errmessage="Amount field cannot be empty";
				$errcode[]=4;
			}
			
			if(!empty($_POST['description']) && isset($_POST['description'])){
				$description=clean_strings($_POST['description']);
				if(!preg_match("/^[a-zA-Z ]*$/",$description)){
					$description_errmessage="Only Alphabets are allowed";
					$errcode[]=5;
				}
				
			}else{
				$description_errmessage="Description field cannot be empty";
				$errcode[]=6;
			}
			
			if(!empty($errcode)){
				$msgbox="You have ". count($errcode) ." errors";
				echo "
					<script>
						popup(\"$msgbox\",'error');
					</script>
				";
			}else{
				mysqli_query($con, "insert into transactions (username, amount, description) values ('$username', '$amount', '$description')");
				if(mysqli_affected_rows($con)==1){
					$msgbox="Transaction Added Successfully";
					setcookie("success",$msgbox,time() + (3600*5),"/");
					redirect_to("new_trans");
				}
			}
		}
	?>
		
			<div id='log_form'> 
			
			<form id='form1' name='form1' onsubmit="return myFunction('Add Transaction?')" method='post' action='' enctype='multipart/form-data'>
				&nbsp;<input class='text' type='text' required title='Username' name='username' placeholder='Username'/>
				<span style='color:red; font-style:italic;'><?php echo $username_errmessage;?></span>

				&nbsp;<input class='text' type='text' required title='amount' name='amount' placeholder='Amount'/>
				<span style='color:red; font-style:italic;'><?php echo $amount_errmessage;?></span>

				&nbsp;
				<select class='text' required name='description'>
					<option value="">Description</option>
					<option>Deposit</option>
					<option>Cash Withdrawal</option>
				</select>
				<span style='color:red; font-style:italic;'><?php echo $description_errmessage;?></span>

				<br><br>
				<button class='btn upd' type='submit' name='update'>Add Transaction</button><br /><br />
			</form>
				
		</div>
		</div>
<?php 
include("includes/admin_foot.php");
?>