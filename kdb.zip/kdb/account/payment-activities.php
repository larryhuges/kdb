<?php 
require_once("../includes/sessions.php");	
require_once("../includes/connection.php");
require_once("../includes/functions.php");
//$url_ = base_url()."logout.php?key=404";
//redirect_to($url_);
confirm_logged_in();
include("includes/member_head.php");
?>
<style type="text/css">
	#inner-frame{
		max-width:1400px;
		width:100%;
		height:auto;
		margin:0 auto;
		padding:10px;
		position:relative;
		overflow-x:hidden;
	}

	.tabs_{
		float: left;
		position: relative;
		padding: 20px 20px;
		font-size: 14px;
		//background-color: red;
		text-align: center;

	}

	.arrow-up {
		position: absolute;
		bottom: 0;
		left: 50%;
		width: 0; 
		height: 0; 
		border-left: 15px solid transparent;
		border-right: 15px solid transparent;
		border-bottom: 20px solid #f0f2f5;
		display: none;
	}
</style>
<div id="frame" style="background-color: #F0F8FF; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame">
		<div class='col one_col col_bg' style="padding: 0px 20px;">
			<div style="float: left; width: 100%; padding: 10px; margin: 0px 0; background-color: #fff;">

				<div style="float: left; width: 100%; padding: 10px; padding-bottom: 20px; font-size: 15px; border-bottom: 2px solid #333;">
					Account Activity
				</div>
				<table class="p2p">
					<tr class="p2p" style="border-bottom: 1px solid #aaa;">
						<th class="p2p">Date <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Amount <i class="fa fa-caret-down"></i></th>
						<th class="p2p" style="">Description <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Status <i class="fa fa-caret-down"></i></th>
						<th class="p2p">Type <i class="fa fa-caret-down"></i></th>
						
						<!--<th class="p2p">Balance <i class="fa fa-caret-down"></i></th>-->
					</tr>
					<?php
						$s = "select * from r_transactions where sender_id = '$t_username' order by date_of_event desc";
						$q = mysqli_query($con, $s);
						if(mysqli_affected_rows($con) >= 1){
							while ($o = mysqli_fetch_assoc($q)) {
					?>
								<tr class="p2p" style="border-bottom: 1px solid #aaa;">
									<td class="p2p"><?php echo $o['date_of_event']?></td>
									<td class="p2p"><?php echo number_format($o['amount'], 2)?></td>
									<td class="p2p"><?php echo ucwords($o['description'])?></td>
									<td class="p2p"><?php echo ucwords($o['status'])?></td>
									<td class="p2p"><?php echo ucwords($o['plan'])?></td>
								<!--	<td class="p2p"><?php echo number_format($t_available_balance, 2)?></td>-->
									
								</tr>
					<?php
							}
						}else{
					?>
							<tr class="p2p" style="border-bottom: 1px solid #aaa;">
								<td class="p2p">No Transfer Activity</td>
							</tr>
					<?php
						}
					?>
				</table>
			</div>
		</div>
	</div>	
</div>



<?php 
include("includes/member_foot.php");
?>
