<?php
	require 'includes/bootstrap.php';
	include("includes/guest_area_head.php");
	alert_box();
?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #fff; background: #000A1E url(media/images/photo/bg_main_visual2.jpg) no-repeat center top; background-size: cover; z-index: 2;">
	<div id="inner-frame" class='' style="padding: 0 0; margin: 70px auto; z-index: 3;">
		<div class='col l_col l_col_a'>
			<div>
				<p><strong style='color: #333; font-size: 2.4rem;'>KDB BANK</strong></p>
				<br> 
				<h1><img src="/media/images/photo/img_copyarea_2_en2.png" width='500' alt="Global KDB"></h1> 
				<br>
				
			</div>
		</div>  
	</div>
</div>
<style>
	.sIco{
		width: auto;
		height: auto;
		position: absolute;
		bottom: 28rem;
		right: 20rem;
		display: flex;
		align-items: center;
		justify-content: center;
		z-index: 22;
		padding: 2rem;
	}

	.sIcoSecond{
		width: 100%;
		height: 100%;
		border-radius: 0 3rem 0 3rem;
		background-color: #0063cc;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		padding: 2rem;
	}

	.innerBox2{
		width: 100%;
		height: auto;
		margin: .5rem 2rem;
		position: relative;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		transition: all 0.25s ease-in-out;
	}
	

	.innerBox2:hover{
		color: #fff;
	}

	.itemHolder2{
		position: relative;
		width: 55px;
		height: 55px;
	}

	.beforeItem{
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		z-index: 1;
	}

	.innerBox2 span{
		width: auto;
		margin-left: 1.5rem;
		color: #fff;  
		font-size: 1.7rem;
	}
		
</style>

<div class='sIco'>
	<div class='sIcoSecond'>
		<a href='access'>
			<div class="innerBox2">
				<div class="itemHolder2">
					<div class="beforeItem" style='background: url(/media/images/photo/ico_chgl_com_01.png) no-repeat center center;'></div>
					<i class="item2"></i>
				</div>
				<span>Login</span>
			</div>
		</a>
		<a href='register'>
			<div class="innerBox2" style='border-top: 1px solid gray;padding: .5rem 0;'>
				<div class="itemHolder2">
					<div class="beforeItem" style='background: url(/media/images/photo/ico_chgl_com_02.png) no-repeat center center;'></div>
					<i class="item2"></i>
				</div>
				<span>Sign Up</span>
			</div>
		</a>
	</div>
</div> 
<style>
	.cus{
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		text-align: left;
		 color: #666;
	}
</style>
<div id="frame" style="padding: 3rem 0; border-top: 1px solid #dedede; background: #f5f7fb;">	
	
	<div id="inner-frame" align="center">

		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus' style='padding-left: 8.5rem;
    background: url(media/images/photo/ico_cscont.png) no-repeat 0 0;'>

				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>KDB Customer Center</span>
				
				<p style='font-size: 1.4rem; color: #666;'>Monday ~ Friday 09:00 ~ 18:00 (Korea time) </p>

			</div>
		</div>
		
		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus'>

				<p style='font-size: 1.4rem; color: #666;'>Domestic </p>
				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>1588-1500, 1668-1500</span>
				

			</div>
		</div>

		<div class='col three_col' style="padding: 1rem;">
			<div class='col one_col cus'>


				<p style='font-size: 1.4rem; color: #666;'>Overseas </p>
				<span style='margin-bottom: 1rem; color: #001f5b; font-size: 2rem;'>+82-1588-1500, +82-1668-1500</span>

			</div>
		</div>

		
	</div>
</div>
<?php include("includes/guest_area_foot.php");?>