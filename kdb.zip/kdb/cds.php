<?php
	require 'includes/bootstrap.php';
	//confirm_logged_in();
	include("includes/guest_area_head.php");
	alert_box();
?>
<style type="text/css">
	.s_title{
		font-size: 16px; 
		font-weight: bold;
	}

	ul{
		margin-left: 20px;
	}

	li{
		line-height: 1.6;
	}
</style>
<?php echo page_header("CDs", "media/images/backgrounds/bg.jpg")?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 70px auto">
		<p>
			KDB offers Certificates of Deposit with minimum investments as low as $1000. Your competitive interest rate is fixed for the term you select and compounded daily. CDs do not permit transaction activity, but you can withdraw your posted interest at anytime.
		</p>
		<br>

		<ul>
		    <li>Choice of terms from 3 months to 10 years.</li>
		    <li>FDIC insurance to the maximum extent allowed by law.</li>
		    <li>Automatic notification prior to maturity.</li>
		    <li>Balances in KDB CD accounts can be included in the relationship balance requirement for a checking account free of monthly service charges.</li>
		</ul>
		<br>

		
		<p>
			For more information please call 1-800-836-1998, Monday through Friday 8:00 AM - 6:00 PM ET or e-mail us at onlinecustomerservice@KDB.com. 
		</p>
		
	</div>
</div>

<?php include("includes/guest_area_foot.php");?>