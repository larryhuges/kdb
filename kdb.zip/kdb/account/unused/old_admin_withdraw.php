<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	

	<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
		<div class='bread_c'>
			<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Withdrawal Request</span>
		</div>
	</div>
	<div class='g_col' style="overflow-x:scroll;">			
		<?php
			if(isset($_POST['confirm'])){
				$username=trim(clean_strings($_POST['username']));
				$g_em=mysqli_query($con,"select email from users_info where username='$username' limit 1");
				$g_o=mysqli_fetch_assoc($g_em);
				$id=trim(clean_strings($_POST['id']));
				
				mysqli_query($con, "update transactions set status='confirmed' where id='$id' and username='$username'");
				if(mysqli_affected_rows($con)==1){
					$subject='Withdrawal Confirmed';
					$message="Dear ".$username.",<br><br>Your Withdrawal Request of $amount) of your 4XMINING online wallet has been confirmed successfully on".formatted_date(date("Y-m-d h:i:s")).".<br> Please login and start trading.";
					$url="";
				send_mail($email,$username,$subject,$message,$url);
					setcookie("success","Confirmed Successfully",time() + (3600*5),"/");
					redirect_to("confirm_payment");
				}
			}
		?>

		<table class='pay'>
			<tr class='pay'>
				<th class='pay' style="color:#fff; background-color: #2196F3;">S/N</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">Username</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">Amount</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">Date</th>
				<th class='pay' colspan="2" style="color:#fff; background-color: #2196F3;">Actions</th>
			</tr>
			
		<?php 
			$i=1;
			$sql="select * from transactions where description='Cash Withdrawal' and status='pending' order by date_of_event desc";
			$query=mysqli_query($con, $sql);
			if(mysqli_affected_rows($con)>=1){
				while($out=mysqli_fetch_assoc($query)){
		?>
				<tr class='pay'>	
					<td class='pay'><?php echo $i?></td>
					<td class='pay'><?php echo $out['username']?></td>
					<td class='pay'>$ <?php echo number_format($out['amount'])?></td>
					<td class='pay'><?php echo formatted_date($out['date_of_event'])?></td>
					<td class='pay'>
						<form action='' method='post' onsubmit='return myFunction("Confirm Payment?")' enctype='multipart/form-data'>
							<input type='hidden' value='<?php echo $out['username']?>' name='username'>
							<input type='hidden' value='<?php echo $out['id']?>' name='id'>
							<button class='btn upd' name='confirm'>Confirm</button>
						</form>
					</td>
				</tr>	
		<?php
					$i++;
				}
			}else{
		?>
				<tr class='pay'>	
					<td class='pay' colspan='7'>Empty</td>
				</tr>
		<?php
			}
		?>
		</table>
			
	</div>

<?php 
include("includes/admin_foot.php");
?>