<?php

	require("constants.php");
	$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD);
	
	if(!$con){
		die("Error Creating Connection".mysqli_error($con));
	}
	
	$sel_db=mysqli_select_db($con,DB_NAME);
	if(!$sel_db){
		die("Error Connecting to Database".mysqli_error($con));
	}
	
?>