<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/admin_head.php");
?>	
	<div class='g_col'>
			<div class='page_title' style='margin:0;'>
				<i class='fa fa-key'></i> E-Pins
				<br><hr>
			</div>
			<br>
			<table class='pay'>
				<tr class='pay'>
					<th class='pay'>S/N</th>
					<th class='pay'>E-Pin</th>
					<th class='pay'>Date</th>
					<th class='pay'>Status</th>
				</tr>
				
			<?php 
				$sql="select * from 349_epin_20 order by status asc, date_generated desc";
				$query=mysqli_query($con, $sql);
				$i=1;
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
					<tr class='pay'>	
						<td class='pay'><?php echo $i?></td>
						<td class='pay'><?php echo $out['ekey']?></td>
						<td class='pay'><?php echo $out['date_generated']?></td>
						<td class='pay'><?php echo $out['status']?></td>
					</tr>	
			<?php	
						$i++;
					}
				}else{
			?>
					<tr class='pay'>	
						<td class='pay' colspan='5'>No Record Found</td>
					</tr>
			<?php
				}
			?>
			</table>

		</div>
<?php 
include("includes/admin_foot.php");
?>