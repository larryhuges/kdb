<?php 
require_once("../includes/bootstrap.php");	
confirm_logged_in();
include("includes/member_head.php");
?>

<style type="text/css">

	.contNoti{
		display: flex; 
		align-items: center; 
		justify-content: flex-start; 
		width: 100%; 
		
	}

	.contNoti > div:first-child{
		width: 18rem;
		font-weight: bold;
		padding: 2rem; 
		text-align: right;
	}

	.contNoti > div:last-child{
		padding: 2rem; 
		display: flex; 
		align-items: center; 
		justify-content: flex-start; 
	}

	.contNoti input[type=radio]{
		width: 2rem;
		height: 2rem ;
		background-color: #0063cc;
		color: #0063cc;
	}

	.text{
		border: .1rem solid #333;
	}

	.tbtn{
		width: auto; 
		font-weight: bold;
		height:auto;
		padding: 1.5rem 2rem;
		font-size:1.4rem;
		border:none;
		cursor:pointer;
		margin: auto 1rem;
		min-width: 10rem;
		border-radius: 1rem 0 1rem 0
	}

	.tupd{
		background-color: #0063cc;
		color: #fff;
	}

</style>


<div id="frame" style="background-color: #F0F8FF; padding: 1.0rem; color: #666; font-size: 1.4rem;">
	<div id="inner-frame">
		<div class='col_bg' style="float: left; width: 100%; padding: 2.0rem; margin: 00; background-color: #fff;">

			<div class="pTitle">
				Exchange
			</div>
			<div class='col one_col' style='margin-top: 5rem;'>
				
				<div class='contNoti'>
					<div>
						Select
					</div>
					<div>
						<input type='radio' name='notii' checked /> &nbsp;&nbsp; Exchange Rate &nbsp;&nbsp;&nbsp;

						<input type='radio' name='notii'/> &nbsp;&nbsp; Exchange Rate Fluctuation
					</div>
				</div>

				<div class='contNoti'>
					<div>
						Currenct Type
					</div>
					<div>
						<select class='text' >
							<option>All</option>
							<option>USDOLLAR (USD)</option>
						</select>
					</div>
				</div>

				<div class='contNoti'>
					<div>
						Base Date of Inquiry
					</div>
					<div>
						<input type='date' style='' required class='text' />
					</div>
				</div>

				<div style='text-align: center; margin: 3rem auto'>
					<button class="tbtn tupd" type='submit' style="">View</button>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
include("includes/member_foot.php");
?>
