<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
alert_box();
?>

<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
	<div class='bread_c'>
		<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Purchase Plan
	</div></span>
</div>
<div class="g_col" style="width: 100%; margin: 0; padding: 20px 0; box-shadow: none;  background-color: transparent;">
<?php
$deposit=$plan=$errmsg=$date_pledged=$life_span=$range=$amount=$payment_method=$amount_err=$payment_method_err="";
$errcheck=0;
	if(isset($_POST['submit_deposit'])){
		
		$plan=clean_strings($_POST['plan_input']);

		if(empty($_POST['amount'])){
			$amount_err="Amount is Required";
			$errcheck=1;
		}else{
			$amount=clean_strings($_POST['amount']);
			if(!preg_match("/^[0-9]*$/",$amount)){
				$amount_err="Only Numbers are allowed";
				$errcheck=1;
			}	
		}

		if(empty($_POST['payment_method']) || $_POST['payment_method']=="Select Payment Method"){
			$payment_method_err="Select Payment Method";
			$errcheck=1;
		}else{
			$payment_method=trim(clean_strings($_POST['payment_method']));
			if(!preg_match("/^[a-zA-Z]*$/",$payment_method)){
				$payment_method_err="Only Alphabets and Numbers are allowed";
				$errcheck=1;
			}
				
		}

		if($plan=='SILVER'){
			if($amount<100 || $amount>=2000){
				$amount_err="Amount must lie between $100 and $1,999 for SILVER Plan";
				$errcheck=1;
			}
		}elseif($plan=='GOLD'){
			if($amount<2000 || $amount>=5000){
			$amount_err="Amount must lie between $2,000 and $4,999 for GOLD Plan";
				$errcheck=1;
			}
		}elseif($plan=='PLATINUM'){
			if($amount<5000 || $amount>=10000){
				$amount_err="Amount must lie between $5,000 and $9,999 for PLATINUM Plan";
				$errcheck=1;
			}
		}elseif($plan=='DIAMOND'){
			if($amount<10000 || $amount>30000){
				$amount_err="Amount must lie between $10,000 and $30,000 for DIAMOND Plan";
				$errcheck=1;
			}
		}

		if($errcheck==1){
			$msg="Mining Subscription (of $ $amount) was not successful!!!<br>$amount_err<br>$payment_method_err";
			echo "
					<script>
						popup(\"$msg\",'error');
					</script>
				";
		}else{
			$_SESSION['usd']=$amount;
			$_SESSION['payment_method']=$payment_method;
			$_SESSION['plan']=$plan;
			if($payment_method=='Visa' || $payment_method=='Mastercard'){
				redirect_to("../simplex/payments/new");
			}else{
				redirect_to("payment");
			}
		}
	}
?>
	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #222d32; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; font-size: 26px; font-family: signika; font-weight: normal;'>
				SILVER (Starter)
				<hr style="width: 100%; border-color:#fff;">
			</div>
				
			<div class='m_col' style="padding:2%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$100 - $1,999</h4>
				<h4 style="color: #fff; font-family: signika;">1 Year Mining Contract</h4>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%;">
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("SILVER")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>

	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #222d32; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; font-size: 26px; font-family: signika; font-weight: normal;'>
				GOLD (Best Buy)
				<hr style="width: 100%; border-color:#fff;">
			</div>
				
			<div class='m_col' style="padding:2%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$2,000 - $4,999</h4>
				<h4 style="color: #fff; font-family: signika;">1 Years Mining Contract</h4>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%;">
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("GOLD")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>
	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #222d32; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; font-size: 26px; font-family: signika; font-weight: normal;'>
				PLATINUM
				<hr style="width: 100%; border-color:#fff;">
			</div>
				
			<div class='m_col' style="padding:2%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$5,000 - $9,999</h4>
				<h4 style="color: #fff; font-family: signika;">1 Year Mining Contract</h4>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%;">
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("PLATINUM")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>
	<div class='m_col' style="padding:10px 2%;">
		<div class='m_col_t' style="background-color: #222d32; padding-top: 0; font-size: 13px;">
			<div style='padding:1%; font-size: 26px; font-family: signika; font-weight: normal;'>
				DIAMOND
				<hr style="width: 100%; border-color:#fff;">
			</div>
				
			<div class='m_col' style="padding:2%;">
				<h4 style="color: #cca800; font-size: 18px; font-family: signika; font-weight: bolder;">$10,000 - $30,000</h4>
				<h4 style="color: #fff; font-family: signika;">4 Year Mining Contract</h4>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					SHA-256 Mining Algorithm
				</p>
				<p style='font-family: page_section_font; color:#ccc; font-weight: normal;'>
					Money Back Guarateed
				</p>
			</div>
			<div class='m_col' style="padding:2%;">
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font;"><i class='fa fa-check' style="color:#aa0;"></i> 10% Daily Income</div>
				<div style="padding: 5px 5px; border-bottom: 1px solid #ccc; font-family: page_section_font; "><i class='fa fa-check' style="color:#aa0;"></i> Instant Withdrawal</div>
				<button style="margin:0; margin-top: 5%; font-family: page_title_font;" onclick='invest_now("DIAMOND")' class='btn upd'> <i class='fa fa-bolt'></i>&nbsp; Start Mining Now</button>
			</div>
		</div>
	</div>

</div>
<div id='alert_box_holder'>
	<div id="alert_box_center" style="margin-top: 5%; margin-bottom: 0;">
		<div id='alert_box' style="padding: 10% 5% 5% 5%; border-radius: 0;">
			<form action='' method='post' enctype='multipart/form-data'>
				<h2 style='color:#3b3; text-align: center; font-family: page_font_rob;'>
					Confirm Purchase
				</h2>
				<br>
				<p style='color:#555; text-align: center; font-family: page_title_font; font-size: 16px;'>
					You are about to purchase <b><span name='plan'><?php echo strtoupper($plan);?></span> PLAN</b>
				</p><br>
				
				<div class="input_icon_holder2">
					<div style="display: table-caption;"><?php echo errmessage_design($amount_err)?></div>
					<span class="input_icon2"><i class="fa fa-money"></i></span>
					<input type='text' value="<?php echo $amount;?>" placeholder='Enter Amount Between <?php echo $range;?>' required class='text' name='amount'>
					<input type='hidden' value="<?php //echo $plan_input;?>" required class='text' name='plan_input'>
				</div>

				<div class="input_icon_holder2">
					<div style="display: table-caption;"><?php echo errmessage_design($payment_method_err)?></div>
					<span class="input_icon2"><i class="fa fa-money"></i></span>
					<select type='text' required class='text' name='payment_method'>
						<option>Select Payment Method</option>
						<!--<option>Visa</option>
						<option>Mastercard</option>-->
						<option>Bitcoin</option>
					</select>
				</div>

				<button type='submit' style="margin:0; float:left;" name='submit_deposit' class='btn upd'>
					Continue <i class="fa fa-carat-right"></i>
				</button>
				<button type='button' onclick="close_alert()" style="margin:0; float:right;" name='submit_deposit' class='btn del'>
					Cancel
				</button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">

	function invest_now(str){
		var range;
		if(str=='SILVER'){
			range="$100 - $1,999";
		}else if(str=='GOLD'){
			range="$2,000 - $4,999";
		}else if(str=='PLATINUM'){
			range="$5,000 - $9,999";
		}else if(str=='DIAMOND'){
			range="$10,000 - $30,000";
		}
		var x=document.getElementById('alert_box_holder');
		var amount=document.getElementsByName('amount');
		var plan=document.getElementsByName('plan');
		var plan_input=document.getElementsByName('plan_input');
		amount[0].placeholder="Enter Amount "+range;
		plan[0].innerHTML=str;
		plan_input[0].value=str;
		x.style.display='block';
	}

	function close_alert(){
		var x=document.getElementById('alert_box_holder');
		x.style.display='none';
	}
</script>
<?php 
include("includes/member_foot.php");
?>