<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
alert_box();
?>

<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
	<div class='bread_c'>
		<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Referral</span>
	</div>
</div>
<div class="g_col">
	<div id='' style='font-size:16px; overflow-x:scroll; color:#4CAF50;'> 
		<div>
			<div style="float: left; padding: 15px 5px">People you have referred</div>
			<button class="btn upd" style="float: right;" onclick="alert('Referral Bonus can be cash out when its sum to $2,000')">Cash out Bonus</button>
		</div>
		<table class='pay'>
			<tr class='pay'>
				<th class='pay' style="color:#fff; background-color: #2196F3;">USERNAME</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">AMOUNT INVESTED</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">DATE INVESTED</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">BONUS</th>
			</tr>

			<?php 
				$sql="select *, sum(referral_bonus) as bb from users_account where referral='{$_SESSION['wlis_member_username']}' order by trans_id desc";
				$query=mysqli_query($con,$sql);
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
						<tr class='pay'>
							<td class='pay'>&nbsp;<b><?php echo strtoupper($out['username']);?></b>&nbsp;</td>
							
							<td class='pay'>&nbsp;$ <?php echo $out['pledge'];?>&nbsp;
							</td>
							<td class='pay'>&nbsp; <?php echo $out['date_pledged'];?></span>&nbsp;</td>
							<td class='pay'>&nbsp;$ <?php echo $out['referral_bonus'];?></span>&nbsp;</td>
							
						</tr>

						<tr class='pay'>
							<td class='pay' style="font-size: 16px; font-family: signika;" colspan="3">&nbsp;TOTAL&nbsp;</td>
							<td class='pay' style="font-size: 16px; font-family: signika;" >&nbsp;$ <?php echo $out['bb'];?></span>&nbsp;</td>
						</tr>
			<?php 
					}
				}else{
			?>
					<tr class='pay'>
						<td class='pay' colspan="5" style="color: #888; text-align: center;">
							&nbsp; You have not referred anyone &nbsp;
						</td>
					</tr>
			<?php
				}
			?>
		</table>
		
	</div>
</div>

<?php 
include("includes/member_foot.php");
?>