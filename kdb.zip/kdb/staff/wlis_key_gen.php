<?php
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
		
		$amount=clean_strings($_GET['amt']);
		$country=clean_strings($_GET['country']);
		$country_n=clean_strings($_GET['country_n']);
		
		if(!empty($amount)){
		echo "<table style='width:100%; height:auto; margin:auto; margin-bottom:1%; border-collapse:collapse; color:#333; border:1px solid #aaa;' class='pay'>
		<h1>";
		if(!empty($country_n)){
			echo $country_n;
		}else{
			echo "Nigeria";
		}
			echo "</h1>
			<th style='width:20px; height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'>S/N</th>
			<th style='width:50px;	height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'>EPINs</th>
			<th style='width:50px;	height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'>Status</th>
			";
		for($i=0;$i<$amount;$i++){
			$allChar="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			$key=$country.substr(str_shuffle($allChar),0,8);
			
			$hashed=sha1($key);
			$query=mysqli_query($con, "select epin from 349_epin_20 where epin='$hashed' limit 1");
			if(mysqli_affected_rows($con)>=1){
				echo null;
			}else{
				if(mysqli_query($con, "insert into `349_epin_20` (ekey, epin, country) values ('$key', '$hashed', '$country')")){
					echo "
					<tr style='width:100%; height:auto; margin:auto; margin-bottom:1%; border-collapse:collapse; color:#333; border:1px solid #aaa;' class='pay'>
					<td style='width:20px;	height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'>".($i+1)."</td>
						<td style='width:50px;	height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'>$key</td>
						<td style='width:50px;	height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'>Active</td>
					</tr>
					";
				}
			}
		} 
		echo "
			<tr style='width:100%; height:auto; margin:auto; margin-bottom:1%; border-collapse:collapse; color:#333; border:1px solid #aaa;' class='pay'>
				<td style='width:50px; height:auto; vertical-align: center; margin:auto; text-align:center; border-collapse:collapse; font-size:14px;' class='pay'><button class='btn upd' id='h_bn' onclick='print_epins()'>Print Epin</button></td>
			</tr>
			</table>
		";
		}else{
			echo "Enter Quantity of Pins";
		}
?>