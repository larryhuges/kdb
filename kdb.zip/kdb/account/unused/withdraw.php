<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
alert_box();
$plan=$amount=$t_id=$tt_i=$withdrawable=$msg="";
$plan=$amount=$t_id=$tt_i=$withdrawable=$firstname=$lastname=$mobile=$h_address=$bank_name=$name_on_account=$account_number=$account_type=$routing_number="";
	$errmessage=array();
if(isset($_POST['submit_withdraw'])){
	if(!empty($_POST['tt_i']) && isset($_POST['tt_i'])){
		$t_id=clean_strings($_POST['tt_i']);
		if(!preg_match("/^[0-9]*$/",$t_id)){
			$errmessage[]="Only Numbers are allowed<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Id cannot be empty";
		$errcode[]=3;
	}
			
	if(!empty($_POST['r_input']) && isset($_POST['r_input'])){
		$amount=clean_strings($_POST['r_input']);
		if(!preg_match("/^[0-9]*$/",$amount)){
			$errmessage[]="Only Numbers are allowed<br>";
			$errcode[]=1;
		}
	}else{
		$errmessage[]="Amount cannot be empty";
		$errcode[]=3;
	}

	
    $date_of_event=date("Y-m-d H:i:s");
	$sql="insert into transactions (firstname, lastname, username, amount, description, user_id, date_of_event, status) values ('{$_SESSION['wlis_member_firstname']}', '{$_SESSION['wlis_member_lastname']}', '{$_SESSION['wlis_member_username']}', $amount, 'Cash Withdrawal', $t_id, '$date_of_event', 'confirmed')";

	$o="";
	if(!empty($errmessage)){
		foreach ($errmessage as $value) {
			$msg.=$value.'<br>';
		}	
		echo "
			<script>
				popup(\"$msg\",'error');
			</script>
		";
	}else{
		if($amount<2000){
			$msg="Minimum withdrawable is $ 2,000";	
				echo "
					<script>
						popup(\"$msg\",'error');
					</script>
				";
		}else{
			$withdrawable=withdraw_bal($t_id);
			$earning=earning($t_id);
			if($withdrawable>=$amount){
			    mysqli_query($con, $sql);
				if(mysqli_affected_rows($con)==1){
					$query=mysqli_query($con, "update `users_account` set withdrawn = $withdrawable where username='{$_SESSION['wlis_member_username']}' and trans_id=$t_id");
					if(mysqli_affected_rows($con)==1){

						$msg="Withdrawal Request (of $ $amount) was Sent Successfully!!!<br>You will recieve a mail shortly.<br> Do check your spam box if you did not recieve the mail";
						setcookie("success","$msg",time() + (3600*5),"/");

						$subject='Requested Successfully';
						$message="Dear ".$_SESSION['wlis_member_username'].",<br><br>we appreciate you for using 4XMINING mining platform.<br>";
						$url="withdraw";
						$admin_msg="{$_SESSION['wlis_member_username']} has requested for withdrawal on ".date("Y-m-d H:i:s");
						send_admin_mail('Withdrawal Request',$admin_msg);
						send_mail($_SESSION['wlis_member_email'],$_SESSION['wlis_member_username'],$subject,$message,$url);
						
					}
				}
			}else{
				$msg="Insufficient Balance";	
				echo "
					<script>
						popup(\"$msg\",'error');
					</script>
				";
			}
		}
	}
}
?>

<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
	<div class='bread_c'>
		<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Request Funds</span>
	</div>
</div>
<div class="g_col">
	<div id='' style='font-size:16px; overflow-x:scroll; color:#4CAF50;'> 
		<table class='pay'>
			<tr class='pay'>
				<th class='pay' style="color:#fff; background-color: #2196F3;">PLAN</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">RETURNABLE</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">MINING GROWTH</th>
				
				<th class='pay' style="color:#fff; background-color: #2196F3;">ACTION</th>
			</tr>

			<?php 
				$sql="select * from users_account where username='{$_SESSION['wlis_member_username']}' and status='in progress' order by trans_id desc";
				$query=mysqli_query($con,$sql);
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
			?>
						<tr class='pay'>
							<td class='pay'>&nbsp;<b><?php echo strtoupper($out['plan'])." (".($out['rate']*100)."%)";?></b>&nbsp;</td>
							<?php
						    	$mod = $out['returnable']%100;
						    	if($mod == 0){
						    	    $earn=$out['returnable'];
						    	}else{
						    	    $earn=$out['returnable']-$mod;
						    	}
                                
                            ?>
							<td class='pay'>&nbsp;$ <?php echo $earn;?>&nbsp;
							</td>
							<td class='pay'>&nbsp;$ <span id='t_widh<?php echo $out['trans_id'];?>'><?php echo $out['trade_growth'];?></span>&nbsp;</td>
							
								<td class='pay'>&nbsp;
									<input type='hidden' min='0' max='500000' id='g_am<?php echo $out['trans_id'];?>' name='<?php echo $out['trans_id'];?>' value='<?php echo $out['trade_growth'];?>' class='text_s' placeholder='Enter Amount' required>
									<input type='hidden' name='t_id' value="<?php echo $out['trans_id'];?>" id='g_id<?php echo $out['trans_id'];?>'>&nbsp;
									<button type='button' onclick='cash_out("<?php echo $out['trans_id'];?>")' class='btn upd'>	Request Cash
									</button>
									&nbsp;
								</td>
						</tr>
			<?php 
					}
				}else{
			?>
					<tr class='pay'>
						<td class='pay' colspan="5" style="color: #888; text-align: center;">
							&nbsp; No Transactions Found &nbsp;
						</td>
					</tr>
			<?php
				}
			?>
		</table>
		
	</div>
</div>
<div id='alert_box_holder'>
	<div id="alert_box_center" style="margin-top: 5%; margin-bottom: 0;">
		<div id='alert_box' style="padding: 10% 5% 5% 5%; border-radius: 0;">
			<form action='' method='post' enctype='multipart/form-data'>
				<h2 style='color:#3b3; text-align: center; font-family: page_font_rob;'>
					Confirm Withdrawal Request
				</h2>
				<br>
				<p style='color:#555; text-align: center; font-family: page_title_font; font-size: 16px;'>
					You are about to withdraw <b><span id='planm'></span></b>
				</p><br>
				
				<input type='hidden' name='tt_i' class='text_s'>
				<input type='hidden' name='r_input' class='text_s'>

				<button type='submit' style="margin:0; float:left;" name='submit_withdraw' class='btn upd'>
					Comfirm
				</button>
				<button type='button' onclick="close_alert()" style="margin:0; float:right;" class='btn del'>
					Cancel
				</button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">

	function cash_out(str){

		var x=document.getElementById('alert_box_holder');
		var planm=document.getElementById('planm');
		var tt_i=document.getElementsByName('tt_i');
		var r_input=document.getElementsByName('r_input');
		
		var plan_am=document.getElementById('g_am'+str).value;
		var plan_id=document.getElementById('g_id'+str).value;

		
		tt_i[0].value=plan_id;
		r_input[0].value=plan_am;
		planm.innerHTML="$ "+plan_am;

		x.style.display='block';
	}

	function close_alert(){
		var x=document.getElementById('alert_box_holder');
		x.style.display='none';
	}
</script>
<?php 
include("includes/member_foot.php");
?>