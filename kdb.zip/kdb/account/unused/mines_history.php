<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_logged_in();
include("includes/member_head.php");
?>
<div class='g_col' style=" box-shadow:none; border-radius: 3px; background-color: transparent;">
	<div class='bread_c'>
		<i class="fa fa-home"></i> Home <span style="color: #aaa;">/ Trade History</span>
	</div>
</div>
<div class="g_col">
	<div id='' style='font-size:16px; overflow-x:scroll; color:#4CAF50;'> 
		<table class='pay'>
			<tr class='pay'>
				<th class='pay' style="color:#fff; background-color: #2196F3;">SN</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">INVEST</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">EARNING</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">GROWTH</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">DATE</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">STATUS</th>
				<th class='pay' style="color:#fff; background-color: #2196F3;">WITHDRAWN</th>
			</tr>

			<?php 
				$sql="select * from users_account where username='{$_SESSION['wlis_member_username']}' order by date_pledged desc";
				$query=mysqli_query($con,$sql);
				$i=1;
				if(mysqli_affected_rows($con)>=1){
					while($out=mysqli_fetch_assoc($query)){
					
			?>
						<tr class='pay'>
							<td class='pay'>&nbsp;<?php echo $i;?>&nbsp;</td>
							<td class='pay'>&nbsp;$ <?php echo $out['pledge'];?>&nbsp;
							</td>
							<?php
						    	$mod = $out['returnable']%100;
						    	if($mod == 0){
						    	    $earn=$out['returnable'];
						    	}else{
						    	    $earn=$out['returnable']-$mod;
						    	}
                                
                            ?>
							<td class='pay'>&nbsp;$ <?php echo $earn;?>&nbsp;
							</td>
							
							<td class='pay'>&nbsp;$ <?php echo $out['trade_growth'];?>&nbsp;
							</td>
							
							<td class='pay'>&nbsp; 
								<?php echo formatted_date($out['date_pledged'])?>
							&nbsp;</td>
							
							
							<td class='pay'>&nbsp;
								
								<?php echo strtoupper($out['status']);?>
								
								&nbsp;
							</td>
							
							<td class='pay' align='center'>&nbsp;
								
								<?php 
									if($out['withdrawn']==$earn){
										echo "<i class='fa fa-check' style='font-size:20px; color:#be0;'></i>";
									}else{
										echo "<i class='fa fa-ban' style='font-size:20px; color:#f00;'></i>";
									}
								?>
								
								&nbsp;
							</td>
						</tr>
			<?php 
					$i++;
					}
				}else{
			?>
					<tr class='pay'>
						<td class='pay' colspan="5" style="color: #888; text-align: center;">
							&nbsp; No Trade Found &nbsp;
						</td>
					</tr>
			<?php
				}
			?>
		</table>
		
	</div>
</div>
<?php 
include("includes/member_foot.php");
?>
