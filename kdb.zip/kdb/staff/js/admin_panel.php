<?php
ob_start();
require_once("includes/sessions.php");	
require_once("includes/connection.php");
require_once("functions/functions.php");
confirm_admin_logged_in();
include("includes/head.php");
?>
<?php
//profile
	$fullname_err="";
	$m_err="";
	$acc_err="";
	$bname_err="";
	$state_err="";
	
//password
	$o_err="";
	$n_err="";
	$r_n_err="";
	$errcheck=0;
	
//support
	$name='';
	$message='';
	$email='';
	
	$n_err='';
	$m_err='';
	$e_err='';
	
	$ph_trans_id="";
	$ph_account="";
	$pay_amount="";
	$gh_trans_id="";
	$gh_account="";
	$ph_bal="";
	$gh_bal="";

	$ph_trans_id_err="";
	$ph_account_err="";
	$pay_amount_err="";
	$gh_trans_id_err="";
	$gh_account_err="";
	
	$errcheck=0;
	
	if(isset($_GET['visible']) && isset($_GET['account']) && !empty($_GET['account'])){
		$visible=clean_strings($_GET['visible']);
		$account=clean_strings($_GET['account']);
		$delete=null;
	}elseif(isset($_GET['delete']) && isset($_GET['account']) && !empty($_GET['account'])){
		$account=clean_strings($_GET['account']);
		$delete=clean_strings($_GET['delete']);
		$visible=null;
	}else{
		$visible=null;
		$account=null;
		$delete=null;
	}
	
		if($visible=='Yes'){
			mysqli_query($con,"update users_info set visible='No' where account=$account");
			redirect_to("admin_panel.php?SelMenu=Block_Unblock");
		}elseif($visible=='No'){
			mysqli_query($con,"update users_info set visible='Yes' where account=$account");
			redirect_to("admin_panel.php?SelMenu=Block_Unblock");
		}
		
		 if($delete=='Yes'){
			mysqli_query($con,"delete from users_info where account=$account");
			mysqli_query($con,"delete from users_account where account=$account");
			redirect_to("admin_panel.php?SelMenu=Block_Unblock");
		}
	
?>
<div id='wrapper' style="background-color:#eee; margin-top:0;">
	<div id='wrapper' style='background-color:#38454f; color:white; display:inline-block; padding:10px 1% 10px 1%; width:98%; margin:0;'>
		<table style='border-collapse:collapse; border:; margin-bottom:10px;'>
		<tr>
			<td style='border-right:2px solid #fff;padding:0px 20px 0px 10px; color:#0c0; text-shadow:0px 0px 2px #000; width:50%; font-family: Agency FB; font-size:40px;'>
				Admin Panel
			</td>
			<td style='width:50%; padding-left:10px;'>
				<span style='font-family: sans-serif; font-weight:bolder; color:White; font-size:20px;'>
					Hello <?php echo $_SESSION['admin_username'];?>, 
				</span><br>
			
				<div id='from'>
					<?php echo date('M d, Y H:i:s');?>
				</div>
			</td>
		</tr>
		</table>
	</div>
	<div id='wrapper' style='background-color:#eee; color:white; display:inline-block; padding:10px 1% 10px 0%; width:99%; margin-top:10px; margin-bottom:0;'>
			<div id="side_nav">
				<ul class="two">
					<a href="admin_panel.php?SelMenu=Merger"><li class="two"><div class="two_bg">Merger</div>
					</li></a>
					<li class="two"><div onclick="show_sub(0)" class="two_bg">Transactions<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
						<ul class="ul_sub_two">
							<a href="admin_panel.php?SelMenu=Ph"><li class="sub_two">View PH List</li></a>
							<a href="admin_panel.php?SelMenu=Gh"><li class="sub_two">View GH List</li></a>
							<a href="admin_panel.php?SelMenu=Gh"><li class="sub_two">Pendings</li></a>
							<a href="admin_panel.php?SelMenu=Gh"><li class="sub_two">History</li></a>
						</ul>
					</li>
					<a href="admin_panel.php?SelMenu=Block_Unblock"><li class="two"><div class="two_bg">Block/Unblock Accounts</div></li></a>
					<li class="two"><div onclick="show_sub(1)" class="two_bg">Staff Accounts<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
						<ul class="ul_sub_two">
							<a href="dashboard.php?SelMenu=Edit_Profile"><li class="sub_two">Create Staff</li></a>
							<a href="dashboard.php?SelMenu=Change_Password"><li class="sub_two">View/Delete Staff</li></a>
						</ul>
					</li>
					<li class="two"><div onclick="show_sub(2)" class="two_bg">Testimonials<span class="drop_sign"><i class="fa fa-angle-down"></i></span></div>
						<ul class="ul_sub_two">
							<li class="sub_two">Approve Testimonies</li>
							<li class="sub_two">Active Testimonies</li>
						</ul>
					</li>
					<a href="logout.php?key=22"><li class="two"><div class="two_bg">Logout</div></li></a>
				</ul>
			</div>
			
			<div id="board" style='height:550px;'>
			
			<?php
				if(isset($_GET['SelMenu']) && $_GET['SelMenu']=="Block_Unblock"){
					echo "<div id='tab' style='font-family:sans-serif; height:550px;'>
					<h1 style='text-align: center; margin-top:30px; color:#d00; font-size:20px; font-family: Tahoma, Geneva, sans-serif;'>
						Block/Unblock User</h1>
					
					
					<table class='pay'>
						<tr class='pay'>
							<th class='pay'>S/N</th>
							<th class='pay'>Names</th>
							<th class='pay'>Account</th>
							<th class='pay'>Visible</th>
							<th class='pay'>Block/Unblock Users</th>
							<th class='pay'>Delete Account</th>
						</tr>";
					
						$sql_b="select fullname, account, visible from users_info order by date asc";
						$query_b=mysqli_query($con,$sql_b);
						$i=1;
						while($out_b=mysqli_fetch_assoc($query_b)){
							 echo "
									<tr class='pay'>
										<td class='pay'>$i</td>
										<td class='pay'>{$out_b['fullname']}</td>
										<td>{$out_b['account']}</td>
										<td class='pay'>{$out_b['visible']}</td>
							";
								if($out_b['visible']=='Yes'){
									echo "<td class='pay'><a onclick='confirm_block(\"{$out_b['fullname']}\",\"Block\",\"Yes\",{$out_b['account']})'><span class='log_btn' style='float:none;'><i class='fa fa-check'></i>&nbsp;Block</span></a></td>";
								}elseif($out_b['visible']=='No'){
									echo "<td class='pay'><a onclick='confirm_block(\"{$out_b['fullname']}\",\"UnBlock\",\"No\",{$out_b['account']})'><span class='log_btn' style='float:none;'><i class='fa fa-check'></i>&nbsp;UnBlock</span></a></td>";
								}
							echo "<td><a onclick='delete_account(\"{$out_b['fullname']}\",{$out_b['account']})'><span class='log_btn' style='float:none;'><i class='fa fa-check'></i>&nbsp;Delete</span></a></td>";
							echo "
									</tr>
								
							";
							$i++;
						}
					echo "	</table>
					</div>";
				}elseif(isset($_GET['SelMenu']) && $_GET['SelMenu']=="Merger"){
					echo "<div id='tab' style='font-family:sans-serif; height:550px;'>
					
					<h1 style='text-align: center; margin-top:30px; color:#d00; font-size:20px; font-family: Tahoma, Geneva, sans-serif;'>
						Block/Unblock User</h1>
					 <form action='' method='post' enctype='multipart/form-data'>
					<br>Transaction Id PH:
					<input type='number' class='text' value='$ph_trans_id' name='ph_trans_id'><br><span style='color:red; font-style:italic; font-size:12px;'>$ph_trans_id_err</span>
					<br>PH Account Num:
					<input type='text' class='text' value='$ph_account' maxlength='10' name='ph_account'><br><span style='color:red; font-style:italic; font-size:12px;'>$ph_account_err</span>
					<br>PH Amount:
					<input type='text' class='text' value='$gh_account' maxlength='10' name='gh_account'><br><span style='color:red; font-style:italic; font-size:12px;'>$gh_account_err</span>
					<br>Transaction Id GH:
					<input type='number' class='text' value='$pay_amount' maxlength='10' name='pay_amount'><br><span style='color:red; font-style:italic; font-size:12px;'>$pay_amount_err</span>
					<br>Pay to Account:
					<td class='pay'><input type='number' class='text' value='$gh_trans_id' name='gh_trans_id'><br><span style='color:red; font-style:italic; font-size:12px;'>$gh_trans_id_err</span><br>
					<input type='submit' class='text' name='merge' value='Merge'>	
					</form></div>
					";
				}elseif(isset($_GET['SelMenu']) && $_GET['SelMenu']=="Ph"){
					echo "
					<div id='tab' style='font-family:sans-serif; height:550px;'>
						 <h1 style='text-align: center; margin-top:30px; color:#d00; font-size:20px; font-family: Tahoma, Geneva, sans-serif;'>List of PH</h1>
						";
						$i=1;
						$sql="select * from users_account where confirm_ph='No' order by date_pledged asc";
						$query=mysqli_query($con,$sql);
					
				   echo "
					<table align='center' class='pay'>
					<tr class='pay'>
						<th class='pay'>trans_id</th>
						<th class='pay'>Name</th>
						<th class='pay'>Username</th>
						<th class='pay'>Account</th>
						<th class='pay'>Merged Help Provided</th>
						<th class='pay'>Balance to Pay</th>
						<th class='pay'>Days Gone</th>
						<th class='pay'>Days Left</th>
						<th class='pay'>Confirm PH </th>
						<th class='pay'>Completed PH Merged</th>
						</tr>
				 ";
					while($outter=mysqli_fetch_assoc($query)){
						echo "
								<tr align='center' class='pay'>
									<td class='pay'>{$outter['trans_id']}</td>
									<td class='pay'>{$outter['fullname']}</td>
									<td class='pay'>{$outter['username']}</td>
									<td class='pay'>{$outter['account']}</td>
									<td class='pay'>{$outter['ph_amount_merged']}</td>
									<td class='pay'>{$outter['ph_amount_bal']}</td>";
										
								$m_target=strtotime($outter['date_to_harvest']);
								if(!empty($m_target)){
									$n_date=ceil(($m_target-time())/60/60/24);
									$n=31-$n_date;
								}else{
									$n_date="Pending";
									$n="pending";
								}
								
						 echo "     <td class='pay'>$n day(s)</td>
								<td class='pay'>$n_date day(s)</td>      
								<td class='pay'>{$outter['confirm_ph']}</td>
									<td class='pay'>{$outter['ph_merged']}</td>
								</tr>
							
						";
						$i++;
					}
					
					echo "</table>
								</div>
								";
				}elseif(isset($_GET['SelMenu']) && $_GET['SelMenu']=="Gh"){
					echo "
					<div id='tab' style='font-family:sans-serif; height:550px;'>
					<h1 style='text-align: center; margin-top:30px; color:#d00; font-size:20px; font-family: Tahoma, Geneva, sans-serif;'>List of GH</h1>";
        
			$i=1;
			$sql="select * from users_account where request_gh='Yes' and level<>'staff' order by date_to_harvest asc";
			$query=mysqli_query($con,$sql);
		echo "
					<!--GH-->
					<table align='center' class='pay'>
					<tr  class='pay'>
						<th class='pay'>trans_id</th>
						<th class='pay'>Name</th>
						<th class='pay'>UserName</th>
						<th class='pay'>Account</th>
						<th class='pay'>Total Cash-Out</th>	
						<th class='pay'>Balance to Receive</th>
						<th class='pay'>Confirm GH </th>
						<th class='pay'>Completed GH Merged</th>
						</tr>";
	
					while($outter=mysqli_fetch_assoc($query)){
						echo "
							<tr align='center' class='pay'>
								<td class='pay'>{$outter['trans_id']}</td>
								<td class='pay'>{$outter['fullname']}</td>
								<td class='pay'>{$outter['username']}</td>
								<td class='pay'>{$outter['account']}</td>
								<td class='pay'>{$outter['returnable']}</td>
								<td class='pay'>{$outter['gh_amount_bal']}</td>
								<td class='pay'>{$outter['confirm_gh']}</td>
								<td class='pay'>{$outter['gh_merged']}</td>
							</tr>  
						";
						$i++;
					}
					echo mysqli_error($con)."
					
					</table></div>";
				}
			?>
				
		</div>
			
		</div>
	<script>
		function show_sub(index){

			var x=document.getElementsByClassName("ul_sub_two");
			var y=document.getElementsByClassName("drop_sign");
			//document.getElementsByClassName("sub_two")[index].style.display="block";
			//alert("it "+document.getElementsByClassName("sub_two")[index].style.display);
			if(x[index].style.display=="block"){
				x[index].style.display="none";
				y[index].innerHTML="<i class='fa fa-angle-down'></i>";
				
			}else{
				x[index].style.display="block";
				y[index].innerHTML="<i class='fa fa-angle-up'></i>";
			}
		}
		
	function confirm_block(str_value,block,visible,acct){
		var x=window.confirm("Are You Sure You want to " + block + " " + str_value + "?");
		if(x==true){
			window.location.assign("admin_panel.php?visible="+visible+"&account="+acct);
		}
	}
	
	function delete_account(str_value,acct){
		var x=window.confirm("Are You Sure You want to Delete " + str_value + " Account?");
		if(x==true){
			window.location.assign("admin_panel.php?delete=Yes"+"&account="+acct);
		}
	}
	</script>
<?php 
	include("includes/foot.php");
	ob_end_flush();
?>