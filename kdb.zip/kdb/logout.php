<?php
    ob_start();
	session_start();
	require_once("includes/connection.php");
	
	if(isset($_GET['key']) && $_GET['key']==404){
	     mysqli_query($con, "update users_info set visible = 'No' where email = '{$_SESSION['customer_email']}'");
	}
	
	$_SESSION=array();
	
	if(isset($_COOKIE[session_name()])){
		setcookie(session_name(),'',time()-42000,'/');
	}
	
	session_destroy();
	
	if (isset($_GET['key']) && $_GET['key']==11){
		header("Location: /");
		exit;
	}elseif(isset($_GET['key']) && $_GET['key']==404){
		header("Location: /?err=404");
		exit;
	}elseif(isset($_GET['key']) && $_GET['key']==22){
		header("Location: ../admin_gain_321_access");
		exit;
	}elseif(isset($_GET['key']) && $_GET['key']==33){
		header("Location: ../depot_log/1");
		exit;
	}
?>