<?php
	require 'includes/bootstrap.php';
	//confirm_logged_in();
	include("includes/guest_area_head.php");
	alert_box();
?>
<style type="text/css">
	.s_title{
		font-size: 16px; 
		font-weight: bold;
	}

	ul{
		margin-left: 20px;
	}

	li{
		line-height: 1.6;
	}
</style>
<?php echo page_header("CHECKING", "media/images/backgrounds/bg.jpg")?>

<div id="frame" style="background-color: #fff; padding: 10px; color: #333; font-size: 14px;">
	<div id="inner-frame" class='all_dis_h show_sixth_frame' style="padding: 0 0; margin: 70px auto">
		<p>
			Whether you write a few checks a month or need unlimited check-writing, KDB has a checking product that is right for you.
		</p>
		<br>

		<p class="s_title">Relationship Checking</p><br>

		<ul>
		    <li>Maintain a low minimum relationship balance of $2,500 and there are no monthly maintenance fees.</li>
		    <li>All of your deposit accounts - Savings, Money Market Accounts, CDs, IRAs - are combined to meet this minimum.</li>
		    <li>No per check charges.</li>
		</ul>
		<br>

		<p class="s_title">NOW Checking</p><br>
		<ul>
		    <li>Earn a competitive interest rate on your checking balances.</li>
		    <li>Low minimum account balance of $2,500 to avoid a monthly maintenance fee.</li>
		</ul>
		<br>
		
		<p class="s_title">Basic Checking</p><br>
		<ul>
		    <li>Perfect for people who only write a few checks per month.</li>
		    <li>No minimum balance.</li>
		    <li>Low monthly fee.</li>
		    <li>Minimum opening deposit of $25.</li>
		</ul>
		<br>
		
		<p>
			All of our checking products come with optional overdraft protection (subject to approval). With an KDB Reserve Line of Credit you'll never have to worry again about writing a check larger than your balance.
		</p>
		<br>
		<ul>
		    <li><b>Online Banking</b> - With KDBOnline™ you can do your banking and pay your bills anywhere you have access to the internet, anytime of the day or night.</li>
		    <li><b>Our Cash Navigator™</b> debit card can be used to get cash at any ATM where you see the NYCE™, Honor™, Pulse™, or Plus™ logos. Additionally, it can be used in place of cash or a check when you shop anywhere MasterCard®/Debit Card is accepted.</li>
		    <li><b>PhoneAccess™</b> - KDB's bank-by-phone service lets you stay up to date on balances and even lets you transfer funds between qualified accounts.</li>
		</ul>
		<br>
		<p>
			For more information please call 1-800-836-1998, Monday through Friday 8:00 AM - 6:00 PM ET or e-mail us at onlinecustomerservice@KDB.com.
		</p>
	</div>
</div>

<?php include("includes/guest_area_foot.php");?>